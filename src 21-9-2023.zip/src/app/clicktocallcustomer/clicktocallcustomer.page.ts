import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { RDMbranchcallPage } from '../modal/rdmbranchcall/rdmbranchcall.page';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';
import { Idle,DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
@Component({
  selector: 'app-clicktocallcustomer',
  templateUrl: './clicktocallcustomer.page.html',
  styleUrls: ['./clicktocallcustomer.page.scss'],
  providers:[DatePipe,Idle]
})
export class ClicktocallcustomerPage implements OnInit {
  userid: any;
  branchid: any;
  UserType: any;
  dateToday3 = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
  allbranchlist: any;
  fromdate:any
  todate:any
  fromdate_limit: any;
  branchdata: any;
  branchlist: any;
  tot_calls: number;
  branchlistlenth: any;
  isshow:boolean=true
  format_fromdate: string;
  format_todate: string;
  oneDay: number;
  diffDays: number;
  idleState: string;
  constructor(public router:Router,public apiservice:ApiServiceService,
    public alert:AlertServiceService,private modalController:ModalController,
    private loader:ToastServiceService,private datepipe:DatePipe,private idle:Idle) { 
       // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(2*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = "No longer idle."));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
        (this.idleState = countdown.toString() )
    );
    }

  ngOnInit() {
    
this.isshow=true
  this.userid= window.localStorage['userID']
  this.branchid= window.localStorage['branchID']
 this. UserType=window.localStorage['userType']
  // let data=this.navParams.get('Data');
  this.getbranch()
//  this.getlistbranch(this.branchid)
// this.reset()
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    //this.timedOut = false;
  }
  async openrdmbranchcall(items){
    debugger
    var fromdate = this.datepipe.transform(this.fromdate,'dd-MM-yyyy')
      
    var todate = this.datepipe.transform(this.todate,'dd-MM-yyyy')
    const modal = await this.modalController.create({
      component: RDMbranchcallPage,
      componentProps: {Data: items,fdate:fromdate,tdate:todate}
    });
    return await modal.present();
  
  }
  goTobranchsummary(){
  //  if(this.UserType=='17'){
  //    this.router.navigateByUrl('/newsummary')
  //  }else{
  //   this.router.navigateByUrl('/regionsummary')
  //  }

   if (this.UserType == 14 || this.UserType == 26) {
    this.router.navigate(['/regionsummary']);
}else
  if(this.UserType =='17')
{ this.router.navigate(['/newsummary']);}else{
  this.router.navigateByUrl('/myplanner');
}

  }
  getbranch(){
   
 
      this.apiservice.getRdmHeatMapBranch(null,this.userid,this.UserType)
      .then((response:any)=> {
        
          response =JSON.parse(JSON.parse(response.data));
          console.log(response);
          this.allbranchlist = response;
      // this.mangermap =response;
      },err=>{
        this.alert.presentAlert("ERROR",err.status)
      })
   
    }

vvxyz(branchid){
  debugger
  var fromdate = this.datepipe.transform(this.fromdate,'dd-MM-yyyy')
      
  var todate = this.datepipe.transform(this.todate,'dd-MM-yyyy')
  this. format_fromdate = this.datepipe.transform(this.fromdate,'yyyy/MM/dd') ;
  this. format_todate = this.datepipe.transform(this.todate, 'yyyy/MM/dd') ;
  this. oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds    
   this. diffDays = Math.round(Math.abs((new Date(this.format_fromdate).getTime() - new Date(this.format_todate).getTime())/(this.oneDay)));
   if(fromdate != undefined && fromdate != null && fromdate != '' && todate != undefined&& todate != null&& todate != ''){
    if(this.diffDays< 31){
if(this.UserType==14){
this.loader.presentLoading('')
  this.apiservice.getRDMBranchList(branchid,this.userid,this.UserType,fromdate,todate)
  .then((response:any)=> {
   debugger
     this.loader.dismissLoading()
    this.isshow=false
      response = JSON.parse(JSON.parse(response.data));
      console.log(response);
      this.branchlist = response;
      this.branchlistlenth=this.branchlist.length
      
      this.tot_calls = 0;

      this.branchlist.forEach(element => {
        this.tot_calls += element.Calls;
      });
    
  // this.mangermap =response;
  })
}else{
  var data = {
            BranchName: window.localStorage['BranchDescription'],
             BranchCode: window.localStorage['branchCode'],
             BranchId: window.localStorage['branchID']
          }
           this.openrdmbranchcall(data);
}
    }else{
      this.alert.presentAlert("","Difference in dates should not exceed 31 days")
    }
}
}



    
//     getlistbranch(branchid:any){
//       
// if(this.fromdate=='' || this.fromdate==undefined || this.fromdate==null){
//   this.alert.presentAlert("","Please choose From Date")
// }else if(this.todate=='' ||this.todate==undefined || this.todate==null){
//   this.alert.presentAlert("","Please choose To Date")
// }
// else{

//       this.fromdate_limit = this.fromdate
//       var fromdate = this.datepipe.transform(this.fromdate,'dd-MM-yyyy')
      
//       var todate = this.datepipe.transform(this.todate,'dd-MM-yyyy')
//       var format_fromdate = this.datepipe.transform(this.fromdate,'yyyy/MM/dd') ;
//       var format_todate = this.datepipe.transform(this.todate, 'yyyy/MM/dd') ;
//       this.fromdate =this.datepipe.transform(this.fromdate, 'dd/MM/yyyy') ;
//       this.todate = this.datepipe.transform(this.todate, 'dd/MM/yyyy') ;
//       console.log(fromdate,todate);
//       var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds    
//       var diffDays = Math.round(Math.abs((new Date(format_fromdate).getTime() - new Date(format_todate).getTime())/(oneDay)));
//       if(fromdate != undefined && fromdate != null && fromdate != '' && todate != undefined&& todate != null&& todate != ''){
//       if(diffDays< 31){
//         if(window.localStorage['userType'] == '14'){
//           // this.loader.presentLoading('')
//       this.apiservice.getRDMBranchList(branchid,this.userid,this.UserType,fromdate,todate)
//       .then((response:any)=> {
       
//         // this.loader.dismissLoading()
//         this.isshow=false
//           response = JSON.parse(JSON.parse(response.data));
//           console.log(response);
//           this.branchlist = response;
//           this.branchlistlenth=this.branchlist.length
          
//           this.tot_calls = 0;

//           this.branchlist.forEach(element => {
//             this.tot_calls += element.Calls;
//           });
        
//       // this.mangermap =response;
//       })
    
//     } else
//     //  if(this.UserType == '17')
//     {
//       var data = {
//         BranchName: window.localStorage['BranchDescription'],
//         BranchCode: window.localStorage['branchCode'],
//         BranchId: window.localStorage['branchID']
//       }
//        this.openrdmbranchcall(data);
//     }
//   }else{
//       // alert('Difference in dates should not exceed 31 days');
//       this.alert.presentAlert("","Difference in dates should not exceed 31 days")
      
//   }
//   }else{
//       //Do Nothing
//      this.alert.presentAlert("","Choose date")
//       // return false
//   }
//   }
// }

}
