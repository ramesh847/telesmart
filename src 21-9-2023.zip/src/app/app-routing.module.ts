import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'forgotpwd',
    loadChildren: () => import('./forgotpwd/forgotpwd.module').then( m => m.ForgotpwdPageModule)
  },
  {
    path: 'notification',
    loadChildren: () => import('./notification/notification.module').then( m => m.NotificationPageModule)
  },
  {
    path: 'userprofile',
    loadChildren: () => import('./userprofile/userprofile.module').then( m => m.UserprofilePageModule)
  },
  {
    path: 'entryscreen',
    loadChildren: () => import('./entryscreen/entryscreen.module').then( m => m.EntryscreenPageModule)
  },
  {
    path: 'mystarcustomers',
    loadChildren: () => import('./mystarcustomers/mystarcustomers.module').then( m => m.MystarcustomersPageModule)
  },
  {
    path: 'zerostarcustomers',
    loadChildren: () => import('./zerostarcustomers/zerostarcustomers.module').then( m => m.ZerostarcustomersPageModule)
  },
  {
    path: 'mysmacustomers',
    loadChildren: () => import('./mysmacustomers/mysmacustomers.module').then( m => m.MysmacustomersPageModule)
  },
  {
    path: 'mynpacustomers',
    loadChildren: () => import('./mynpacustomers/mynpacustomers.module').then( m => m.MynpacustomersPageModule)
  },
  {
    path: 'demandcollection',
    loadChildren: () => import('./demandcollection/demandcollection.module').then( m => m.DemandcollectionPageModule)
  },
  {
    path: 'otheraccounts',
    loadChildren: () => import('./otheraccounts/otheraccounts.module').then( m => m.OtheraccountsPageModule)
  },
  {
    path: 'unitvisitreport',
    loadChildren: () => import('./unitvisitreport/unitvisitreport.module').then( m => m.UnitvisitreportPageModule)
  },
  {
    path: 'uvrsection',
    loadChildren: () => import('./uvrsection/uvrsection.module').then( m => m.UvrsectionPageModule)
  },
  {
    path: 'uvrsectionhistory',
    loadChildren: () => import('./uvrsectionhistory/uvrsectionhistory.module').then( m => m.UvrsectionhistoryPageModule)
  },
  {
    path: 'uvrallsection',
    loadChildren: () => import('./uvrallsection/uvrallsection.module').then( m => m.UvrallsectionPageModule)
  },
  {
    path: 'uvrpof',
    loadChildren: () => import('./uvrpof/uvrpof.module').then( m => m.UvrpofPageModule)
  },
  {
    path: 'modalmycustomer',
    loadChildren: () => import('./modal/modalmycustomer/modalmycustomer.module').then( m => m.ModalmycustomerPageModule)
  },
  {
    path: 'myzerocustomermodal',
    loadChildren: () => import('./modal/myzerocustomermodal/myzerocustomermodal.module').then( m => m.MyzerocustomermodalPageModule)
  },
  {
    path: 'followup-leads',
    loadChildren: () => import('./followup-leads/followup-leads.module').then( m => m.FollowupLeadsPageModule)
  },
  {
    path: 'express-leads',
    loadChildren: () => import('./express-leads/express-leads.module').then( m => m.ExpressLeadsPageModule)
  },
  {
    path: 'rtgs-neft',
    loadChildren: () => import('./rtgs-neft/rtgs-neft.module').then( m => m.RTGSNEFTPageModule)
  },
  {
    path: 'mysmacustomermodal',
    loadChildren: () => import('./modal/mysmacustomermodal/mysmacustomermodal.module').then( m => m.MysmacustomermodalPageModule)
  },
  {
    path: 'my-npacustomermodal',
    loadChildren: () => import('./modal/my-npacustomermodal/my-npacustomermodal.module').then( m => m.MyNPAcustomermodalPageModule)
  },
  {
    path: 'demandcollectionmodal',
    loadChildren: () => import('./modal/demandcollectionmodal/demandcollectionmodal.module').then( m => m.DemandcollectionmodalPageModule)
  },
  {
    path: 'otheraccountmodal',
    loadChildren: () => import('./modal/otheraccountmodal/otheraccountmodal.module').then( m => m.OtheraccountmodalPageModule)
  },
  {
    path: 'expressleadmodal',
    loadChildren: () => import('./modal/expressleadmodal/expressleadmodal.module').then( m => m.ExpressleadmodalPageModule)
  },
  {
    path: 'rtgs-neftmodal',
    loadChildren: () => import('./modal/rtgs-neftmodal/rtgs-neftmodal.module').then( m => m.RtgsNeftmodalPageModule)
  },
  {
    path: 'mywishaddcustomer',
    loadChildren: () => import('./mywishaddcustomer/mywishaddcustomer.module').then( m => m.MywishaddcustomerPageModule)
  },
  {
    path: 'mywishprimarycustomer',
    loadChildren: () => import('./mywishprimarycustomer/mywishprimarycustomer.module').then( m => m.MywishprimarycustomerPageModule)
  },
  {
    path: 'mywishsecondarycustomer',
    loadChildren: () => import('./mywishsecondarycustomer/mywishsecondarycustomer.module').then( m => m.MywishsecondarycustomerPageModule)
  },
  {
    path: 'mywishfollowup',
    loadChildren: () => import('./mywishfollowup/mywishfollowup.module').then( m => m.MywishfollowupPageModule)
  },
  {
    path: 'mywishconversions',
    loadChildren: () => import('./mywishconversions/mywishconversions.module').then( m => m.MywishconversionsPageModule)
  },
  {
    path: 'myassigncallmodal',
    loadChildren: () => import('./modal/myassigncallmodal/myassigncallmodal.module').then( m => m.MyassigncallmodalPageModule)
  },
  {
    path: 'myfollowupcallmodal',
    loadChildren: () => import('./modal/myfollowupcallmodal/myfollowupcallmodal.module').then( m => m.MyfollowupcallmodalPageModule)
  },
  {
    path: 'mydiary',
    loadChildren: () => import('./mydiary/mydiary.module').then( m => m.MydiaryPageModule)
  },
  // {
  //   path: 'exceptionreport',
  //   loadChildren: () => import('./exceptionreport/exceptionreport.module').then( m => m.ExceptionreportPageModule)
  // },
  {
    path: 'myassignedcall',
    loadChildren: () => import('./myassignedcall/myassignedcall.module').then( m => m.MyassignedcallPageModule)
  },
  {
    path: 'myfollowupcall',
    loadChildren: () => import('./myfollowupcall/myfollowupcall.module').then( m => m.MyfollowupcallPageModule)
  },
  {
    path: 'commoncall',
    loadChildren: () => import('./commoncall/commoncall.module').then( m => m.CommoncallPageModule)
  },
  {
    path: 'commoncallmodal',
    loadChildren: () => import('./modal/commoncallmodal/commoncallmodal.module').then( m => m.CommoncallmodalPageModule)
  },
  {
    path: 'addinsurance',
    loadChildren: () => import('./addinsurance/addinsurance.module').then( m => m.AddinsurancePageModule)
  },
  {
    path: 'insurancecustomer',
    loadChildren: () => import('./insurancecustomer/insurancecustomer.module').then( m => m.InsurancecustomerPageModule)
  },
  {
    path: 'followupleadmodal',
    loadChildren: () => import('./modal/followupleadmodal/followupleadmodal.module').then( m => m.FollowupleadmodalPageModule)
  },
  {
    path: 'myassignedvisits',
    loadChildren: () => import('./myassignedvisits/myassignedvisits.module').then( m => m.MyassignedvisitsPageModule)
  },
  {
    path: 'myfollowupvisits',
    loadChildren: () => import('./myfollowupvisits/myfollowupvisits.module').then( m => m.MyfollowupvisitsPageModule)
  },
  
// ramesh code?

{
  path: 'myassignedvisits',
  loadChildren: () => import('./myassignedvisits/myassignedvisits.module').then( m => m.MyassignedvisitsPageModule)
},
{
  path: 'myfollowupvisitmodal',
  loadChildren: () => import('./modal/myfollowupvisitmodal/myfollowupvisitmodal.module').then( m => m.MyfollowupvisitmodalPageModule)
},
{
  path: 'myfollowupvisitendmodel',
  loadChildren: () => import('./modal/myfollowupvisitendmodel/myfollowupvisitendmodel.module').then( m => m.MyfollowupvisitendmodelPageModule)
},
{
  path: 'commonvisit-update-modal',
  loadChildren: () => import('./modal/commonvisit-update-modal/commonvisit-update-modal.module').then( m => m.CommonvisitUpdateModalPageModule)
},
{
  path: 'commonvisit',
  loadChildren: () => import('./commonvisit/commonvisit.module').then( m => m.CommonvisitPageModule)
},
{
  path: 'performancedashboard',
  loadChildren: () => import('./performancedashboard/performancedashboard.module').then( m => m.PerformancedashboardPageModule)
},

{
  path: 'performancedashboardmodal',
  loadChildren: () => import('./modal/performancedashboardmodal/performancedashboardmodal.module').then( m => m.PerformancedashboardmodalPageModule)
},
{
  path: 'commonvisit',
  loadChildren: () => import('./commonvisit/commonvisit.module').then( m => m.CommonvisitPageModule)
},
{
  path: 'assignedvisitupdatemodal',
  loadChildren: () => import('./modal/assignedvisitupdatemodal/assignedvisitupdatemodal.module').then( m => m.AssignedvisitupdatemodalPageModule)
},
{
  path: 'assignedvisithistorymodal',
  loadChildren: () => import('./modal/assignedvisithistorymodal/assignedvisithistorymodal.module').then( m => m.AssignedvisithistorymodalPageModule)
},
  {
    path: 'heatmap',
    loadChildren: () => import('./heatmap/heatmap.module').then( m => m.HeatmapPageModule)
  },
  {
    path: 'myfollowupcallconnect',
    loadChildren: () => import('./modal/myfollowupcallconnect/myfollowupcallconnect.module').then( m => m.MyfollowupcallconnectPageModule)
  },
  {
  path: 'exceptionreport',
  loadChildren: () => import('./exceptionreport/exceptionreport.module').then( m => m.ExceptionreportPageModule)
  },
  {
    path: 'myplanner',
    loadChildren: () => import('./myplanner/myplanner.module').then( m => m.MyplannerPageModule)
  },
  {
    path: 'myplanner/:id',
    loadChildren: () => import('./myplanner/myplanner.module').then( m => m.MyplannerPageModule)
  },
  {
    path: 'mywishsecondarymodal',
    loadChildren: () => import('./modal/mywishsecondarymodal/mywishsecondarymodal.module').then( m => m.MywishsecondarymodalPageModule)
  },
  {
    path: 'mywishprimarymodal',
    loadChildren: () => import('./modal/mywishprimarymodal/mywishprimarymodal.module').then( m => m.MywishprimarymodalPageModule)
  },
  {
    path: 'mywishfollowupmodal',
    loadChildren: () => import('./modal/mywishfollowupmodal/mywishfollowupmodal.module').then( m => m.MywishfollowupmodalPageModule)
  },
  {
    path: 'mylink',
    loadChildren: () => import('./mylink/mylink.module').then( m => m.MylinkPageModule)
  },
  {
    path: 'heatmapstaff',
    loadChildren: () => import('./heatmapstaff/heatmapstaff.module').then( m => m.HeatmapstaffPageModule)
  },
  {
    path: 'goalsheet',
    loadChildren: () => import('./goalsheet/goalsheet.module').then( m => m.GoalsheetPageModule)
  },
  {
    path: 'diarycalenderdistribution',
    loadChildren: () => import('./diarycalenderdistribution/diarycalenderdistribution.module').then( m => m.DiarycalenderdistributionPageModule)
  },
  {
    path: 'diarycalenderd-assigned-customer',
    loadChildren: () => import('./diarycalenderd-assigned-customer/diarycalenderd-assigned-customer.module').then( m => m.DiarycalenderdAssignedCustomerPageModule)
  },
  {
    path: 'diarycalenderd-view-reports',
    loadChildren: () => import('./diarycalenderd-view-reports/diarycalenderd-view-reports.module').then( m => m.DiarycalenderdViewReportsPageModule)
  },
  {
    path: 'diarycalenderd-other-customers',
    loadChildren: () => import('./diarycalenderd-other-customers/diarycalenderd-other-customers.module').then( m => m.DiarycalenderdOtherCustomersPageModule)
  },
  {
    path: 'diarywishlist',
    loadChildren: () => import('./diarywishlist/diarywishlist.module').then( m => m.DiarywishlistPageModule)
  },
  {
    path: 'myplannerupdate',
    loadChildren: () => import('./modal/myplannerupdate/myplannerupdate.module').then( m => m.MyplannerupdatePageModule)
  },
  {
    path: 'todayassignedupdatemodal',
    loadChildren: () => import('./modal/todayassignedupdatemodal/todayassignedupdatemodal.module').then( m => m.TodayassignedupdatemodalPageModule)
  },
  {
    path: 'planeercallconnect',
    loadChildren: () => import('./modal/myplannerupdate/planeercallconnect/planeercallconnect.module').then( m => m.PlaneercallconnectPageModule)
  },
  {
    path: 'regionsummary',
    loadChildren: () => import('./regionsummary/regionsummary.module').then( m => m.RegionsummaryPageModule)
  },

  {
    path: 'newsummary',
    loadChildren: () => import('./newsummary/newsummary.module').then( m => m.NewsummaryPageModule)
  },
  {
    path: 'regiongoalsheet',
    loadChildren: () => import('./regiongoalsheet/regiongoalsheet.module').then( m => m.RegiongoalsheetPageModule)
  },
  {
    path: 'regionstarcustomer',
    loadChildren: () => import('./regionstarcustomer/regionstarcustomer.module').then( m => m.RegionstarcustomerPageModule)
  },
  {
    path: 'clicktocallcustomer',
    loadChildren: () => import('./clicktocallcustomer/clicktocallcustomer.module').then( m => m.ClicktocallcustomerPageModule)
  },
  {
    path: 'regionreport',
    loadChildren: () => import('./regionreport/regionreport.module').then( m => m.RegionreportPageModule)
  },
  {
    path: 'rdmplanner',
    loadChildren: () => import('./rdmplanner/rdmplanner.module').then( m => m.RdmplannerPageModule)
  },
  {
    path: 'rdmleadlelecall',
    loadChildren: () => import('./rdmleadlelecall/rdmleadlelecall.module').then( m => m.RdmleadlelecallPageModule)
  },
  {
    path: 'regionheatmap',
    loadChildren: () => import('./regionheatmap/regionheatmap.module').then( m => m.RegionheatmapPageModule)
  },
  {
    path: 'managergoalsheet',
    loadChildren: () => import('./managergoalsheet/managergoalsheet.module').then( m => m.ManagergoalsheetPageModule)
  },
  {
    path: 'branchgoalsheet',
    loadChildren: () => import('./modal/branchgoalsheet/branchgoalsheet.module').then( m => m.BranchgoalsheetPageModule)
  },
  {
    path: 'managermycustomer',
    loadChildren: () => import('./managermycustomer/managermycustomer.module').then( m => m.ManagermycustomerPageModule)
  },
  {
    path: 'mycustomerlist',
    loadChildren: () => import('./mycustomerlist/mycustomerlist.module').then( m => m.MycustomerlistPageModule)
  },
  {
    path: 'rdm-clicktocall',
    loadChildren: () => import('./rdm-clicktocall/rdm-clicktocall.module').then( m => m.RdmClicktocallPageModule)
  },
  {
    path: 'rdmbranchcall',
    loadChildren: () => import('./modal/rdmbranchcall/rdmbranchcall.module').then( m => m.RDMbranchcallPageModule)
  },
  {
    path: 'branchempcalldetails',
    loadChildren: () => import('./modal/branchempcalldetails/branchempcalldetails.module').then( m => m.BranchempcalldetailsPageModule)
  },
  {
    path: 'branchempdetail',
    loadChildren: () => import('./modal/branchempdetail/branchempdetail.module').then( m => m.BranchempdetailPageModule)
  },
  {
    path: 'rdmbranch-employees',
    loadChildren: () => import('./modal/rdmbranch-employees/rdmbranch-employees.module').then( m => m.RDMbranchEmployeesPageModule)
  },
  {
    path: 'rdmemployee-customer',
    loadChildren: () => import('./modal/rdmemployee-customer/rdmemployee-customer.module').then( m => m.RDMEmployeeCustomerPageModule)
  },
  {
    path: 'rdmplan-update',
    loadChildren: () => import('./rdmplan-update/rdmplan-update.module').then( m => m.RDMplanUpdatePageModule)
  },
  {
    path: 'branchwisedetails',
    loadChildren: () => import('./modal/branchwisedetails/branchwisedetails.module').then( m => m.BranchwisedetailsPageModule)
  },
  {
    path: 'empnamewisedetails',
    loadChildren: () => import('./modal/empnamewisedetails/empnamewisedetails.module').then( m => m.EmpnamewisedetailsPageModule)
  },
  {
    path: 'check',
    loadChildren: () => import('./modal/check/check.module').then( m => m.CheckPageModule)
  },
  {
    path: 'calendar-diary',
    loadChildren: () => import('./calendar-diary/calendar-diary.module').then( m => m.CalendarDiaryPageModule)
  },
  {
    path: 'rmcust-view',
    loadChildren: () => import('./modal/rmcust-view/rmcust-view.module').then( m => m.RMCustViewPageModule)
  },
  {
    path: 'view-report',
    loadChildren: () => import('./modal/view-report/view-report.module').then( m => m.ViewReportPageModule)
  },
  {
    path: 'pending-report',
    loadChildren: () => import('./modal/pending-report/pending-report.module').then( m => m.PendingReportPageModule)
  },
  {
    path: 'wish-pending-report',
    loadChildren: () => import('./modal/wish-pending-report/wish-pending-report.module').then( m => m.WishPendingReportPageModule)
  },
  {
    path: 'view-report-branch',
    loadChildren: () => import('./modal/view-report-branch/view-report-branch.module').then( m => m.ViewReportBranchPageModule)
  },
  {
    path: 'dairybranchsummary',
    loadChildren: () => import('./modal/dairybranchsummary/dairybranchsummary.module').then( m => m.DairybranchsummaryPageModule)
  },
  {
    path: 'branchreportsummary',
    loadChildren: () => import('./modal/branchreportsummary/branchreportsummary.module').then( m => m.BranchreportsummaryPageModule)
  },
  {
    path: 'branchreportbrange',
    loadChildren: () => import('./modal/branchreportbrange/branchreportbrange.module').then( m => m.BranchreportbrangePageModule)
  },
  {
    path: 'branchsummarypending',
    loadChildren: () => import('./modal/branchsummarypending/branchsummarypending.module').then( m => m.BranchsummarypendingPageModule)
  },
  {
    path: 'summarywishlist',
    loadChildren: () => import('./modal/summarywishlist/summarywishlist.module').then( m => m.SummarywishlistPageModule)
  },
  {
    path: 'managerheatmap',
    loadChildren: () => import('./managerheatmap/managerheatmap.module').then( m => m.ManagerheatmapPageModule)
  },
  {
    path: 'managerheatmapdetail',
    loadChildren: () => import('./modal/managerheatmapdetail/managerheatmapdetail.module').then( m => m.ManagerheatmapdetailPageModule)
  },
  {
    path: 'mydiarybranch',
    loadChildren: () => import('./mydiarybranch/mydiarybranch.module').then( m => m.MydiarybranchPageModule)
  },
  {
    path: 'diarybranchuserdetails',
    loadChildren: () => import('./modal/diarybranchuserdetails/diarybranchuserdetails.module').then( m => m.DiarybranchuserdetailsPageModule)
  },
  {
    path: 'monthlyuserdetails',
    loadChildren: () => import('./modal/monthlyuserdetails/monthlyuserdetails.module').then( m => m.MonthlyuserdetailsPageModule)
  },
  {
    path: 'dairyuserdetailscheck',
    loadChildren: () => import('./modal/dairyuserdetailscheck/dairyuserdetailscheck.module').then( m => m.DairyuserdetailscheckPageModule)
  },
  {
    path: 'checkmanagerheatmap',
    loadChildren: () => import('./checkmanagerheatmap/checkmanagerheatmap.module').then( m => m.CheckmanagerheatmapPageModule)
  },
  {
    path: 'checkrmcustview',
    loadChildren: () => import('./modal/checkrmcustview/checkrmcustview.module').then( m => m.CheckrmcustviewPageModule)
  },
  {
    path: 'assignedcommonupdate',
    loadChildren: () => import('./modal/assignedcommonupdate/assignedcommonupdate.module').then( m => m.AssignedcommonupdatePageModule)
  },
  {
    path: 'commoncallconnect',
    loadChildren: () => import('./modal/commoncallconnect/commoncallconnect.module').then( m => m.CommoncallconnectPageModule)
  },
  {
    path: 'checkmyplanner',
    loadChildren: () => import('./checkmyplanner/checkmyplanner.module').then( m => m.CheckmyplannerPageModule)
  },
  {
    path: 'assigncallconnect',
    loadChildren: () => import('./modal/assigncallconnect/assigncallconnect.module').then( m => m.AssigncallconnectPageModule)
  },
  {
    path: 'assignvisitcallconnect',
    loadChildren: () => import('./modal/assignvisitcallconnect/assignvisitcallconnect.module').then( m => m.AssignvisitcallconnectPageModule)
  },
  {
    path: 'commonvisitcallconnect',
    loadChildren: () => import('./modal/commonvisitcallconnect/commonvisitcallconnect.module').then( m => m.CommonvisitcallconnectPageModule)
  },
  {
    path: 'followupleadcallconnect',
    loadChildren: () => import('./modal/followupleadcallconnect/followupleadcallconnect.module').then( m => m.FollowupleadcallconnectPageModule)
  },
  {
    path: 'expressleadcallconnect',
    loadChildren: () => import('./modal/expressleadcallconnect/expressleadcallconnect.module').then( m => m.ExpressleadcallconnectPageModule)
  },
  {
    path: 'rtgsneftcallconnect',
    loadChildren: () => import('./modal/rtgsneftcallconnect/rtgsneftcallconnect.module').then( m => m.RtgsneftcallconnectPageModule)
  },
  {
    path: 'mystarcallconnect',
    loadChildren: () => import('./modal/mystarcallconnect/mystarcallconnect.module').then( m => m.MystarcallconnectPageModule)
  },
  {
    path: 'zerocallconnect',
    loadChildren: () => import('./modal/zerocallconnect/zerocallconnect.module').then( m => m.ZerocallconnectPageModule)
  },
  {
    path: 'mysmacallconnect',
    loadChildren: () => import('./modal/mysmacallconnect/mysmacallconnect.module').then( m => m.MysmacallconnectPageModule)
  },
  {
    path: 'mynpacallconnect',
    loadChildren: () => import('./modal/mynpacallconnect/mynpacallconnect.module').then( m => m.MynpacallconnectPageModule)
  },
  {
    path: 'demandcallconnect',
    loadChildren: () => import('./modal/demandcallconnect/demandcallconnect.module').then( m => m.DemandcallconnectPageModule)
  },
  {
    path: 'otheraccountcallconnect',
    loadChildren: () => import('./modal/otheraccountcallconnect/otheraccountcallconnect.module').then( m => m.OtheraccountcallconnectPageModule)
  },
  {
    path: 'myplanercallconnect',
    loadChildren: () => import('./modal/myplanercallconnect/myplanercallconnect.module').then( m => m.MyplanercallconnectPageModule)
  },
  {
    path: 'primarycallconnect',
    loadChildren: () => import('./modal/primarycallconnect/primarycallconnect.module').then( m => m.PrimarycallconnectPageModule)
  },
  {
    path: 'secondarycallconnect',
    loadChildren: () => import('./modal/secondarycallconnect/secondarycallconnect.module').then( m => m.SecondarycallconnectPageModule)
  },
  {
    path: 'mywishfollowupcallconnect',
    loadChildren: () => import('./modal/mywishfollowupcallconnect/mywishfollowupcallconnect.module').then( m => m.MywishfollowupcallconnectPageModule)
  },
  {
    path: 'senderdetails',
    loadChildren: () => import('./modal/senderdetails/senderdetails.module').then( m => m.SenderdetailsPageModule)
  },
  {
    path: 'courtesycallentry',
    loadChildren: () => import('./courtesycallentry/courtesycallentry.module').then( m => m.CourtesycallentryPageModule)
  },
  {
    path: 'rooted',
    loadChildren: () => import('./rooted/rooted.module').then( m => m.RootedPageModule)
  },
  {
    path: 'plannerfollowupmodal',
    loadChildren: () => import('./modal/plannerfollowupmodal/plannerfollowupmodal.module').then( m => m.PlannerfollowupmodalPageModule)
  },
  {
    path: 'managerentry',
    loadChildren: () => import('./managerentry/managerentry.module').then( m => m.ManagerentryPageModule)
  },
  {
    path: 'notificationpopup',
    loadChildren: () => import('./modal/notificationpopup/notificationpopup.module').then( m => m.NotificationpopupPageModule)
  },
  {
    path: 'potentialstar',
    loadChildren: () => import('./potentialstar/potentialstar.module').then( m => m.PotentialstarPageModule)
  },
  {
    path: 'potentiacallconect',
    loadChildren: () => import('./modal/potentiacallconect/potentiacallconect.module').then( m => m.PotentiacallconectPageModule)
  },
  {
    path: 'monthlytelecals',
    loadChildren: () => import('./monthlytelecals/monthlytelecals.module').then( m => m.MonthlytelecalsPageModule)
  },
  {
    path: 'monthlytelecals/:id',
    loadChildren: () => import('./monthlytelecals/monthlytelecals.module').then( m => m.MonthlytelecalsPageModule)
  },
  {
    path: 'monthlyvisits',
    loadChildren: () => import('./monthlyvisits/monthlyvisits.module').then( m => m.MonthlyvisitsPageModule)
  },
  {
    path: 'monthlyvisits/:id',
    loadChildren: () => import('./monthlyvisits/monthlyvisits.module').then( m => m.MonthlyvisitsPageModule)
  },
  {
    path: 'monthlyplannerstarcall',
    loadChildren: () => import('./monthlyplannerstarcall/monthlyplannerstarcall.module').then( m => m.MonthlyplannerstarcallPageModule)
  },
  {
    path: 'monthlyplannernpacall',
    loadChildren: () => import('./modal/monthlyplannernpacall/monthlyplannernpacall.module').then( m => m.MonthlyplannernpacallPageModule)
  },
  {
    path: 'monthlyplannerothercall',
    loadChildren: () => import('./modal/monthlyplannerothercall/monthlyplannerothercall.module').then( m => m.MonthlyplannerothercallPageModule)
  },
  {
    path: 'mplannerrtgscallconnect',
    loadChildren: () => import('./modal/mplannerrtgscallconnect/mplannerrtgscallconnect.module').then( m => m.MplannerrtgscallconnectPageModule)
  },
  {
    path: 'advancecommitment',
    loadChildren: () => import('./advancecommitment/advancecommitment.module').then( m => m.AdvancecommitmentPageModule)
  },
  {
    path: 'rdmadvancecommitment',
    loadChildren: () => import('./rdmadvancecommitment/rdmadvancecommitment.module').then( m => m.RdmadvancecommitmentPageModule)
  },
  {
    path: 'rdmadvancecommitment/:id',
    loadChildren: () => import('./rdmadvancecommitment/rdmadvancecommitment.module').then( m => m.RdmadvancecommitmentPageModule)
  },
  {
    path: 'advancecommitmentsummary',
    loadChildren: () => import('./advancecommitmentsummary/advancecommitmentsummary.module').then( m => m.AdvancecommitmentsummaryPageModule)
  },
  {
    path: 'myplannerconnectcall',
    loadChildren: () => import('./myplannerconnectcall/myplannerconnectcall.module').then( m => m.MyplannerconnectcallPageModule)
  },  {
    path: 'newnotification',
    loadChildren: () => import('./newnotification/newnotification.module').then( m => m.NewnotificationPageModule)
  },
  {
    path: 'trialnotify',
    loadChildren: () => import('./trialnotify/trialnotify.module').then( m => m.TrialnotifyPageModule)
  },
  {
    path: 'visitenrty',
    loadChildren: () => import('./visitenrty/visitenrty.module').then( m => m.VisitenrtyPageModule)
  },
  {
    path: 'addcustomer',
    loadChildren: () => import('./addcustomer/addcustomer.module').then( m => m.AddcustomerPageModule)
  },
  {
    path: 'pfdshow',
    loadChildren: () => import('./pfdshow/pfdshow.module').then( m => m.PfdshowPageModule)
  },
  {
    path: 'viewpdf',
    loadChildren: () => import('./viewpdf/viewpdf.module').then( m => m.ViewpdfPageModule)
  },
  {
    path: 'sessionout',
    loadChildren: () => import('./sessionout/sessionout.module').then( m => m.SessionoutPageModule)
  },
  {
    path: 'fingureprint',
    loadChildren: () => import('./fingureprint/fingureprint.module').then( m => m.FingureprintPageModule)
  },
  {
    path: 'pdfview',
    loadChildren: () => import('./pdfview/pdfview.module').then( m => m.PdfviewPageModule)
  },
  {
    path: 'startuppage',
    loadChildren: () => import('./startuppage/startuppage.module').then( m => m.StartuppagePageModule)
  },
  {
    path: 'visitreport',
    loadChildren: () => import('./visitreport/visitreport.module').then( m => m.VisitreportPageModule)
  },
  {
    path: 'reportstarwishnew',
    loadChildren: () => import('./reportstarwishnew/reportstarwishnew.module').then( m => m.ReportstarwishnewPageModule)
  },
  {
    path: 'visitnumberofvisit',
    loadChildren: () => import('./visitnumberofvisit/visitnumberofvisit.module').then( m => m.VisitnumberofvisitPageModule)
  },
  {
    path: 'menucomponent',
    loadChildren: () => import('./menucomponent/menucomponent.module').then( m => m.MenucomponentPageModule)
  },
  {
    path: 'monthlynpaplannerclicktocall',
    loadChildren: () => import('./monthlynpaplannerclicktocall/monthlynpaplannerclicktocall.module').then( m => m.MonthlynpaplannerclicktocallPageModule)
  },
  {
    path: 'insurancehistory',
    loadChildren: () => import('./insurancehistory/insurancehistory.module').then( m => m.InsurancehistoryPageModule)
  },
  {
    path: 'insurancehistorypopup',
    loadChildren: () => import('./insurancehistorypopup/insurancehistorypopup.module').then( m => m.InsurancehistorypopupPageModule)
  },
  {
    path: 'poster',
    loadChildren: () => import('./poster/poster.module').then( m => m.PosterPageModule)
  },

 
  










];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
