import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FingureprintPageRoutingModule } from './fingureprint-routing.module';

import { FingureprintPage } from './fingureprint.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FingureprintPageRoutingModule
  ],
  declarations: [FingureprintPage]
})
export class FingureprintPageModule {}
