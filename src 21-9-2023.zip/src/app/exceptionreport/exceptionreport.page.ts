import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../service/api-service.service';
import {Router } from '@angular/router';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
@Component({
  selector: 'app-exceptionreport',
  templateUrl: './exceptionreport.page.html',
  styleUrls: ['./exceptionreport.page.scss'],
  providers:[Idle]
})

export class ExceptionreportPage implements OnInit {
  ecode: any;
  ename: any;
  ebranch: any;
  ebranchname: any;
  edate: any;
  userid: any;
  branchid: any;
  userType: any;
  myexceptions: any = [];
  exceptions: any = [];
  idleState: string;
  constructor(private router: Router,private apiservice: ApiServiceService,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
      {
        let idleState = countdown
        let minutes = Math.floor((idleState)/ 60);
        let extraSeconds = (idleState) % 60;
       let minutes1 = minutes < 10 ? "0" + minutes : minutes;
       let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
       this.idleState=minutes1 +':'+ extraSeconds1
       console.log(this.idleState)
      }
        // (this.idleState = countdown.toString() )
    );}

  ngOnInit() {
debugger
    this.ecode = localStorage.getItem('userCode');
    this.ename = localStorage.getItem('userName');
    this.ebranch = localStorage.getItem('branchCode');
    this.ebranchname = localStorage.getItem('BranchDescription');
    console.log( this.ecode, this.ename,this.ebranch, this.ebranchname )
    var d = new Date();
    this.edate = (d.setDate(d.getDate() - 1));
    this.getexception();
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  getexception() {
    debugger
    // this.showspin();
    this.userid = window.localStorage['userID'];
    this.branchid = window.localStorage['branchID'];
    this.userType = window.localStorage['userType'];
    console.log("usertype",this.userType)
    this.apiservice.Exception_visitinsert(this.branchid, this.userid).then(response => {
      debugger
        console.log(response)
    })

    if (this.userType == 17) {
       this.apiservice.Exception_Mgr(this.branchid).then(response => {
        console.log(response);
        //  this.hidespin();
        var user = JSON.stringify(response.data);
        this.exceptions = JSON.parse(user);
        this.exceptions = JSON.parse(this.exceptions);
        this.exceptions = JSON.parse(this.exceptions);
        this.exceptions = this.exceptions.Table;
        // response = JSON.parse(response);

        // this.exceptions = response.Table;
        this.exceptions.forEach((element, i) => {
          var trailingCharsIntactCount = 3;

          this.exceptions[i].AccountNumber = new Array(element.AccountNumber.length - trailingCharsIntactCount + 1).join('x')
            + element.AccountNumber.slice(-trailingCharsIntactCount);

        })
        this.exceptions = this.groupBy(this.exceptions, 'ExceptionType');
        console.log(this.exceptions);
        this.myexceptions = [];
        this.exceptions.forEach((element) => {
          if (element[0].ExceptionType == 'OVRD') this.myexceptions.push({ type: 'OVRD', data: element });
          if (element[0].ExceptionType == 'DEPC') this.myexceptions.push({ type: 'DEPC', data: element });
          if (element[0].ExceptionType == 'OPEN') this.myexceptions.push({ type: 'OPEN', data: element });
          if (element[0].ExceptionType == 'DACT') this.myexceptions.push({ type: 'DACT', data: element });
          if (element[0].ExceptionType == 'NRIO') this.myexceptions.push({ type: 'NRIO', data: element });
          if (element[0].ExceptionType == 'NRIC') this.myexceptions.push({ type: 'NRIC', data: element });
          if (element[0].ExceptionType == 'ODBD') this.myexceptions.push({ type: 'ODBD', data: element });
          if (element[0].ExceptionType == 'LADM') this.myexceptions.push({ type: 'LADM', data: element });
          if (element[0].ExceptionType == 'SBNE') this.myexceptions.push({ type: 'SBNE', data: element });
          if (element[0].ExceptionType == 'ABRC') this.myexceptions.push({ type: 'ABRC', data: element });
          if (element[0].ExceptionType == 'OPER') this.myexceptions.push({ type: 'OPER', data: element });
          if (element[0].ExceptionType == 'CASI') this.myexceptions.push({ type: 'CASI', data: element });
          if (element[0].ExceptionType == 'CASD') this.myexceptions.push({ type: 'CASD', data: element });
          if (element[0].ExceptionType == 'THRL') this.myexceptions.push({ type: 'THRL', data: element });
          if (element[0].ExceptionType == 'LNAR') this.myexceptions.push({ type: 'LNAR', data: element });
          if (element[0].ExceptionType == 'TODE') this.myexceptions.push({ type: 'TODE', data: element });
          if (element[0].ExceptionType == 'DPBL') this.myexceptions.push({ type: 'DPBL', data: element });
          if (element[0].ExceptionType == 'LLOS') this.myexceptions.push({ type: 'LLOS', data: element });
          if (element[0].ExceptionType == 'CLOS') this.myexceptions.push({ type: 'CLOS', data: element });
          if (element[0].ExceptionType == 'NEFA') this.myexceptions.push({ type: 'NEFA', data: element });
          if (element[0].ExceptionType == 'OUTC') this.myexceptions.push({ type: 'OUTC', data: element });
          if (element[0].ExceptionType == 'ACTD') this.myexceptions.push({ type: 'ACTD', data: element });
          if (element[0].ExceptionType == 'RTGA') this.myexceptions.push({ type: 'RTGA', data: element });
        });
        console.log('dddd',this.myexceptions);
      })

    } 
    else {
       this.apiservice.Exception_Staff(this.userid).then(response => {
        console.log(response);
        // this.hidespin();
       var responseValue = JSON.stringify(response.data);
       responseValue = JSON.parse(responseValue);
       responseValue = JSON.parse(responseValue);
       responseValue = JSON.parse(responseValue);
       console.log(responseValue['Table']);
        this.exceptions = responseValue['Table'];
        this.exceptions.forEach((element, i) => {
          var trailingCharsIntactCount = 3;

          this.exceptions[i].AccountNumber = new Array(element.AccountNumber.length - trailingCharsIntactCount + 1).join('x')
            + element.AccountNumber.slice(-trailingCharsIntactCount);

        })
        this.exceptions = this.groupBy(this.exceptions, 'ExceptionType');
        console.log(this.exceptions);
        this.myexceptions = [];
        this.exceptions.forEach((element) => {
          if (element[0].ExceptionType == 'OVRD') this.myexceptions.push({ type: 'OVRD', data: element });
          if (element[0].ExceptionType == 'DEPC') this.myexceptions.push({ type: 'DEPC', data: element });
          if (element[0].ExceptionType == 'OPEN') this.myexceptions.push({ type: 'OPEN', data: element });
          if (element[0].ExceptionType == 'DACT') this.myexceptions.push({ type: 'DACT', data: element });
          if (element[0].ExceptionType == 'NRIO') this.myexceptions.push({ type: 'NRIO', data: element });
          if (element[0].ExceptionType == 'NRIC') this.myexceptions.push({ type: 'NRIC', data: element });
          if (element[0].ExceptionType == 'ODBD') this.myexceptions.push({ type: 'ODBD', data: element });
          if (element[0].ExceptionType == 'LADM') this.myexceptions.push({ type: 'LADM', data: element });
          if (element[0].ExceptionType == 'SBNE') this.myexceptions.push({ type: 'SBNE', data: element });
          if (element[0].ExceptionType == 'ABRC') this.myexceptions.push({ type: 'ABRC', data: element });
          if (element[0].ExceptionType == 'OPER') this.myexceptions.push({ type: 'OPER', data: element });
          if (element[0].ExceptionType == 'CASI') this.myexceptions.push({ type: 'CASI', data: element });
          if (element[0].ExceptionType == 'CASD') this.myexceptions.push({ type: 'CASD', data: element });
          if (element[0].ExceptionType == 'THRL') this.myexceptions.push({ type: 'THRL', data: element });
          if (element[0].ExceptionType == 'LNAR') this.myexceptions.push({ type: 'LNAR', data: element });
          if (element[0].ExceptionType == 'TODE') this.myexceptions.push({ type: 'TODE', data: element });
          if (element[0].ExceptionType == 'DPBL') this.myexceptions.push({ type: 'DPBL', data: element });
          if (element[0].ExceptionType == 'LLOS') this.myexceptions.push({ type: 'LLOS', data: element });
          if (element[0].ExceptionType == 'CLOS') this.myexceptions.push({ type: 'CLOS', data: element });
          if (element[0].ExceptionType == 'NEFA') this.myexceptions.push({ type: 'NEFA', data: element });
          if (element[0].ExceptionType == 'OUTC') this.myexceptions.push({ type: 'OUTC', data: element });
          if (element[0].ExceptionType == 'ACTD') this.myexceptions.push({ type: 'ACTD', data: element });
          if (element[0].ExceptionType == 'RTGA') this.myexceptions.push({ type: 'RTGA', data: element });
        });
        console.log(this.myexceptions);
      })

    }
  }


  groupBy(collection, property) {
    var i = 0, val, index,
        values = [], result = [];
    for (; i < collection.length; i++) {
        val = collection[i][property];
        index = values.indexOf(val);
        if (index > -1){
          result[index].push(collection[i]);
          
        } 
        else {
            values.push(val);
            result.push([collection[i]]);
         
        }
    }
    return result;
}
goToMyplannerPage() {
  if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
    this.router.navigate(['/regionsummary']);
}else
  if(window.localStorage['userType']=='17')
{ this.router.navigate(['/newsummary']);}else{
  this.router.navigateByUrl('/myplanner');
}
  // this.router.navigateByUrl('/myplanner');
}
}

