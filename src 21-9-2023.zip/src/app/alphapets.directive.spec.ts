import { AlphapetsDirective } from './alphapets.directive';

describe('AlphapetsDirective', () => {
  it('should create an instance', () => {
    const directive = new AlphapetsDirective();
    expect(directive).toBeTruthy();
  });
});
