import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';
@Component({
  selector: 'app-insurancecustomer',
  templateUrl: './insurancecustomer.page.html',
  styleUrls: ['./insurancecustomer.page.scss'],
  providers:[Idle]
})
export class InsurancecustomerPage implements OnInit {
  insurCustDataaa: any;
  insuranceCustomerData: any;
  insurancelength: any;
  idleState: string;

  constructor(private Apiservice:ApiServiceService, private loader:ToastServiceService,private router:Router,private idle:Idle) {// sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
      {
        let idleState = countdown
        let minutes = Math.floor((idleState)/ 60);
        let extraSeconds = (idleState) % 60;
       let minutes1 = minutes < 10 ? "0" + minutes : minutes;
       let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
       this.idleState=minutes1 +':'+ extraSeconds1
       console.log(this.idleState)
      }
        // (this.idleState = countdown.toString() )
    ); }

  ngOnInit() {
    this.insuranceGetCustomersData();
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  goToMyplannerPage() {
    if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
      this.router.navigate(['/regionsummary']);
}else
    if(window.localStorage['userType']=='17')
  { this.router.navigate(['/newsummary']);}else{
    this.router.navigateByUrl('/myplanner');
  }
    // this.router.navigateByUrl('/myplanner');

  }
  insuranceGetCustomersData(){
    var BranchId = window.localStorage['branchID'];
    var UserId = window.localStorage['userID'];
    // this.showspin();
   
this.loader.presentLoading('')
 
    this.Apiservice.getInsurancesearch(UserId,BranchId).then((response:any)=>{
      // this.hidespin();
      console.log("insuranceData", response);
      this.loader.dismissLoading();
      var result = response.data;
        result = JSON.parse(result);
if(result == 'No record')
{
  this.insurancelength=0
}else{

        result = JSON.parse(result);
      this.insurCustDataaa =  result;
      // response = JSON.parse(response);
      this.insuranceCustomerData = result;
     this.insurancelength= this.insuranceCustomerData.length
      console.log("customerInsuranceData",this.insuranceCustomerData )
}

    })
  }

  

  

}
