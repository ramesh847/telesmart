import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../service/api-service.service';
import { ModalController } from '@ionic/angular';
import { FollowupleadmodalPage } from '../modal/followupleadmodal/followupleadmodal.page';
import * as moment from "moment"; 
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { EndcallmodalPage } from '../modal/followupleadmodal/endcallmodal/endcallmodal.page';
import { MyfollowupvisitmodalPage } from '../modal/myfollowupvisitmodal/myfollowupvisitmodal.page';
import { Router } from '@angular/router';
import { EndcallmodalPageModule } from '../modal/followupleadmodal/endcallmodal/endcallmodal.module';
import { ToastServiceService } from '../service/toast-service.service';
import { AlertServiceService } from '../service/alert-service.service';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
// import {MyfollowupcallconnectPage}  from './../modal/myfollowupcallconnect/myfollowupcallconnect.page'
@Component({
  selector: 'app-followup-leads',
  templateUrl: './followup-leads.page.html',
  styleUrls: ['./followup-leads.page.scss'],
  providers:[Idle]
})
export class FollowupLeadsPage implements OnInit {
  myleadscreenlist: any;
  startleadtime: string;
  DisLat: any;
  DisLong: any;
  Inlatlng: any;
  distanceInMeter: number;
  endleadtime: string;
  myleadlength: any;
  search:any={}
  CUSTOMER_ID:any;
  UpdatedOn:any;
  businessunitlist: any;
  idleState: string;
  getnummmm:any;

  constructor(private loader:ToastServiceService,private geolocation: Geolocation,
    private modalController:ModalController,private Apiservice:ApiServiceService,
    private router:Router,public alertservice:AlertServiceService,private idle:Idle) {// sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>{
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    debugger
    this.getbusinessunit()
    this.displaylead();
    // this.reset()
  }
  clicknumberstar(num:any){
    debugger
   this.getnummmm= this.Apiservice.firstfivexxxx(num)
  }
  reset(){
    this.idle.watch()
  }
  searchMyLeads (BusinessUnit,customerid) {
    // $scope.showspin();
    debugger
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    if(BusinessUnit == "" ||BusinessUnit == "undefined"||BusinessUnit == undefined){
      BusinessUnit= 0;
    }
    if(customerid == ""||customerid == "undefined"||customerid == undefined){
      customerid= 0;
    }
    this.loader.presentLoadingassign('')
    this.Apiservice.myleadscreen(userid, branchid, customerid, BusinessUnit)
      .then((response:any)=> {
        // $scope.hidespin();
        this.loader.dismissLoading()
        debugger
        console.log(response);
        var result = response.data;
        result = JSON.parse(result);
        result = JSON.parse(result); 
        this.myleadscreenlist = result;
       this.myleadlength= this.myleadscreenlist.length
        this.loader.dismissLoading()


      },err=>{
        debugger
        this.loader.dismissLoading()
        this.alertservice.presentAlert('',err.status)
      })
     
  }
  followupleadRefresh(event) {
    debugger
    this.refreshdisplaylead()
    setTimeout(() => {
      // Any calls to load data go here
      event.target.complete();
    }, 2000);
  };
 refreshdisplaylead() {
    
    var branchid = window.localStorage['branchID'];
  var userid = window.localStorage['userID'];
  var customerid = 0;
  var BusinessUnit = 0;
    // this.showspin();
    this.loader.presentLoading('')
   this.Apiservice.myleadscreen(userid, branchid, customerid, BusinessUnit)
      .then((response:any)=> {
        // this.hidespin();
        var result = response.data;
        result = JSON.parse(result);
        result = JSON.parse(result);
        console.log("---this.myleadscreenlist",response );
        this.myleadscreenlist = result;
       this.myleadlength= this.myleadscreenlist.length
        this.loader.dismissLoading()
        console.log(this.myleadscreenlist)


      },err=>{
        this.loader.dismissLoading()
        this.alertservice.presentAlert('Error',err.status)
      })
      // .error(function(response) {
      //   this.hidespin();
      //   console.log(response);
      // });
  }

  displaylead() {
    debugger
    var branchid = window.localStorage['branchID'];
  var userid = window.localStorage['userID'];
  var customerid = 0;
  var BusinessUnit = 0;
    // this.showspin();
    this.loader.presentLoadingassign('')
   this.Apiservice.myleadscreen(userid, branchid, customerid, BusinessUnit)
      .then((response:any)=> {
        // this.hidespin();
        debugger
        var result = response.data;
        result = JSON.parse(result);
        result = JSON.parse(result);
        console.log("---this.myleadscreenlist",response );
        this.myleadscreenlist = result;
       this.myleadlength= this.myleadscreenlist.length
        this.loader.dismissLoading()
        console.log(this.myleadscreenlist)


      },err=>{
        this.loader.dismissLoading()
        this.alertservice.presentAlert("",err.status)
      })
      // .error(function(response) {
      //   this.hidespin();
      //   console.log(response);
      // });
  }

//start

  startmylead(obj)
{
  console.log(obj);
alert("You have started the Meeting")
    console.log(obj);
     var timestart = new Date();
    console.log(timestart);
    this.startleadtime = moment(timestart).format("h.mm s a");
    //    this.followuptime = moment(this.data.followuptime).format('h.mm a')
    //  this.startleadtime = $filter('date')(timestart, 'h.mm s a');
    console.log( this.startleadtime);
}
goToMyplannerPage() {
  if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
    this.router.navigate(['/regionsummary']);
}else
  if(window.localStorage['userType']=='17')
  { this.router.navigate(['/newsummary']);}else{
  this.router.navigateByUrl('/myplanner');
  }
}
Endcallscreen(item) {
  debugger
this.Apiservice.followupleadmodalarray=[]
this.Apiservice.followupleadmodalarray.push(item)
this.router.navigateByUrl('/followupleadcallconnect')

 
 }
//start
myleadsmodel(items){
  debugger
  console.log(items)
  this.Apiservice.followupleadmodalarray=[]
  this.Apiservice.followupleadmodalarray.push(items,{model:"Actionnavigation"},{close:"closefollowlead"})
  this.router.navigateByUrl('/followupleadmodal')
  // const modal = await this.modalController.create({
  //   component: FollowupleadmodalPage,
  //   componentProps: { Data: items,model: "Actionnavigation"  }
  //   });
  //   return await modal.present();
}

//End
endNavigationleads(items){
debugger
this.Apiservice.followupleadmodalarray=[]
  this.Apiservice.followupleadmodalarray.push(items,{model: "endnavigation"},{close:"closefollowlead"})
  this.router.navigateByUrl('/followupleadmodal')
  // const modal = await this.modalController.create({
  //   component: FollowupleadmodalPage,
  //   componentProps: { Data: items,model: "endnavigation" }
  //   });
  //   return await modal.present();
}

//navigationmap
startNavigationrootleads(items){
  debugger
  this.Apiservice.followupleadmodalarray=[]
  this.Apiservice.followupleadmodalarray.push(items,{model:"Navigationrootleads"},{close:"closefollowlead"})
  this.router.navigateByUrl('/followupleadmodal')
  // const modal = await this.modalController.create({
  //   component: FollowupleadmodalPage,
  //   componentProps: { Data: items,model: "Navigationrootleads" }
  //   });
  //   return await modal.present();
}
getbusinessunit () {
  debugger
  //  this.showspin();
   this.Apiservice.getFollowupleadsdrop()
      .then((res:any)=> {
        debugger
       var response = res.data;
     response = JSON.parse(response);
     response = JSON.parse(response);
        this.businessunitlist = response;
console.log(this.businessunitlist)

       // this.hidespin();

      })
      


  }
}