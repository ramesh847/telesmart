// import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { FilterPipe } from 'ngx-filter-pipe';
import { MyfollowupvisitmodalPage } from '../modal/myfollowupvisitmodal/myfollowupvisitmodal.page';
import { ApiServiceService } from '../service/api-service.service';
// import { CommonvisitUpdateModalPage } from '../modal/commonvisit-update-modal/commonvisit-update-modal.page';
import { CommonvisitUpdateModalPage } from '../modal/commonvisit-update-modal/commonvisit-update-modal.page';
import { Router } from '@angular/router';
import { ToastServiceService } from '../service/toast-service.service';
// ../modal/myfollowupvisitmodal/myfollowupvisitmodal.page
import { Idle, DEFAULT_INTERRUPTSOURCES } from "@ng-idle/core";
@Component({
  selector: 'app-commonvisit',
  templateUrl: './commonvisit.page.html',
  styleUrls: ['./commonvisit.page.scss'],
  providers:[Idle]
})
export class CommonvisitPage implements OnInit {
  getnummmm:any;
  callPurpose: any;
  CBSCustomerID:any;
  mobileNumber:any;
  Purpose:any;
  search:any={}
  commonvisitdataonload: any;
  firstWords: any[];
  datalength: any;
  idleState: string;
  constructor(private Apiservice: ApiServiceService, private filterPipe: FilterPipe,
    private modalController: ModalController,public router:Router,private loader:ToastServiceService,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          // (this.idleState = countdown.toString() )
          {
            let idleState = countdown
            let minutes = Math.floor((idleState)/ 60);
            let extraSeconds = (idleState) % 60;
           let minutes1 = minutes < 10 ? "0" + minutes : minutes;
           let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
           this.idleState=minutes1 +':'+ extraSeconds1
           console.log(this.idleState)
          }
      );}

  ngOnInit() {
    debugger
    this.getpurpose()
    this.getCommonvisitsonload()
    // this.reset()
  }
  clicknumberstar(num:any){
    debugger
   this.getnummmm= this.Apiservice.firstfivexxxx(num)
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    //this.timedOut = false;
  }
  goToMyplannerPage() {
    if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
      this.router.navigate(['/regionsummary']);
}else
    if(window.localStorage['userType']=='17')
  { this.router.navigate(['/newsummary']);}else{
    this.router.navigateByUrl('/myplanner');
  }
    // this.router.navigateByUrl('/myplanner');
  }
  callNumber(data){
    this.Apiservice.commonvisitupdatearray=[]
    this.Apiservice.commonvisitupdatearray.push(data)
  this.router.navigateByUrl('/commonvisitcallconnect')
  }
  commonvisitrefresh(event) {
    debugger
    this.refreshgetCommonvisitsonload()
    setTimeout(() => {
      // Any calls to load data go here
      event.target.complete();
    }, 2000);
  };
  refreshgetCommonvisitsonload() {
    debugger
    // this.showspin();
    // this.loader.presentLoading('')
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    var calltype = "P";

    var custid = " ";
    // this.showspin();
    this.Apiservice.getcomvisits(0, branchid, calltype, custid)
      .then((response:any)=> {
        debugger
        // this.loader.dismissLoading()
        // this.$broadcast('scroll.refreshComplete');
        // this.hidespin();
        response = JSON.parse(response.data);
        this.commonvisitdataonload = JSON.parse(response);
        this.datalength= this.commonvisitdataonload.length
        console.log(this.commonvisitdataonload);
        var firstname = [];
        this.firstWords = [];
        for (let i = 0; i <this.commonvisitdataonload.length; i++) {
          firstname = this.commonvisitdataonload[i].CustomerName.split(" ");
          this.firstWords.push(firstname[0]);
          this.commonvisitdataonload[i].firstname = this.firstWords[i];
        }
        console.log(this.commonvisitdataonload)
        // this.hidespin();
      })
     

  };

  getCommonvisitsonload() {
    debugger
    // this.showspin();
    this.loader.presentLoading('')
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    var calltype = "P";

    var custid = " ";
    // this.showspin();
    this.Apiservice.getcomvisits(0, branchid, calltype, custid)
      .then((response:any)=> {
        debugger
        this.loader.dismissLoading()
        // this.$broadcast('scroll.refreshComplete');
        // this.hidespin();
        response = JSON.parse(response.data);
        this.commonvisitdataonload = JSON.parse(response);
        this.datalength= this.commonvisitdataonload.length
        console.log(this.commonvisitdataonload);
        var firstname = [];
        this.firstWords = [];
        for (let i = 0; i <this.commonvisitdataonload.length; i++) {
          firstname = this.commonvisitdataonload[i].CustomerName.split(" ");
          this.firstWords.push(firstname[0]);
          this.commonvisitdataonload[i].firstname = this.firstWords[i];
        }
        console.log(this.commonvisitdataonload)
        // this.hidespin();
      })
     

  };


  searchCommonVisits(purposeid,custid){
    debugger
    this.commonvisitdataonload=[];
    // this.showspin();
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    var calltype = "P";
    // var custid = " ";
    if(purposeid == ""){
      purposeid = 0;
    }
    if(custid == ''||typeof custid == 'undefined'){
      custid=" ";
    }

    // this.showspin();
    this.Apiservice.getcomvisits(purposeid, branchid, calltype, custid)
      .then((response:any)=> {
        // this.$broadcast('scroll.refreshComplete');
        // this.hidespin();
        response = JSON.parse(response);
        this.commonvisitdataonload = response;
        console.log(this.commonvisitdataonload);
        var firstname = [];
        this.firstWords = [];
        for (let i = 0; i <this.commonvisitdataonload.length; i++) {
          firstname = this.commonvisitdataonload[i].CustomerName.split(" ");
          this.firstWords.push(firstname[0]);
          this.commonvisitdataonload[i].firstname = this.firstWords[i];
        }
        console.log(this.commonvisitdataonload)
        // this.hidespin();
      })
    }
  getpurpose(){
    //this.showspin();
    debugger

    this.Apiservice.getpurposenew()
      .then((response:any)=> {
        debugger
        console.log(response.data);
        response = JSON.parse(JSON.parse(response.data));
        this.callPurpose = response;
        //this.hidespin();

      })
     
  }
   commonvisitUpdateModal(items:any){

    this.Apiservice.commonvisitupdatearray=[]
    this.Apiservice.commonvisitupdatearray.push(items)
    this.router.navigateByUrl('/commonvisit-update-modal')
 
  }

  }


