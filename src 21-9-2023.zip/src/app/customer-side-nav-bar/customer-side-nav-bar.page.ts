import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, LoadingController, MenuController } from '@ionic/angular';
import { IpaddressService } from '../fm-services/ipaddress.service';

@Component({
  selector: 'app-customer-side-nav-bar',
  templateUrl: './customer-side-nav-bar.page.html',
  styleUrls: ['./customer-side-nav-bar.page.scss'],
})
export class CustomerSideNavBarPage implements OnInit {
  username:any;
  user_code:any;
  branchDesc:any;
  UserType: any;
  tum_user_photo: any;
  showAdminAccess: boolean;
  showCustomerAccess: boolean;
  MaintenanceEngineerAccess: boolean;

  constructor(private router: Router, private menu: MenuController,
    public Ipaddressservice: IpaddressService,
    private http: HttpClient,public loadingController: LoadingController,
    public alertController: AlertController,) {
    this.username = localStorage.getItem('TUM_USER_NAME');
    this.user_code = localStorage.getItem('TUM_USER_CODE');
    this.branchDesc = localStorage.getItem('TUM_BRANCH_CODE');
    this.tum_user_photo = localStorage.getItem('tum_user_photo');

    this.UserType = localStorage.getItem('UserType');
    if (this.UserType == "administrator") this.showAdminAccess = true;
    else this.showAdminAccess = false;

    if(this.UserType == "Customer") this.showCustomerAccess = true;
    else this.showCustomerAccess = false;

    if(this.UserType == "Maintenance Engineer") this.MaintenanceEngineerAccess = true;
    else this.MaintenanceEngineerAccess = false;
  }

  ngOnInit() {
  };

  dashboard() {
    this.menu.toggle();
    this.router.navigate(['/dashboard']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };
  customer() {
    debugger
    this.menu.toggle();
    this.router.navigate(['/customer-property-details']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };
  myTask() {
    this.menu.toggle();
    this.router.navigate(['/fm-my-task']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };
  additionalCharges() {
    this.menu.toggle();
    this.router.navigate(['/fm-additional-page']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };
  quickReciept() {
    this.menu.toggle();
    this.router.navigate(['/fm-quick-receipt']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };

  transaction() {
    this.menu.toggle();
    this.router.navigate(['/fm-transaction']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };

  propertyList() {
    this.menu.toggle();
    this.router.navigate(['/fm-property-list']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };

  paymentDetails() {
    this.menu.toggle();
    this.router.navigate(['/fm-payment-details']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };
  issueLedger() {
    this.menu.toggle();
    this.router.navigate(['/fm-issue-ledger']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };
  documentExpiryReport() {
    this.menu.toggle();
    this.router.navigate(['/fm-document-expiry-report']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };
  propertyContactList() {
    this.menu.toggle();
    this.router.navigate(['/fm-propety-contact-list']).then(() => {
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  };


  async logout() {
    var alert1 = await this.alertController.create({
      backdropDismiss: false,
      cssClass: 'custom-alert',
      message: 'Are you sure you want to logout',
      buttons: [

        {
          text: 'No',
          role: 'cancel',
          cssClass: 'alert-button-cancel',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        }, {
          text: 'Yes',
          cssClass: 'alert-button-confirm',
          handler: () => {

            var logout_obj = {
              access_token: localStorage.getItem('token'),
              userid: localStorage.getItem('TUM_USER_ID'),
              usertoken: localStorage.getItem('usertoken'),

            };

            const header = new Headers();
            header.append("Content-Type", "application/json");
            let options = new HttpHeaders().set('Content-Type', 'application/json');
            this.http.post(this.Ipaddressservice.ipaddress + '/Collections/Collections/logout/', logout_obj, {
              headers: options,
            }).subscribe(resp => {

              localStorage.clear();
              this.router.navigate(['/login-page']);

            }, error => {
              localStorage.clear();
              this.router.navigate(['/login-page']);

            });

          }
        }
      ]
    });

    await alert1.present();
  }
  async presentLoadingWithOptions() {
    const loading = await this.loadingController.create({
      spinner: 'lines-sharp',
      duration: 500,
      // message: 'Please wait...',
      translucent: true,
      cssClass: 'custom-class custom-loading',

    });
    return await loading.present();
  };

  async loadingdismiss() {

    return await this.loadingController.dismiss();
  };

  // toggleMenu() {
  //   debugger;
  //   this.menu.toggle(); //Add this method to your button click function

  // }
}
