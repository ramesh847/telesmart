import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MenucomponentPageRoutingModule } from './menucomponent-routing.module';

import { MenucomponentPage } from './menucomponent.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MenucomponentPageRoutingModule
  ],
  declarations: [MenucomponentPage]
})
export class MenucomponentPageModule {}
