import { Component, OnInit } from '@angular/core';
import { AlertController, LoadingController, MenuController } from '@ionic/angular';
import { AlertServiceService } from '../service/alert-service.service';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { Router } from '@angular/router';
import { ApiServiceService } from '../service/api-service.service';

@Component({
  selector: 'app-menucomponent',
  templateUrl: './menucomponent.page.html',
  styleUrls: ['./menucomponent.page.scss'],
})
export class MenucomponentPage implements OnInit {

  constructor(private menu: MenuController,private alert:AlertController,
    private alertService: AlertServiceService,
    private appVersion: AppVersion,private router:Router,private service:ApiServiceService,
    public loadingController: LoadingController ) { }

  ngOnInit() {
  }
  async presentLoadingWithOptions() {
    const loading = await this.loadingController.create({
      spinner: 'lines-sharp',
      duration: 500,
      // message: 'Please wait...',
      translucent: true,
      cssClass: 'custom-class custom-loading',

    });
    return await loading.present();
  };

  async loadingdismiss() {

    return await this.loadingController.dismiss();
  };
  userprofile(){
    debugger
    this.menu.toggle();
    this.router.navigate(['/userprofile']).then(() => {
      debugger
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  }
  notification(){
    debugger
    this.menu.toggle();
    this.router.navigate(['/userprofile']).then(() => {
      debugger
      setTimeout(() => {
        this.presentLoadingWithOptions();
      }, 1000);
      window.location.reload();
      this.loadingdismiss();
    });
  }

}
