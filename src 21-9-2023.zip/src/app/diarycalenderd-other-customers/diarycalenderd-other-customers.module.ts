import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DiarycalenderdOtherCustomersPageRoutingModule } from './diarycalenderd-other-customers-routing.module';

import { DiarycalenderdOtherCustomersPage } from './diarycalenderd-other-customers.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DiarycalenderdOtherCustomersPageRoutingModule
  ],
  declarations: [DiarycalenderdOtherCustomersPage]
})
export class DiarycalenderdOtherCustomersPageModule {}
