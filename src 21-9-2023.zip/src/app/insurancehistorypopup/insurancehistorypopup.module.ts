import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InsurancehistorypopupPageRoutingModule } from './insurancehistorypopup-routing.module';

import { InsurancehistorypopupPage } from './insurancehistorypopup.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InsurancehistorypopupPageRoutingModule
  ],
  declarations: [InsurancehistorypopupPage]
})
export class InsurancehistorypopupPageModule {}
