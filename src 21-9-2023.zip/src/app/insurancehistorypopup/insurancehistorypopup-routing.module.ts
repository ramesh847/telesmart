import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InsurancehistorypopupPage } from './insurancehistorypopup.page';

const routes: Routes = [
  {
    path: '',
    component: InsurancehistorypopupPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InsurancehistorypopupPageRoutingModule {}
