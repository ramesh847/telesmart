import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-insurancehistorypopup',
  templateUrl: './insurancehistorypopup.page.html',
  styleUrls: ['./insurancehistorypopup.page.scss'],
})
export class InsurancehistorypopupPage implements OnInit {
  history:any[]=[]
  constructor(public modalController: ModalController,private navParams:NavParams, 
    private ApiServiceService:ApiServiceService,
    public alertservice:AlertServiceService) { }

  ngOnInit() {
    debugger
    this.history=[]
   let xyz= this.navParams.get('Data')
   this.ApiServiceService.insurancegetdetailshistory(xyz).then((res:any)=>{
    debugger
    for(let i=0;i< JSON.parse(JSON.parse(res.data)).length;i++){
      this.history.push({
        Leadstatus:JSON.parse(JSON.parse(res.data))[i].Leadstatus,
        Leaddatetime:JSON.parse(JSON.parse(res.data))[i].Leaddatetime.replace('T',' '),
        CreatedDate:JSON.parse(JSON.parse(res.data))[i].CreatedDate.replace('T',' '),
        description:JSON.parse(JSON.parse(res.data))[i].description
      })
    }
   
    // this.datepipe.transform( this.express.followupdate,'YYYY-MM-dd')

   })
  }
  modeldissmiss() {
    this.modalController.dismiss()
  }
}
