import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ManagerheatmapPageRoutingModule } from './managerheatmap-routing.module';

import { ManagerheatmapPage } from './managerheatmap.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ManagerheatmapPageRoutingModule
  ],
  declarations: [ManagerheatmapPage]
})
export class ManagerheatmapPageModule {}
