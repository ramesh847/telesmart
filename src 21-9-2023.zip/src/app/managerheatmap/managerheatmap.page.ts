import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { ManagerheatmapdetailPage } from '../modal/managerheatmapdetail/managerheatmapdetail.page';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';

@Component({
  selector: 'app-managerheatmap',
  templateUrl: './managerheatmap.page.html',
  styleUrls: ['./managerheatmap.page.scss'],
  providers:[Idle]
})
export class ManagerheatmapPage implements OnInit {
  
  // segment: any;
  cardshow: boolean=false;
  showmmlist: boolean=false;
  userid: any;
  branchid: any;
  userType: any;
  mangermap: any;
  assignstartdate: any;
  assignstartend: any;
  individuals: any;
  segment: any;
  segment1: any;
  idleState: string;

  constructor(public router: Router, public apiservice: ApiServiceService,
    public alert: AlertServiceService, private modalController: ModalController,
    private loader: ToastServiceService,private idle:Idle) {// sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>{
          let idleState = countdown
           let minutes = Math.floor((idleState)/ 60);
           let extraSeconds = (idleState) % 60;
          let minutes1 = minutes < 10 ? "0" + minutes : minutes;
          let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
          this.idleState=minutes1 +':'+ extraSeconds1
          console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    debugger
    this.segment1= 'indivuduals';
    this. userid = window.localStorage['userID'];;
    this. branchid = window.localStorage['branchID'];
    this. userType = window.localStorage['userType'];
    this.heatdisplay()
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  segmentChanged(ev: any) {
    debugger
    this.segment1 = ev.detail.value;
    if(this.segment1=='branch'){
      // this.cardshow = true
      this.cardbranch()
      // this.tablebranch()
    }else{
      // this.segment=this.segment
      this.heatdisplay()
      
    }
  }
  cardbranch() {
    debugger
    this.cardshow = true
    this.showmmlist = false
    this.branchdisplay()
  }
  tablebranch() {
    debugger
    this.cardshow = false
    this.showmmlist = true
    this.branchdisplay()
  }
  branchdisplay(){
    this.apiservice.getheapmap(this.userid,this. branchid)
    .then((response:any)=> {
      debugger
        response = JSON.parse(JSON.parse(response.data));
        console.log(response);
       this.mangermap =response;

       this.apiservice.AssigneDdate()
    .then((response:any) =>{
      debugger
        response = JSON.parse(JSON.parse(response.data));
        console.log(response);
       this.assignstartdate =response[0].EndDate;
       this.assignstartend=response[0].StartDate;
    })
    })


  }
  heatdisplay()
        {
          debugger
          // this.loader.presentLoading('')
            this.apiservice.getheapmapbranchname(this.userid, this.branchid)
        .then((response:any) =>{
          debugger
          // this.loader.dismissLoading()
            response = JSON.parse(JSON.parse(response.data));
            console.log(response);
           this.individuals =response;
        })



        }

        modeldissmiss(){
          this.router.navigateByUrl('newsummary')
        }

  async getindivudualsdetails(items) {
    debugger
    const modal = await this.modalController.create({
      component: ManagerheatmapdetailPage,
      componentProps: { Data: items, }
    });
    return await modal.present();
  }

 
  
}
