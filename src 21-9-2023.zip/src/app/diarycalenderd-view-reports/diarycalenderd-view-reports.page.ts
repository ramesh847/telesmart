import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';

@Component({
  selector: 'app-diarycalenderd-view-reports',
  templateUrl: './diarycalenderd-view-reports.page.html',
  styleUrls: ['./diarycalenderd-view-reports.page.scss'],
  providers:[Idle]

})
export class DiarycalenderdViewReportsPage implements OnInit {
  dataresp: any;
  custID='';
  customerType ='';
  data: any ={};
  dataresplength: any;
  idleState: string;
  constructor(private apiService: ApiServiceService,private router: Router,private loader:ToastServiceService,
    private AlertService:AlertServiceService,private idle:Idle) {
   // sets an idle timeout of 5 seconds, for testing purposes.
   this.idle.setIdle(5);
   // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
   this.idle.setTimeout(15*60);
   // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
   this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

   this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
   this.idle.onTimeout.subscribe(() => {
     // this.idleState = "Timed out!";
     // this.timedOut = true;
     this.router.navigate(['sessionout'])
   });
   this.idle.onIdleStart.subscribe(
     () => (this.idleState = "")
   );
   this.idle.onTimeoutWarning.subscribe(
     countdown =>
      //  (this.idleState = countdown.toString() )
      {
        let idleState = countdown
        let minutes = Math.floor((idleState)/ 60);
        let extraSeconds = (idleState) % 60;
       let minutes1 = minutes < 10 ? "0" + minutes : minutes;
       let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
       this.idleState=minutes1 +':'+ extraSeconds1
       console.log(this.idleState)
      }
   );
   }

  ngOnInit() {
    this.getViewReport();
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }

 getViewReport() {
  debugger
    // this.showspin();
      var userid = window.localStorage['userID'];;
      var branchid = window.localStorage['branchID'];
      var userType = window.localStorage['userType'];
      if(this.data.customerid == undefined ){
        var custID = 0 ;
      }else{
        custID = this.data.customerid ;
      }
      this.loader.presentLoadingassign('')
      this.apiService.getviewreportGrid(userid, branchid, userType, custID.toString()).then(response => {
        debugger
        this.loader.dismissLoading()
        var res = JSON.stringify(response.data);
        debugger
        res = JSON.parse(res);
        res = JSON.parse(res);
        res = JSON.parse(res);
        // res = JSON.parse(res);
        this.dataresp = res;
        this.dataresp = this.dataresp.Table;
        this.dataresplength=this.dataresp.length
        // this.data.customerid=''
        debugger
        console.log(this.dataresp)
      },err=>{
        this.loader.dismissLoading()
        this.AlertService.presentAlert('Error',err.status)
      })
    }
    goToMyplannerPage() {
      if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
        this.router.navigate(['/regionsummary']);
  }else
      if(window.localStorage['userType']=='17')
    { this.router.navigate(['/newsummary']);}else{
      this.router.navigateByUrl('/myplanner');
    }
      // this.router.navigateByUrl('/myplanner');
    }
}
