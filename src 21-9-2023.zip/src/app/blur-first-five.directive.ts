import { Directive, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appBlurFirstFive]'
})
export class BlurFirstFiveDirective {

  constructor(private el: ElementRef, private renderer: Renderer2) {
    this.blurFirstFiveCharacters();
  }

  private blurFirstFiveCharacters() {
    const text = this.el.nativeElement.textContent;
    const blurredText = 'xxxx' + text.substring(4);

    this.renderer.setProperty(this.el.nativeElement, 'textContent', blurredText);
  }

}
