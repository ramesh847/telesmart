import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from './../service/api-service.service';
import { Pipe, PipeTransform } from '@angular/core';
import { FilterPipe } from 'ngx-filter-pipe';
import { AlertController, ModalController } from '@ionic/angular';
// import { MyassigncallmodalPage } from '../modal/myassigncallmodal/myassigncallmodal.page';
import { MyfollowcallmodalPage } from '../modal/myfollowcallmodal/myfollowcallmodal.page';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import {Router} from '@angular/router';
import { ToastServiceService } from '../service/toast-service.service';
import { AssignedcommonupdatePage } from '../modal/assignedcommonupdate/assignedcommonupdate.page';
import { CommoncallconnectPage } from '../modal/commoncallconnect/commoncallconnect.page';
import { AlertServiceService } from '../service/alert-service.service';
import { Idle,DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
@Component({
  selector: 'app-commoncall',
  templateUrl: './commoncall.page.html',
  styleUrls: ['./commoncall.page.scss'],
  providers: [
    DatePipe,Idle],
})
export class CommoncallPage implements OnInit {
  getnummmm:any;
  dateToday3 = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
    // customers: any = [];
    purpose: any = [];
    search: any = {};
    commoncallsdataonload: any = [];
    firstWords: any[];
    purposename: any;
    username: any;
    commoncallsdata :any = [];
    loaddata:boolean=false;
    date: any;
    date_a: any;
    followupcallsdata :any = [];
  branchid: any;
  usertype: any;
  usercode: any;
  CallerId: any;
  calltype: any;
  datatofilter: any;
  commoncallgrid:boolean;
  commoncallupdate:boolean;
  commoncallconnect:boolean;
  commoncallsdataonloadlength: any;

  //call update start
  savebool:boolean
  assigned:any={};
  Cusdata1: any;
  Purpose: any;
 
  hidecalloutcome:boolean;
  customerid: any;
  purposeid: any;
  enable:boolean;
  assignedcallscustomerdata: any;
 
  firstname1: any;
  myvalue:boolean;
  getusername: any;
  Collectiondate1: any;
  cbsid: any;
  mobile1: any;
 
  remarks1: any;
  lastname1: any;
  customername1: any;
  responseid: any;
  callid: any;
  BusinessUnit: number;
  mobile: any;
  customername: any;
  firstname: any;
  lastname: any;
  remarks: any;
  collectionmode: string;
  collectiondate: string;
  accountno: any;
  amount: any;
  nextcalldate1: any;
  followuptime: any;
  getfollowdates: string;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  nextcalldate: string;
  jointvisit: string;
  jointcode: any;
  lat1: any;
  lng1: any;
  latvalue: any;
  langvalue: any;
  address: any;
 
  userid: any;
 
 
  depositVal: any;
  casaVal: any;
  AdvanceVal: any;
  InsuranceVal: any;
  success: any[];
 
  // loaddata: boolean;
  custid: string;
 
  // datatofilter: any[];
  callout: any;
  jointvisitChecked: boolean = false;

  //end

  //call connect start
  Cusdata: any;
  item: any;
  clickcall:any={}
  res: any;
  resout: any;
  clickcallID: any;
  interval: any;
  statusResp: any;
  repStatus: any;
  EndCallobj:any={}
  endDate: string;
  currDate: string;
  voicerecording: string;
  location: string;
  provider: string;
  status: string;
  status2: string;
  rowid: any;
  clickid: any;
  //end
  commoncallgridtable:boolean
  idleState: string;
  getcaller: any;
  getcustomer: any;
    constructor(private Apiservice: ApiServiceService, private filterPipe: FilterPipe, private datepipe: DatePipe,
      private modalController: ModalController,private loader:ToastServiceService,private AlertService:AlertServiceService,
      private router: Router,private alert:AlertController,private idle:Idle) { 
         // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
      {
        let idleState = countdown
        let minutes = Math.floor((idleState)/ 60);
        let extraSeconds = (idleState) % 60;
       let minutes1 = minutes < 10 ? "0" + minutes : minutes;
       let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
       this.idleState=minutes1 +':'+ extraSeconds1
       console.log(this.idleState)
      }
    );
      }
   
    ngOnInit() {
      this.commoncallgrid=true
      this.commoncallupdate=false
      this.commoncallconnect=false
      this.commoncallgridtable=true
      this. branchid = window.localStorage['branchID'];
      this. usertype = window.localStorage['userType'];
      // this. userid = window.localStorage['userID'];
      this. usercode = window.localStorage['userCode'];
      this. CallerId = window.localStorage['userID'];
      this. username = window.localStorage['userName'];
      console.log(this.search)
      this.getCommoncallsonload();
      this.getpurpose();
  //  this.reset()
    }
    reset() {
      this.idle.watch();
      // this.idleState = "Started.";
      //this.timedOut = false;
    }
    getpurpose() {
      this.Apiservice.getpurpose().then(res=>{
        console.log(res);
        var data = JSON.stringify(res.data);
        this.purpose = JSON.parse(data);
        this.purpose = JSON.parse(this.purpose);
        this.purpose = JSON.parse(this.purpose);
        // this.purpose = JSON.parse(this.purpose);
        
      });
    }
    goToMyplannerPage() {
      if (this.usertype == 14 || this.usertype == 26) {
        this.router.navigate(['/regionsummary']);
    }else
      if(this.usertype =='17')
    { this.router.navigate(['/newsummary']);}else{
      this.router.navigateByUrl('/myplanner');
    }
      // this.router.navigateByUrl('/myplanner')
    }
   
   
  
   
    getCommoncallsonload() {
      debugger
      var branchid = window.localStorage['branchID'];
      var calltype = "T";
      var custid = " ";
      var purpose =null
      var selectdate=null
     
      this.loaddata = true;
     
      this.loader.presentLoading('')
      this.Apiservice.getcomcallscommon(purpose, branchid, calltype, custid,selectdate).then(response => {
    // console.log(response);
    debugger
    this.loader.dismissLoading();
    var data = JSON.stringify(response.data);
    // result = JSON.parse(result);
    
    this.commoncallsdataonload = JSON.parse(data);
    this.commoncallsdataonload = JSON.parse(this.commoncallsdataonload);
    this.commoncallsdataonload = JSON.parse(this.commoncallsdataonload);
    this.commoncallsdataonloadlength=this.commoncallsdataonload.length


    // this.commoncallsdataonload = result;
    console.log(this.commoncallsdataonload.length)
    var firstname = [];
    this.firstWords = [];

    for (var i = 0; i < this.commoncallsdataonload.length; i++) {
      firstname = this.commoncallsdataonload[i].CustomerName.split(" ");
      this.firstWords.push(firstname[0]);
      this.commoncallsdataonload[i].firstname = this.firstWords[i];
      if(this.commoncallsdataonload[i].ToCallDate == null || this.commoncallsdataonload[i].ToCallDate == undefined || this.commoncallsdataonload[i].ToCallDate =='' ){
        this.date=null
        this.date_a=null
        this.commoncallsdataonload[i].tofiltercalldate=this.date_a
        
              }else{
      this.date = this.commoncallsdataonload[i].ToCallDate.split('/');
      this.date_a = this.date[1]+'/'+this.date[0]+'/'+this.date[2];
      this.commoncallsdataonload[i].tofiltercalldate = this.date_a;
              }
    }
    // this.datatofilter = this.commoncallsdataonload;
      });
    }
    // clicknumberstar(num:any){
    //   debugger
    //  this.getnummmm= this.Apiservice.firstfivexxxx(num)
    // }
    clicknumberstar(num:any,status)
    {
      debugger
      if(status == 'grid'){
        this.getnummmm= this.Apiservice.firstfivexxxx(num)
      }
      else if(status == 'ca'){
        this.getcaller= this.Apiservice.firstfivexxxx(num)
      }else
      {
        this.getcustomer= this.Apiservice.firstfivexxxx(num)
    
    }
  }
  searchCommonCalls(purposeid,custid,selectdate){
    debugger
      localStorage.setItem('CCpurposeselected',purposeid);
      this.commoncallsdataonload = [];
    
      this.commoncallsdata = [];
      this.loaddata = true;
      if(purposeid == "" || purposeid=='Select' || purposeid==undefined){
        purposeid = null;
      }
      if(custid == ''|| custid == undefined){
        custid=null;
      }
      if(selectdate == '' || selectdate == undefined){
        selectdate = null;
      }
     
      this.calltype='T'
      this.loader.presentLoading('')
      this.Apiservice.getcomcallscommon(purposeid,this. branchid, this.calltype, custid,selectdate)
        .then((response:any) =>{
          debugger
          this.loader.dismissLoading()
          // $ionicLoading.hide();
          
            // response =JSON.parse( JSON.parse(response.data));
response=JSON.parse(response.data)
this.commoncallsdataonload = JSON.parse(response);
this.  commoncallsdataonloadlength=this.commoncallsdataonload.length
// this.commoncallgrid=true
// this.commoncallupdate=false
// this.commoncallconnect=false
         
           
  //   if(this.commoncallsdataonloadlength !=0){
  //     var firstname = [];
  //     this.firstWords = [];
  //     for (let i = 0; i < this.commoncallsdataonload.length; i++) {
  //       firstname = this.commoncallsdataonload[i].CustomerName;
  //       this.firstWords.push(firstname[0]);
  //       this.commoncallsdataonload[i].firstname = this.firstWords[i];
  //       if(this.commoncallsdataonload[i].ToCallDate == null || this.commoncallsdataonload[i].ToCallDate == undefined || this.commoncallsdataonload[i].ToCallDate =='' ){
  // this.date=null
  // this.date_a=null
  // this.commoncallsdataonload[i].tofiltercalldate=this.date_a
  
  //       }else{
  //         this.date = this.commoncallsdataonload[i].ToCallDate.split('/');
  //         this.date_a = this.date[1]+'/'+this.date[0]+'/'+this.date[2];
  //         this.commoncallsdataonload[i].tofiltercalldate = this.date_a;
  //       }
      
       
  //     }
  //     this.datatofilter = this.commoncallsdataonload;
  //   }
          
          
         
          //console.log(this.commoncallsdataonload)
   
        
       
          // console.log(this.commoncallsdataonload)
          // $ionicLoading.hide();
        })
       
  
  
    }
  
    
   
   

   
   commoncallsUpdmodal1(items){
     debugger
    this.Apiservice.assignedcommoncallarray=[]
    this.Apiservice.assignedcommoncallarray.push(items,{close:"endassigncommoncallconnect"})
    // new code start
    this.commoncallgrid=false
    this.commoncallupdate=true
    this.commoncallconnect=false

    this. assigned.JointVisit=true
    this.Cusdata1 =this.Apiservice.assignedcommoncallarray
    let Cusdata=this.Cusdata1[0]
    this.getcalloutcome()
    this.commoncallsUpdmodal(Cusdata)
    // this.router.navigateByUrl('/assignedcommonupdate')
    // end
  
  
    }
    getcalloutcome() {
      // this.showspin();
      this.Apiservice.getcalloutcome1()
        .then((response:any) =>{
          console.log(response);
          this.purposeid = response.PurposeId;
          response = JSON.parse(JSON.parse(response.data));
          this.callout = response;
          // this.hidespin()
  
  
        })

      }
      commoncallsUpdmodal(obj) {
        debugger
        console.log(obj)
        this.assigned.custname = obj.firstname;
        this.assigned.fullname = obj.CustomerName;
        this.Purpose = obj.Purpose;
        console.log(this.Purpose)
    
    //Condition to hide call closed option for NPA followup and VVIP Visits purposes
    if(this.Purpose != "NPA followup" && this.Purpose != "VVIP Visits"){
      this.hidecalloutcome = false;
    }else{
      this.hidecalloutcome = true;
    }
    
    
    
        //address
        this.assigned.addressname ="";
            //  $("#showdivscalls").css("display", "none");
    
        this.assigned.current = "";
        this.assigned.collected_date = "";
        this.assigned.collected_accno = "";
        this.assigned.collectamount = "";
        this.assigned.calloutcome = "";
        this.assigned.followdate = "";
        this.assigned.followtime = "";
        this.assigned.calltype = 'T';
        this.assigned.JointVisit = "";
        this.assigned.jointusername = "";
        this.assigned.jointcode = "";
        this.assigned.remarks = "";
        var customerid = obj.CBSCustomerID;
        this.customerid = obj.CBSCustomerID;
        window.localStorage['Customerid'] = obj.CBSCustomerID;
        window.localStorage['Callid'] = obj.CallID;
    
        window.localStorage['PurposeId'] = obj.PurposeId;
        this.purposeid = obj.PurposeId;
    
    
    
        // this.UpdateModal.show();
        if (customerid == null) {
    
          this.enable = false;
    
        }
        if (customerid != null) {
          this.enable = true;
          this.Apiservice.getcustomerdetails(customerid)
            .then((response:any)=> {
              debugger
              response = JSON.parse(JSON.parse(response.data));
              // response = JSON.parse(response);
              this.assignedcallscustomerdata = JSON.parse(response);
              if(this.assignedcallscustomerdata != "" && this.assignedcallscustomerdata != undefined)
              {
              this.assigned.customerid = customerid;
              this.assigned.firstname = this.assignedcallscustomerdata[0].Nfirstname;
              this.assigned.lastname = this.assignedcallscustomerdata[0].Nlastname;
              this.assigned.mobile = this.assignedcallscustomerdata[0].Nmobile;
              this.assigned.resphnno = this.assignedcallscustomerdata[0].Nresidencephone;
              this.assigned.email = this.assignedcallscustomerdata[0].Nemail;
              this.assigned.Purpose = this.assignedcallscustomerdata[0].Purpose;
    console.log(this.assigned);
    
              this.firstWords = [];
    
              var firstname = [];
    
              for (let i = 0; i < this.assignedcallscustomerdata.length; i++) {
    
                firstname = this.assignedcallscustomerdata[i].Nfirstname;
    
                this.firstWords.push(firstname[0]);
                this.assignedcallscustomerdata[i].firstname = this.firstWords[i];
                this.firstname1 = this.assignedcallscustomerdata[i].firstname;
    
              }
    debugger
              console.log(this.assignedcallscustomerdata[0].Add1);
              if(this.assignedcallscustomerdata[0].Add1 != undefined || this.assignedcallscustomerdata[0].Add2 != undefined || this.assignedcallscustomerdata[0].Add3 != undefined || this.assignedcallscustomerdata[0].Add4 != undefined || this.assignedcallscustomerdata[0].PIN != undefined){
                var respAdd1= this.assignedcallscustomerdata[0].Add1;
                var add1 = respAdd1.replace("/", "-");
                console.log(add1);
                var respAdd2= this.assignedcallscustomerdata[0].Add2;
                var add2 = respAdd2.replace("/", "-");
                console.log(add1);
                
              this.assigned.addressname = add1.replaceAll(' ','')+' '+add2.replaceAll(' ','')+' '+this.assignedcallscustomerdata[0].Add3+' '+this.assignedcallscustomerdata[0].Add4+' '+this.assignedcallscustomerdata[0].PIN;
              console.log(this.assigned.addressname);
              }
              if(this.assigned.addressname != "" && this.assigned.addressname != undefined)
              { 
                console.log(this.assigned.addressname);
               this.myvalue = true;
               //this.data.selectele='P';
              //  this.setlatlong(this.assigned.addressname);
              }
    
            }
    
            },err=>{
              debugger
              if(err.status == '-4'){
                this.AlertService.presentAlert("Error", "Request Time Out")
              }else if(err.status == '-3'){
                this.AlertService.presentAlert("Error","Host could not be resolved")
              }else
              {
              
              this.AlertService.presentAlert("Error", err.status)
              }
            })
           
        }
             
      };
      verifytime() {
        debugger
        var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
        this.getfollowdates = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
        if (this.getfollowdates <= date) {
          this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
        //  this.followupvisits.followdate=''
        //  this.followupvisits.followtime=''
        }
        
      }
      checkboxClick(Event){
        debugger
        console.log(Event);
        
        if(Event == true){
          this.assigned.JointVisit = 'N';
        }else{
          this.assigned.JointVisit = "Y";
        }
        // console.log(this.followupvisits.JointVisit)
      }
      checkusercode(val) {
        var usercode = val;
        var branchid = window.localStorage['branchID'];
      
        // this.showspin();
        this.Apiservice.getusername(usercode, branchid)
          .then( (response:any)=> {
            // this.hidespin();
            debugger
            console.log(response);
            response = JSON.parse(JSON.parse(response.data));
            if (response == "This User Not in this Branch") {
      
              this.AlertService.presentAlert("","Please Enter The Valid Emp Code")
              return false;
              this.assigned.jointusername = "";
             this.assigned.jointcode = "";
      
            } else {
              this.getusername = response;
             this.assigned.jointusername = this.getusername;
              console.log(this.getusername)
            }
      
          })
          
      }
      savecommoncalls(obj) {
        debugger
        var usercode = window.localStorage['userCode'];
        var username = window.localStorage['userName'];
        var branchid = window.localStorage['branchID'];
        var CallerId = window.localStorage['userID'];
        var cbsid = window.localStorage['Customerid'];
        console.log(cbsid)
    
        var mobile1 = obj.mobile;
        var calltype = this.assigned.calltype;
        var remarks1 = this.assigned.remarks;
        var firstname1 = obj.firstname;
        var lastname1 =obj.lastname;
        var purpose = window.localStorage['PurposeId'];
        var customername1 = this.assigned.firstname;
        var responseid = this.assigned.calloutcome;
        var callid = window.localStorage['Callid'];
        var BusinessUnit = 0;
        var fullname=obj.fullname
        
        console.log(responseid)
    
    
        if (mobile1 == "") {
    
          var mobile = null;
        } else {
          var mobile = mobile1;
        }
    
        if (customername1 == "") {
    
          var customername = null;
        } else {
          var customername = customername1;
        }
    
    
        if (firstname1 == "") {
    
          var firstname = null;
        } else {
          var firstname = firstname1;
        }
    
        if (lastname1 == "" || lastname1== undefined) {
    
          var lastname = null;
        } else {
          var lastname = lastname1;
        }
    
        if (remarks1 == "") {
    
          var remarks = null;
        } else {
          var remarks = remarks1;
        }
    
        if (purpose == "5" && this.assigned.current == "Y") {
          if ((this.assigned.collected_date == null || this.assigned.collected_date == undefined || this.assigned.collected_date == "") || (this.assigned.collected_accno == "" || this.assigned.collected_accno == undefined || this.assigned.collected_accno == null) || (this.assigned.collectamount == undefined || this.assigned.collectamount == "" || this.assigned.collectamount == null)) {
    this.AlertService.presentAlert("","Fill All Details Of Amount Collected")
    return false
           
    
          } else {
            var collectionmode = "Y";
            this.Collectiondate1 = this.assigned.collected_date;
            var collectiondate = this.datepipe.transform(this.Collectiondate1, 'yyyy-MM-dd');
            var accountno = this.assigned.collected_accno;
            var amount = this.assigned.collectamount;
          }
    
        }
        console.log(this.assigned.current)
        console.log(this.assigned.JointVisit)
    
        if (purpose != "5") {
           collectionmode = null;
    
        }
    
        if (purpose == "5") {
          if (this.assigned.current == "" || this.assigned.current == undefined || this.assigned.current == null || this.assigned.current == "N") {
            collectionmode = null;
    
          }
        }
    
        if (collectionmode == null) {
          var accountno = null;
          var amount = null;
          collectiondate = null;
        }
    
    
        if (this.assigned.calloutcome == "" || this.assigned.calloutcome == undefined || this.assigned.calloutcome == null) {
    this.AlertService.presentAlert("","Select Call OutCome")
    
         
          return false;
        }
    
    
    
        if (responseid == "2") {
          if ((this.assigned.followdate == null || this.assigned.followdate == "" || this.assigned.followdate == undefined) || (this.assigned.followtime == null || this.assigned.followtime == undefined || this.assigned.followtime == "")) {
            this.AlertService.presentAlert("","Provide Followup Details")
          
            return false;
    
    
          }  else {
            var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
            this.getfollowdates = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
            if (this.getfollowdates <= date) {
            
              this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
            return false
            }else{
      
      
      
            this.nextcalldate1 = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
          //  $filter('date')(this.followupvisits.followdate, 'yyyy-MM-dd');
      
          var time = this.assigned.followtime.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.assigned.followtime];
      
          if (time.length > 1) { // If time format correct
            time = time.slice (1);  // Remove full string match value
            this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
            time[0] = +time[0] % 12 || 12; 
            time[1]="."// Adjust hours
          }
          this.modifytime1= time.join ('');
          if(this.getampm=="AM"){
            this.modifytime2= this.modifytime1+' '+"AM"
          }else{
            this.modifytime2= this.modifytime1+' '+"PM"
          }
        
              var nextcalldate = this.nextcalldate1 + ' ' +  this.modifytime2;
              
         
         
      
           
          }
        }
    
        }
    
        if (responseid != "2") {
          nextcalldate = " ";
          //          var Endtime = null;
          // var Totime = null;
    
        }
    
        if (this.assigned.calltype == "" || this.assigned.calltype == undefined || this.assigned.calltype == null) {
    this.AlertService.presentAlert("","Select Call Type")
    
         
          return false;
    
        }
    
        if (this.assigned.calltype == "P" && this.assigned.JointVisit == "Y") {
          if (this.assigned.jointcode == null || this.assigned.jointcode == "" || this.assigned.jointcode == undefined) {
            this.AlertService.presentAlert("","Enter Joint Usercode")
          
            return false;
          } else {
            var jointvisit = "Y";
            var jointcode = this.assigned.jointcode;
    
          }
    
        }
    
        if (this.assigned.calltype == "P") {
          if (this.assigned.JointVisit == "" || this.assigned.JointVisit == null || this.assigned.JointVisit == undefined || this.assigned.JointVisit == "N") {
    
            jointvisit = null;
          }
        }
    
        if (this.assigned.calltype != "P") {
    
          jointvisit = null;
    
        }
    
        if (jointvisit == null) {
          var jointcode = null;
        }
    
        console.log(this.Purpose)
        if (this.Purpose == 'Lead Generation') {
    
          if ((this.assigned.casa != "" && this.assigned.casa != undefined) || (this.assigned.deposits != "" && this.assigned.deposits != undefined) || (this.assigned.advance != "" && this.assigned.advance != undefined) || (this.assigned.insurance != "" && this.assigned.insurance != undefined)) {
            console.log(this.assigned.casa);
            var casaVal = this.assigned.casa;
            console.log(casaVal)
            var depositVal = this.assigned.deposits;
            console.log(depositVal)
            var AdvanceVal = this.assigned.advance;
            console.log(AdvanceVal)
            var InsuranceVal = this.assigned.insurance;
            console.log(InsuranceVal)
    
          } else {
            this.AlertService.presentAlert("","Fill Details Of Expected Business")
           
            return false;
          }
    
          if (this.assigned.casa == undefined || this.assigned.casa == "") {
    
            casaVal = 0;
          } else {
            casaVal = this.assigned.casa;
          }
          if (this.assigned.deposits == undefined || this.assigned.deposits == "") {
            depositVal = 0;
          } else {
            depositVal = this.assigned.deposits;
          }
    
          if (this.assigned.advance == undefined || this.assigned.advance == "") {
            AdvanceVal = 0;
          } else {
            AdvanceVal = this.assigned.advance;
          }
    
          if (this.assigned.insurance == undefined || this.assigned.insurance == "") {
            InsuranceVal = 0;
          } else {
            InsuranceVal = this.assigned.insurance;
          }
    
        } else {
          casaVal = 0;
           depositVal = 0;
           AdvanceVal = 0;
           InsuranceVal = 0;
        }
    
        var Endtime = null;
        var Totime = null;
        console.log(this.assigned.followdate)
        console.log(this.assigned.followtime)
        console.log(this.assigned.JointVisit)
    
        if (this.assigned.calltype == "P") {
    
          if ((this.assigned.addressname == "") || ((this.assigned.addressname == 'undefined') || (this.assigned.addressname == undefined))) {
            console.log(this.assigned.addressname)
            this.AlertService.presentAlert("","Enter Your Location")
            
            return false;
    
          } else {
            //alert(latvalue);
            var latvalue = this.lat1;
            //console.log(latvalue)
            var langvalue = this.lng1;
            //console.log(latvalue)
            var address = this.assigned.addressname;
          }
    
    
        } else {
          var latvalue = null;
          var langvalue = null;
          var address = null;
        }
        console.log(purpose);
        if(lastname == '.') lastname = null;
        console.log(branchid, cbsid, fullname, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
    if (this.assigned.calltype == "P") {
    
      console.log("call type is pv");
       this.savebool=true
      this.Apiservice.updatecommoncalls(branchid, cbsid, fullname, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
      .then((response:any)=> {
        debugger
        // this.hidespin($ionicLoading);
        console.log(response);
        response =JSON.parse( JSON.parse(response.data));
        var success:any = [];
        success = response;
    
         if(success!="")
        {
    
          if (success[0].response == 1) {
    
            this.statusmethod(success[0].Column1)
            
            
                } 
                else {
                  // this.savemethod()
                  console.log(success, latvalue, langvalue, address,purpose, cbsid)
                  this.Apiservice.saveaddress(success, latvalue, langvalue, address,purpose,cbsid)
          .then((response:any)=> {
            debugger
            console.log(response)
             if(JSON.parse(response.data) == "Yes")
                  {
                    this.savemethod()
                 
        
                  }
        
                  else{
                    this.savebool=false
                    this.AlertService.presentAlert("","Error While Saving")
              
        
           
                  }
        
          })
               
                }
    
    
          
    //debugger;
     
    
    
    
        }
        
        
      })
    
        
        // this.UpdateModal.hide();
    }
    else
    {
      debugger
      console.log("call type is not pv");
      
      this.savebool=true
      this.Apiservice.updatecommoncalls(branchid, cbsid, fullname, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
      .then((response:any)=> {
        debugger
        // this.hidespin($ionicLoading);
        // console.log(response);
        response = JSON.parse(JSON.parse(response.data));
        var success = [];
        success = response;
    
    
        if (success[0].response == 1) {
    
    this.statusmethod(success[0].Column1)
        
       
    
        } 
        else {
          this.savemethod()
        
       
        }
    
        // this.getCommoncallsonload();
        
      }) 
    }
    
      }

      async statusmethod(msg){
        const alert = await this.alert.create({
          // header: 'You have ended the call explicitly. would you like to update?',
          cssClass:'alertHeader',
          // subHeader: 'Subtitle',
          message: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status '+msg,
          buttons: [{ text     : 'Ok',
         
          
          handler:() => {
            debugger
            // if(this.Cusdata1[1].close=="endassigncommoncallconnect" ||this.Cusdata1[1].close=="endassigncommoncallconnectpage"){
            //   this.route.navigateByUrl('/commoncall')
            // }
            
            this.savebool=false
            this.getCommoncallsonload1()
      
          }
        },
      
      ]
        });
        await alert.present()
      }
         async savemethod(){
          const alert = await this.alert.create({
            // header: 'You have ended the call explicitly. would you like to update?',
            cssClass:'alertHeader',
            // subHeader: 'Subtitle',
            message: 'Saved Successfully',
            buttons: [{ text     : 'Ok',
           
            
            handler:() => {
              debugger
            
              this.savebool=false
              this.getCommoncallsonload1()
              // if(this.Cusdata1[1].close=="endassigncommoncallconnect" ||this.Cusdata1[1].close=="endassigncommoncallconnectpage"){
              //   this.route.navigateByUrl('/commoncall')
              // }
      
            }
          },
        
        ]
          });
          await alert.present()
          }


   callNumber1(items){
     debugger

this.Apiservice.assignedcommoncallarray=[]
this.Apiservice.assignedcommoncallarray.push(items)

// new code start
this.commoncallgrid=false
this.commoncallupdate=false
this.commoncallconnect=true

this.Cusdata = this.Apiservice.assignedcommoncallarray[0];
console.log(this.Cusdata);
this.callNumber(this.Cusdata)
// this.router.navigateByUrl('/commoncallconnect')
// end
   }
  
   callNumber(item){
    debugger
    // window.localStorage['mobile']
    console.log(item);
    this.item = item;
    this.clickcall.callerName=window.localStorage['userName'];
    this.clickcall.callerMobile=window.localStorage['mobile']
    // window.localStorage['mobile']
    // window.localStorage['mobile']
    // window.localStorage['mobile'];;
    this.clickcall.customerName=item.CustomerName;
    this.clickcall.customerMobile=item.Mobile
    // item.Mobile
    // item.Mobile
    // item.Mobile;
    this.clickcall.customerId=item.CBSCustomerID;
    this.clickcall.purpose=item.Purpose;
    var currentDate= new Date();
    this.clickcall.currDate = this.datepipe.transform(currentDate, 'yyyy-MM-dd hh-mm-ss');
    // console.log(this.currDate);
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];

    if(this.clickcall.callerMobile =='' || this.clickcall.callerMobile ==undefined || this.clickcall.callerMobile ==null ){
      this.AlertService.presentAlert("","CallerNumber Not Available")
    }else if(this.clickcall.customerMobile =='' || this.clickcall.customerMobile ==undefined || this.clickcall.customerMobile ==null ){
     this.AlertService.presentAlert("","CustomerNumber Not Available") }else{
      this.Apiservice.endcallnrewfunction(branchid,userid,this.clickcall.callerMobile,this.clickcall.customerMobile).then((res:any)=>{
        this.rowid=JSON.parse(JSON.parse(res.data))
       
       
       
           this.Apiservice.clickToCall(this.clickcall.callerMobile,this.clickcall.customerMobile,this.rowid)
           .then((response:any)=> {
             debugger
             console.log(response)
             // this.hidespin($ionicLoading);
             this.resout = JSON.parse(JSON.parse(JSON.parse(response.data)));
             // this.resout = JSON.parse(this.res);
             console.log(this.resout)
             if(this.resout.status == '200'){
               this.clickcallID = this.resout.data;
               this.Apiservice. autoclicktocallupdate(this.clickcall.customerId,  this.clickcall.customerName,  this.clickcallID.id,  this.rowid,  "Commoncall").then((res:any)=>{
                debugger
                             })
               this.callinterval();
               // this.CallConnectModal.show();
             }else{
            
             this.AlertService.presentAlert("",response)
           
         
             }
       
       
           })
           
         })
     }



  }
  callinterval(){
    debugger
    this.interval = setInterval(() => {
      this.callResp();
          // clearInterval(this.interval)
        }, 10000);
 
    //   if ( angular.isDefined(gettimer) ) return;
    //  var gettimer =$interval( function(){ this.callResp(); }, 10000);

    
  }
  callResp(){
    debugger
    console.log(this.clickcallID.id);
    var id = this.clickcallID.id;
    this.Apiservice.callStatusFollowUp(id)
    .then((response:any)=> {
      debugger
    //  console.log(response)
      this.statusResp= JSON.parse(JSON.parse(JSON.parse(response.data)))
      this.repStatus = this.statusResp;
      //this.hidespin($ionicLoading);
      console.log(JSON.parse( JSON.parse(response.data)).length);
      if(JSON.parse(JSON.parse(JSON.parse(response.data))).data.length == 1){
        if((this.repStatus.data[0].status=="NOANSWER" || this.repStatus.data[0].status=="FAILED" || this.repStatus.data[0].status=="CONGESTION") && this.repStatus.data[0].status2==null) {
          this.stopCall();
        this.callResppopup(this.repStatus.data[0].status,id,"1")
        
        }else{
        console.log(this.repStatus.data[0].status2);
      if(this.repStatus.data[0].status2 != null){
        console.log(this.repStatus.data[0]);
        if(this.repStatus.data[0].status2 == 'ANSWER'){
          this.stopCall();
         // this.CallConnectModal.hide();
          // console.log(this.currDate);
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile=window.localStorage['mobile'];
          this.EndCallobj.customerName=this.Cusdata.CustomerName;
          this.EndCallobj.customerMobile=this.Cusdata.Mobile
          this.EndCallobj.customerId=this.Cusdata.CBSCustomerID;
          //this.EndCallobj.purpose=this.item.purpose_id;
          this.EndCallobj.purposeText= this.Cusdata.Purpose.split('/').join('-');
          this.EndCallobj.endStatus= 'A';
          //var currentDate= new Date();
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          this.Endcall(this.EndCallobj);
          // this.End(this.Cusdata);
        }else{
         
  this.stopCall()
          this.callResppopup(this.repStatus.data[0].status2,id,"2")
  
  
        }
      }
      }
    }
    })
    
  
  }
  callResppopup(ans,id,leg2){
    debugger
this.stopCall()
                            // <<<---using ()=> syntax
      this.Apiservice.callStatusLead(id).then((res:any)=>{
  
        debugger
       res= JSON.stringify(res)
       res=JSON.parse(res)
  
       if(res !='' && res.data == '"\\"\\""'){
    this.Apiservice.callStatusLead(id).then((res:any)=>{
  
      debugger
     res= JSON.stringify(res)
     res=JSON.parse(res)




    
      var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
      
      if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
        this.voicerecording='No Record'
      }else{
      this.voicerecording=xyz[0].recording.slice(28)
      }
      if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
      this.location="no record"
      }else{
        this.location=xyz[0].location
      }
      if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
        this.provider="no provider"
      }else{
        this.provider=xyz[0].provider
      }
      if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
        this.status="no status"
      }else{
       this.status=xyz[0].status
      }
      if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
        this.status2="no status"
      }else{
       this.status2=xyz[0].status2
      }
      
   debugger
   var branchid = window.localStorage['branchID'];
   var usertype = window.localStorage['userType'];
   var userid = window.localStorage['userID'];
   var purpose = 'Common Calls';
var objendcall={
  CustId :this.clickcall.customerId,
            CustName :this.clickcall.customerName,
            CustNumber :this.clickcall.customerMobile,
            strUserId :userid,
            strBranch :branchid,
            UserNumber :this.clickcall.callerMobile,
            StartTime :xyz[0].start_time,
            Endtime :xyz[0].end_time,
            Purpose :purpose,
            duration :xyz[0].duration,
            bill :xyz[0].billsec,
            credit :xyz[0].credits,
            status :this.status,
            status1 :this.status2,
            rec :this.voicerecording,
            location :this.location,
            provider :this.provider,
            callid :id,
            rowid :this.rowid
}


      this.Apiservice.endcallconnectnewmethod(objendcall)
        .then((response:any)=> {
                debugger
            this.callresppopoutput(ans,leg2)
            
              },err=>{
                 if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
              })
              
            
            
              }
            )
  }else{
  
  
      
        var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
        if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
          this.voicerecording='No Record'
        }else{
        this.voicerecording=xyz[0].recording.slice(28)
        }
        if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
        this.location="no record"
        }else{
          this.location=xyz[0].location
        }
        if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
          this.provider="no provider"
        }else{
          this.provider=xyz[0].provider
        }
        if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
          this.status="no status"
        }else{
         this.status=xyz[0].status
        }
        if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
          this.status2="no status"
        }else{
         this.status2=xyz[0].status2
        }
        
     debugger
     var branchid = window.localStorage['branchID'];
     var usertype = window.localStorage['userType'];
     var userid = window.localStorage['userID'];
     var purpose = 'Common Calls';
  var objendcall={
    CustId :this.clickcall.customerId,
              CustName :this.clickcall.customerName,
              CustNumber :this.clickcall.customerMobile,
              strUserId :userid,
              strBranch :branchid,
              UserNumber :this.clickcall.callerMobile,
              StartTime :xyz[0].start_time,
              Endtime :xyz[0].end_time,
              Purpose :purpose,
              duration :xyz[0].duration,
              bill :xyz[0].billsec,
              credit :xyz[0].credits,
              status :this.status,
              status1 :this.status2,
              rec :this.voicerecording,
              location :this.location,
              provider :this.provider,
              callid :id,
              rowid :this.rowid
  }
  
  
        this.Apiservice.endcallconnectnewmethod(objendcall)
          .then((response:any)=> {
                  debugger
              this.callresppopoutput(ans,leg2)
              
                },err=>{
                   if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                })
                
              
              
                }
              }
              )
  



  
  }
  async callresppopoutput(ans,leg2){
    debugger

if(ans == "FAILED" && leg2 == "2"){
  const alert = await this.alert.create({
    header: "Successfully Saved",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: '',
    buttons: [{ text     : 'Ok',
   
    
    handler:() => {
      this.clickcall={};
      // this.modelDissmiss()
       // this.CallConnectModal.hide();
        this.stopCall();
       
        this.getCommoncallsonload1()
    }
  },

]
  });
  await alert.present()
}
else{
    const alert = await this.alert.create({
      header: ans+' Would you like to update?',
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: '',
      buttons: [{ text     : 'Yes',
     
      
      handler:() => {
        // this.clickcall={};
          //this.CallConnectModal.hide();
          // this.modelDissmiss()
          this.stopCall();
          console.log(this.Cusdata);
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile=window.localStorage['mobile'];
          this.EndCallobj.customerName=this.Cusdata.CustomerName;
          this.EndCallobj.customerMobile=this.Cusdata.Mobile
          this.EndCallobj.customerId=this.Cusdata.CBSCustomerID;
          //this.EndCallobj.purpose=this.item.purpose_id;
          this.EndCallobj.purposeText= this.Cusdata.Purpose;
          this.EndCallobj.endStatus= 'I';
          //var currentDate= new Date();
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          // this.Endcall(this.EndCallobj);
          // this.End(this.Cusdata);
            this.endvisit(this.Cusdata)
      }
    },
    {
      text     : 'No',
     
      
      handler:() => {
        this.clickcall={};
        // this.modelDissmiss()
         // this.CallConnectModal.hide();
          this.stopCall();
         
          this.getCommoncallsonload1()
          // this.route.navigateByUrl('/commoncall')
         //this.followupcallsUpdmodal(this.item);
      }
    }
  ]
    });
    await alert.present()
  }
  }
  Endcall1(obj){
    this.endvisit(this.Cusdata)
  }
  Endcall(obj){
    debugger
    this.stopCall()
if(this.repStatus.data.length==0){
  this.endvisit(this.Cusdata)
}else{

    if(this.repStatus.data[0].status2=='ANSWER'){
    this. clickid=this.clickcallID.id
    console.log(obj);
    if(obj.endDate == undefined || obj.endDate == 'undefined' || obj.endDate == null || obj.endDate == ''){
      var enDate= new Date();
      this.endDate =this.datepipe.transform(enDate,'yyyy-MM-dd hh-mm-ss')
      // this.endDate = $filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
      // this.endDate = $filter('date')(enDate, 'hh-mm-ss');
      console.log(this.endDate);
      }else{
        var enDate= new Date(obj.endDate);
        this.endDate =this.datepipe.transform(enDate, 'yyyy-MM-dd hh-mm-ss');
        console.log(this.endDate);
      }
      var curDate= new Date(obj.currDate);
      this.currDate = this.datepipe.transform(curDate, 'yyyy-MM-dd hh-mm-ss');
      console.log(this.currDate);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var purpose = 'Common Calls';
 
                             // <<<---using ()=> syntax
      this.Apiservice.callStatusLead(this.clickid).then((res:any)=>{

        debugger
       res= JSON.stringify(res)
       res=JSON.parse(res)
  
       if(res !='' && res.data == '"\\"\\""'){
        this.Apiservice.callStatusLead(this.clickid).then((res:any)=>{

          debugger
         res= JSON.stringify(res)
         res=JSON.parse(res)
    
        
    
    
         if(res=='' || JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
           
            this.stopCall();
            // console.log($scope.item);
            this.endvisit(this.Cusdata)
          }else{
          
          if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
            // $scope.clickTocallConnect.hide();
            this.stopCall();
            // console.log($scope.item);
            this.endvisit(this.Cusdata)
          }else{
          
          var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
          
          if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
            this.voicerecording='No Record'
          }else{
          this.voicerecording=xyz[0].recording.slice(28)
          }
          if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
          this.location="no record"
          }else{
            this.location=xyz[0].location
          }
          if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
            this.provider="no provider"
          }else{
            this.provider=xyz[0].provider
          }
          if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
            this.status="no status"
          }else{
           this.status=xyz[0].status
          }
          if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
            this.status2="no status"
          }else{
           this.status2=xyz[0].status2
          }
          var objendcall={
            CustId :obj.customerId,
                      CustName :obj.customerName,
                      CustNumber :obj.customerMobile,
                      strUserId :userid,
                      strBranch :branchid,
                      UserNumber :obj.callerMobile,
                      StartTime :xyz[0].start_time,
                      Endtime :xyz[0].end_time,
                      Purpose :purpose,
                      duration :xyz[0].duration,
                      bill :xyz[0].billsec,
                      credit :xyz[0].credits,
                      status :this.status,
                      status1 :this.status2,
                      rec :this.voicerecording,
                      location :this.location,
                      provider :this.provider,
                      callid :this.clickid,
                      rowid :this.rowid
          }
          
          this.Apiservice.endcallconnectnewmethod(objendcall)
            .then((response:any)=> {
                    debugger
                
                    // obj.endStatus == 'I'
                    if(obj.endStatus == '0'){
                 
                   
        
                    this.endcallpopup()
        
                  }else{
                    debugger
                  //  this.clickcall={};
                         
                        this.stopCall();
                          // console.log($scope.item);
                          this.endvisit(this.Cusdata)
                  }
                  },err=>{
                     if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
            return false
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
            return false
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          false
          }
                  })
                  
                
                }
                  }
                })
       }
  
  else{
       if(res=='' || JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
         
          this.stopCall();
          // console.log($scope.item);
          this.endvisit(this.Cusdata)
        }else{
        
        if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
          // $scope.clickTocallConnect.hide();
          this.stopCall();
          // console.log($scope.item);
          this.endvisit(this.Cusdata)
        }else{
        
        var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
        if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
          this.voicerecording='No Record'
        }else{
        this.voicerecording=xyz[0].recording.slice(28)
        }
        if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
        this.location="no record"
        }else{
          this.location=xyz[0].location
        }
        if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
          this.provider="no provider"
        }else{
          this.provider=xyz[0].provider
        }
        if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
          this.status="no status"
        }else{
         this.status=xyz[0].status
        }
        if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
          this.status2="no status"
        }else{
         this.status2=xyz[0].status2
        }
        var objendcall={
          CustId :obj.customerId,
                    CustName :obj.customerName,
                    CustNumber :obj.customerMobile,
                    strUserId :userid,
                    strBranch :branchid,
                    UserNumber :obj.callerMobile,
                    StartTime :xyz[0].start_time,
                    Endtime :xyz[0].end_time,
                    Purpose :purpose,
                    duration :xyz[0].duration,
                    bill :xyz[0].billsec,
                    credit :xyz[0].credits,
                    status :this.status,
                    status1 :this.status2,
                    rec :this.voicerecording,
                    location :this.location,
                    provider :this.provider,
                    callid :this.clickid,
                    rowid :this.rowid
        }
        
        this.Apiservice.endcallconnectnewmethod(objendcall)
          .then((response:any)=> {
                  debugger
              
                  // obj.endStatus == 'I'
                  if(obj.endStatus == '0'){
               
                 
      
                  this.endcallpopup()
      
                }else{
                  debugger
                //  this.clickcall={};
                       
                      this.stopCall();
                        // console.log($scope.item);
                        this.endvisit(this.Cusdata)
                }
                },err=>{
                   if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
            return false
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
            return false
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          return false
          }
                })
                
              
              }
                }}
              })
 
    
    


          }else{
            this.endvisit(this.Cusdata)
          }
        }
  }
  endvisit(items){
    debugger
  // items.startmeetingtime=this.startmeetingtime
    // this.modelshow=true;
    this.Apiservice.assignedcommoncallarray=[]
    this.Apiservice.assignedcommoncallarray.push(items,{close:"endassigncommoncallconnectpage"})
    this.commoncallgrid=false
    this.commoncallupdate=true
    this.commoncallconnect=false
    this.Cusdata1 =this.Apiservice.assignedcommoncallarray
    let Cusdata=this.Cusdata1[0]
    this.savebool=false
    this.getcalloutcome()
    this.commoncallsUpdmodal(Cusdata)
    // this.getCommoncallsonload()
    // this.route.navigateByUrl('/assignedcommonupdate')
    // const modal = await this.modalController.create({
    //   component: MyfollowupvisitendmodelPage,
    //   componentProps: { Data: items }
    // });
    // return await modal.present();
  }

  End(obj) {
  
    this.endvisit(obj)
  // } catch (err) {
  //   console.log(err);
  // }

}
  stopCall(){
    clearInterval(this.interval)
  }
async endcallpopup(){
  debugger
  const alert = await this.alert.create({
    header: 'You have ended the call explicitly. would you like to update?',
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: '',
    buttons: [{ text     : 'Yes',
   
    
    handler:() => {
      // this.clickcall={};
      // this.CallConnectModal.hide();
      // this.alert.dismiss()
       this.stopCall();
       console.log();
       this.End(this.Cusdata);
      //  this.endvisit(this.Cusdata)
    }
  },
  {
    text     : 'No',
   
    
    handler:() => {
      this.clickcall={};
      //this.CallConnectModal.hide();
      this.stopCall();
      // this.alert.dismiss()
       console.log(this.Cusdata);
      //  this.route.navigate(['myfollowupvisitendmodel'])
      // this.endvisit(this.Cusdata)
       //this.followupcallsUpdmodal(this.item);
    }
  }
]
  });
  await alert.present()
}
modelDissmiss(){
  // this.loader.presentLoading('')
debugger
 
  this.getCommoncallsonload1()

}
getCommoncallsonload1() {
  debugger
  var branchid = window.localStorage['branchID'];
  var calltype = "T";
  var custid = " ";
  var purpose =null
  var selectdate=null
 
  this.loaddata = true;
 
  this.loader.presentLoading('')
  this.Apiservice.getcomcallscommon(purpose, branchid, calltype, custid,selectdate).then(response => {
// console.log(response);
debugger
this.search.CBSCustomerID=''
this.search.Purpose=''
this.commoncallupdate=false
this.commoncallconnect=false
this.commoncallgrid=true
this.loader.dismissLoading();
var data = JSON.stringify(response.data);
// result = JSON.parse(result);

this.commoncallsdataonload = JSON.parse(data);
this.commoncallsdataonload = JSON.parse(this.commoncallsdataonload);
this.commoncallsdataonload = JSON.parse(this.commoncallsdataonload);
this.commoncallsdataonloadlength=this.commoncallsdataonload.length


// this.commoncallsdataonload = result;
console.log(this.commoncallsdataonload.length)
var firstname = [];
this.firstWords = [];

for (var i = 0; i < this.commoncallsdataonload.length; i++) {
  firstname = this.commoncallsdataonload[i].CustomerName.split(" ");
  this.firstWords.push(firstname[0]);
  this.commoncallsdataonload[i].firstname = this.firstWords[i];
  if(this.commoncallsdataonload[i].ToCallDate == null || this.commoncallsdataonload[i].ToCallDate == undefined || this.commoncallsdataonload[i].ToCallDate =='' ){
    this.date=null
    this.date_a=null
    this.commoncallsdataonload[i].tofiltercalldate=this.date_a
    
          }else{
  this.date = this.commoncallsdataonload[i].ToCallDate.split('/');
  this.date_a = this.date[1]+'/'+this.date[0]+'/'+this.date[2];
  this.commoncallsdataonload[i].tofiltercalldate = this.date_a;
          }
}
// this.datatofilter = this.commoncallsdataonload;
  });
}
}
   
   