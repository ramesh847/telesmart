import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, MenuController, ModalController, Platform } from '@ionic/angular';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { NativeGeocoder, NativeGeocoderOptions, NativeGeocoderResult } from '@ionic-native/native-geocoder/ngx';
// import { DateFormatPipe } from 'angular2-moment';
import * as moment from 'moment';
import CryptoJS from 'crypto-js';
import { ToastServiceService } from '../service/toast-service.service';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx'
// import * as permissions from '@ionic-native/android-permissions'
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx'
import { DatePipe } from '@angular/common';
import { TrialnotifyPage } from '../trialnotify/trialnotify.page';
// import {Device} from '@ionic-native/device'
// import { Device } from '@ionic-native/device'
// import { UniqueDeviceID, UniqueDeviceIDOriginal } from '@ionic-native/unique-device-id';
// import { UniqueDeviceID } from '@ionic-native/unique-device-id'
// import { UniqueDeviceID } from '@ionic-native/unique-device-id';

// import { Uid } from '@ionic-native/uid/ngx';
// import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { Network } from '@ionic-native/network/ngx';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';

declare var rootdetection: any;
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  providers: [LocationAccuracy, AndroidPermissions,DatePipe,Network ],

})
export class LoginPage implements OnInit {
  logindata: any = { "user_name": "", "password": "" }
  userEncrypted: any;
  pwdEncrypted: any;
  mydata: any;
  mydata1: any;
  footername: any;
  username: any;
  branchposition: boolean;
  //location start
  // Readable Address
  address: string;
  captchares: any;
  // Location coordinates
  latitude: number;
  longitude: number;
  accuracy: number;
  capthchhide: boolean
  invalidOTP: boolean
  randomotp: any;
  showotpdiv: boolean
  userEncryptedsms: any;
  messagecontentsms: any;
  mobilesms: any;
  captchaarray: any[] = []
  //Geocoder configuration
  app_ver: any;
  geoencoderOptions: NativeGeocoderOptions = {
    useLocale: true,
    maxResults: 5
  };
  otp: any;
  usercode: any;
  resver: any;
  UniqueDeviceID: any;
  remainingText: number;
  rootedid: any;
  showspinner: boolean = false;
  loginpage: boolean = true
  timestamp: number;
  app_ver1: any;
  notifyjson: any;
  notifycontent: any;
  currentdate: string;
  notifydate: string;
  getnotify: any;
  tokarray:any[]=[]
  empnamed: string;
  bbbvversion: any;
  logintype:any;
  constructor(private http: HttpClient, private authService: ApiServiceService, private alertService: AlertServiceService,
    private router: Router, private alert: AlertController, private geolocation: Geolocation,
    private nativeGeocoder: NativeGeocoder, private menuCtrl: MenuController, private loader: ToastServiceService,
    private androidPermissions: AndroidPermissions, private platform: Platform, private LocationAccuracy: LocationAccuracy,
    private modalController:ModalController,private datepipe:DatePipe,private network: Network,private faio: FingerprintAIO
  ) {

  

  }

  ngOnInit() {
    debugger
    this.logintype="FP"
    window.localStorage['logintype']=this.logintype
       if(window.localStorage['userName'] == '' || window.localStorage['userName'] ==undefined){
      this.empnamed=''
    }else{
   this.empnamed= window.localStorage['userName']
    }
console.log("login oninit")
    if(//biometric_success
      window.localStorage['biomatric'] == 'biometric_success'){
        // this.router.navigate(['login']);
        this.showFingerprintAuthDlg1()
        
    this.app_ver1 = parseFloat(localStorage.getItem('ver'))
  
    this.logindata = {}
   
 this.tokarray=[]
 this.capthchhide = true
 this.getcaptcha()
 console.log(this.constructor.name);
 if (this.constructor.name == "LoginPage") {
   this.menuCtrl.enable(false);
 }
       }else{
        window.localStorage['logintype']="WFP"
        this.app_ver1 = parseFloat(localStorage.getItem('ver'))
  
        this.logindata = {}
       
        this.capthchhide = true
       
    
     this.tokarray=[]
      this.getcaptcha()
    
    
        
        console.log(this.constructor.name);
        if (this.constructor.name == "LoginPage") {
          this.menuCtrl.enable(false);
        }
      }


//     this.app_ver1 = parseFloat(localStorage.getItem('ver'))
  
//     this.logindata = {}
   
//     this.capthchhide = true
   

//  this.tokarray=[]
//   this.getcaptcha()


    
//     console.log(this.constructor.name);
//     if (this.constructor.name == "LoginPage") {
//       this.menuCtrl.enable(false);
//     }
  

  }
  public showFingerprintAuthDlg1() {
    debugger

        this.faio.isAvailable().then((result: any) => {
          debugger
          console.log(result)
    
          this.faio.show({
            cancelButtonTitle: 'Cancel',
            description: "",
            disableBackup: true,
            title:  this.empnamed,
            fallbackButtonTitle: 'FB Back Button',
            subtitle: ''
          })
            .then((result: any) => {
              debugger
              console.log(result)
              //biometric_success
              this.logintype="FP"
              window.localStorage['logintype']=this.logintype
              this.fingerlogin()
              // this.alertService.presentAlert("",result)
              // alert("Successfully Authenticated!")
            })
            .catch((error: any) => {
              debugger
              console.log(error.message)
              this.logintype="WFP"
              window.localStorage['logintype']=this.logintype
              // when cancel button click->BIOMETRIC_DISMISSED
              // this.alertService.presentAlert("",error.message)
              // alert("Match not found!")
            });
    
        })
          .catch((error: any) => {
            debugger
            // biomatric not enroled
            this.alertService.presentAlert("",error.message)
            console.log(error.message)
          });
      }
 

//finger print login start

fingerlogin() {
  debugger


this.gpslocation1()
  // this.getGeolocation()
}
gpslocation1(){
  debugger
  this.loader.presentLoadinglogin('')
  this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION).then(
    result => {
      debugger
      this.loader.dismissLoading()
      if (result.hasPermission) {

        //If having permission show 'Turn On GPS' dialogue
        this.askToTurnOnGPS1();
      } else {

        //If not having permission ask for permission
        this.requestGPSPermission1();
      }
    },
    err => {
      this.loader.dismissLoading()
      this.alertService.presentAlert("",err);
      this.showFingerprintAuthDlg1()
    }
  );
}
askToTurnOnGPS1() {
  debugger
  this.LocationAccuracy.request(this.LocationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
    (res:any) => {
      debugger
      var xyz=res
      this.authService.uvrlocationarray.push(xyz.code)
      // window.localStorage['errcode']=xyz.code
      // this.alertService.presentAlert('', "location enabled")
      // When GPS Turned ON call method to get Accurate location coordinates
      this.getGeolocation1()
    },
    err =>{ 
      debugger
      console.log(err)
      this.authService.uvrlocationarray.push(err.code)
      // window.localStorage['errcode']=err.code
      this.logoutlogin()
      // this.alertService.presentAlert('Error', err.message)
      // this.alertService.presentAlert("","Please Enable Location")
      // alert('Error requesting location permissions ' + JSON.stringify(error))
    }
  );
}
getGeolocation1() {
  debugger
this.loader.presentLoadinglogin('')
  navigator.geolocation.getCurrentPosition((resp) => {
    debugger
    this.loader.dismissLoading()
    this.latitude = resp.coords.latitude;
    this.longitude = resp.coords.longitude;
    this.accuracy = resp.coords.accuracy;
    this.timestamp = resp.timestamp;

    window.localStorage['latitude'] = this.latitude
    window.localStorage['longitude'] = this.longitude
    window.localStorage['accuracy'] = this.accuracy
window.localStorage['timestamp']=this.timestamp

    // this.doLogingeo()
    // this.getGeoencoder(resp.coords.latitude, resp.coords.longitude);
    this.logoutlogin()

  },err=>{
    debugger
    this.loader.dismissLoading()
    this.alertService.presentAlert("",err.message)
    this.showFingerprintAuthDlg1()
  })


}
requestGPSPermission1() {
  debugger
  this.LocationAccuracy.canRequest().then((canRequest: boolean) => {
    debugger
    if (canRequest) {
      console.log("4");
    } else {
      
      this.askToTurnOnGPS1();
    }
  });
}






logoutlogin(){
debugger
this.authService.getversion().then((resp) => {
debugger
this.loader.dismissLoading()
console.log(resp);
var response = JSON.parse(resp.data)
let live_version_resp: any = JSON.parse(response);
console.log(live_version_resp);
let live_version: any = parseFloat(live_version_resp.Table[0].Version);
localStorage.setItem('live_ver', live_version);
console.log(parseFloat(live_version), parseFloat(localStorage.getItem('ver')));
var app_version = parseFloat(localStorage.getItem('ver'));


  if(1==1)
 {
  console.log("version matched");


 let userCode= window.localStorage['empusercode']
 
 let Pwd= window.localStorage['password']
var obj = {
    strUserCode: userCode,
    strPassword: Pwd,
    
  }


  this.authService.login(obj).then((resp) => {
    console.log(resp);
    debugger
    // this.loader.dismissLoading()
    var response = JSON.parse(resp.data);
    this.mydata = response;
    console.log(this.mydata);
    
    debugger




    

      if (1 == 1)  {
        window.localStorage['userID'] = this.mydata[0].UserId;
        window.localStorage['branchID'] = this.mydata[0].BranchId;
        window.localStorage['branchCode'] = this.mydata[0].BranchCode;
        window.localStorage['userCode'] = this.mydata[0].UserCode;
        this.footername = window.localStorage['userCode'];
        window.localStorage['userName'] = this.mydata[0].UserName;
        this.username = window.localStorage['userName'];
        window.localStorage['userType'] = this.mydata[0].UserType;
        window.localStorage['BranchDescription'] = this.mydata[0].BranchDescription;
        window.localStorage['mobile'] = this.mydata[0].mobile;
        // this.branchposition = false;

        debugger
this.authService.userlogininfo(window.localStorage['userID'],window.localStorage.deviceID, window.localStorage['logintype']).then((res:any)=>{
debugger
})

        this.authService.updateversion(this.mydata[0].BranchId, this.mydata[0].UserId, localStorage.getItem('ver')).then((resp) => {
          console.log(resp)
        })
          this.loader.dismissLoading()
        this.popupshow()

      } else {
        if (this.mydata[0].DeviceId == '' || this.mydata[0].DeviceId ==null) {
          this.loader.dismissLoading()
          // this.checkdeviceid()

        } else {
          this.loader.dismissLoading()
          this.alertService.presentAlert('Login Failed', 'Invalid Device');
          // this.getcaptcha()
        }
      }
    
  }, (err) => {
    debugger
    this.loader.dismissLoading()
    console.log(err)
    this.alertService.presentAlert("", err.error)
  })
} else {

  console.log("version mismatched");
  
  this.mismatched()
  // this.alertService.presentAlert('Login Failed', 'Your App has been outdated. Please download and install the latest app to continue using Telesmart. ');
}

}, (err) => {
debugger
this.loader.dismissLoading()
console.log(err);

this.alertService.presentAlert("",err.error)
})
}

// end









  getcaptcha() {
   
    debugger

    this.tokarray=[]

    const characters ='23456789ABCDEFGHJKMNPQRSTUVWYZ'
    let result = ' ';
    const charactersLength = characters.length;
    for ( let i = 0; i <6; i++ ) {
        result = characters.charAt(Math.floor(Math.random() * charactersLength));
        this.tokarray.push(result)
    }
    this.captchares=this.tokarray[0]+this.tokarray[1]+this.tokarray[2]+this.tokarray[3]+this.tokarray[4]+this.tokarray[5]
    console.log("pageloadcaptcha",this.captchares)
  }
  getcpt() {
    debugger

    // this.authService.getcaptcha().then((resp: any) => {
    //   debugger
    //   this.captchares = JSON.parse(JSON.parse(resp.data))
    //   this.capthchhide = false
    // })
    this.tokarray=[]

    const characters ='23456789ABCDEFGHJKMNPQRSTUVWYZ'
    let result = ' ';
    const charactersLength = characters.length;
    for ( let i = 0; i <= 6; i++ ) {
        result = characters.charAt(Math.floor(Math.random() * charactersLength));
        this.tokarray.push(result)
    }
    this.captchares=this.tokarray[0]+this.tokarray[1]+this.tokarray[2]+this.tokarray[3]+this.tokarray[4]+this.tokarray[5]
    this.capthchhide = false


  }
  getcpt1() {
    debugger
// this.loader.presentLoadingloginassign('')
    // this.authService.getcaptcha().then((resp: any) => {
    //   debugger
    //   // this.loader.dismissLoading()
    //   this.captchares = JSON.parse(JSON.parse(resp.data))
    //   this.capthchhide = true
    // }, err=>{
    //   debugger
    //   console.log(err);
    //  this.alertService.presentAlert("","Please Try After Some Time")

   
    // })
    this.tokarray=[]
    const characters ='23456789ABCDEFGHJKMNPQRSTUVWYZ'
    let result = ' ';
    const charactersLength = characters.length;
    for ( let i = 0; i < 6; i++ ) {
        result = characters.charAt(Math.floor(Math.random() * charactersLength));
        this.tokarray.push(result)
    }
    this.captchares=this.tokarray[0]+this.tokarray[1]+this.tokarray[2]+this.tokarray[3]+this.tokarray[4]+this.tokarray[5]
    this.capthchhide = true
  }
  resetPwd() {
    this.router.navigate(['/forgotpwd'])
  }
  doLogin1() {
    debugger
    this.getGeolocation()
    if (this.logindata.user_name == '' && this.logindata.password == '') {
      this.alertService.presentAlert('Login Failed', "Please Enter The Credentials..");
    }
    else if (this.logindata.user_name == '') {
      this.alertService.presentAlert('Login Failed', "Please Enter The Emp Code");
    }
    else if (this.logindata.password == '') {
      this.alertService.presentAlert('Login Failed', "Please Enter The Password");
    }
    else if (this.logindata.user_name = '3442' && this.logindata.password == '12') {

      let data1 = {
        "strUserCode": "8C9fn2A3KFGhSLmzJtuqzA==",
        "strPassword": "tDMbWUk/l26gcPQgdLykAg=="
      }
      this.loader.presentLoadinglogin('')
      this.authService.login(data1).then((res: any) => {
        console.log(res)
        this.loader.dismissLoading()
        if (res.length != 0) {
          // localStorage.setItem('userID', '2606');
          // localStorage.setItem('branchID', '329');
          // localStorage.setItem('branchCode', '329');
          // localStorage.setItem('userCode', '3442');

          // localStorage.setItem('userName','Nagaraj');
          // localStorage.setItem('userType', '11');
          // localStorage.setItem('mobile', '9490739835');
          this.mydata = JSON.parse(res.data)
          window.localStorage['userID'] = this.mydata[0].UserId;
          window.localStorage['branchID'] = this.mydata[0].BranchId;
          window.localStorage['branchCode'] = this.mydata[0].BranchCode;
          window.localStorage['userCode'] = this.mydata[0].UserCode;
          // $rootScope.footername = window.localStorage['userCode'];
          window.localStorage['userName'] = this.mydata[0].UserName;
          // $rootScope.username = window.localStorage['userName'];
          window.localStorage['userType'] = this.mydata[0].UserType;
          window.localStorage['BranchDescription'] = this.mydata[0].BranchDescription;
          window.localStorage['mobile'] = this.mydata[0].mobile;

          // window.localStorage['userID'] = this.mydata[0].UserId;
          // window.localStorage['branchID'] = this.mydata[0].BranchId;
          // window.localStorage['branchCode'] = this.mydata[0].BranchCode;
          // window.localStorage['userCode'] = this.mydata[0].UserCode;
          // $rootScope.footername = window.localStorage['userCode'];
          // window.localStorage['userName'] = this.mydata[0].UserName;
          // $rootScope.username = window.localStorage['userName'];
          // window.localStorage['userType'] = this.mydata[0].UserType;
          // window.localStorage['BranchDescription'] = this.mydata[0].BranchDescription;
          // window.localStorage['mobile'] = this.mydata[0].mobile;


          // localStorage.setItem("branchID",res[0].BranchCode);
          // localStorage.setItem("userID",res[0].UserCode);
          this.menuCtrl.enable(true);
          this.router.navigate(['/myplanner']);
        }
      }).catch((error) => {
        this.alertService.presentAlert('failed', console.error(error));

      });


    }
    else {
      this.alertService.presentAlert('Login Failed', 'Invalid Credentials..');
    }
  }
 
  doLoginx() {
    // var permissions = cordova.plugins.permissions;
    debugger



    this.androidPermissions.checkPermission(
      this.androidPermissions.PERMISSION.READ_PHONE_STATE
    ).then(res => {
      debugger
      if (res.hasPermission) {

      } else {
        this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.READ_PHONE_STATE).then(res => {
          debugger
          alert("Persmission Granted Please Restart App!");
          // this.getUniqueDeviceID()
          // this.uuuuid()
        }).catch(error => {
          alert("Error! " + error);
        });
      }
    }).catch(error => {
      debugger
      alert("Error! " + error);
    });

  }





  doLogin() {
    debugger
 

this.gpslocation()
    // this.getGeolocation()
  }
  gpslocation(){
    debugger
    this.loader.presentLoading('')
    this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION).then(
      result => {
        debugger
        this.loader.dismissLoading()
        if (result.hasPermission) {
  
          //If having permission show 'Turn On GPS' dialogue
          this.askToTurnOnGPS();
        } else {
          this.loader.dismissLoading()
          //If not having permission ask for permission
          this.requestGPSPermission();
        }
      },
      err => {
        this.loader.dismissLoading()
        this.alertService.presentAlert("",err);
      }
    );
  }
  askToTurnOnGPS() {
    debugger
    this.loader.presentLoadinglogin('')
    this.LocationAccuracy.request(this.LocationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
      (res:any) => {
        debugger
        this.loader.dismissLoading()
        var xyz=res
        this.authService.uvrlocationarray.push(xyz.code)
        // window.localStorage['errcode']=xyz.code
        // this.alertService.presentAlert('', "location enabled")
        // When GPS Turned ON call method to get Accurate location coordinates
        this.getGeolocation()
      },
      err =>{ 
        debugger
        this.loader.dismissLoading()
        console.log(err)
        this.authService.uvrlocationarray.push(err.code)
        // window.localStorage['errcode']=err.code
        this.doLogingeo()
        // this.alertService.presentAlert('Error', err.message)
        // this.alertService.presentAlert("","Please Enable Location")
        // alert('Error requesting location permissions ' + JSON.stringify(error))
      }
    );
  }
  requestGPSPermission() {
    debugger
    this.loader.presentLoadinglogin('')
    this.LocationAccuracy.canRequest().then((canRequest: boolean) => {
      debugger
      this.loader.dismissLoading()
      if (canRequest) {
        console.log("4");
      } else {
        
        this.askToTurnOnGPS();
      }
    });
  }
  doLogingeo() {
    debugger


this.loader.presentLoadinglogin('')

    var base64Key = CryptoJS.enc.Utf8.parse('7b3e4c8e58d5c4f22e86c92a4a3a8a25');
    console.log(base64Key)
    var iv = CryptoJS.enc.Utf8.parse('2a4fc2da7e2a9e68');

    console.log(this.logindata.user_name, this.logindata.password)
    if ((this.logindata.user_name == '' || this.logindata.user_name == undefined || this.logindata.user_name == null) && (this.logindata.password == '' || this.logindata.password == undefined || this.logindata.password == null)) {

      // var myPopup = $ionicPopup.show({
      //   template: '<center>Please Enter The Credentials..</center>',
      //   title: 'Login Failed',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      this.loader.dismissLoading()
      this.alertService.presentAlert('Login Failed', 'Please Enter The Credentials..');
      this.getcaptcha()
      return false;

    }

    if (this.logindata.user_name != '' || this.logindata.user_name != undefined || this.logindata.user_name !=null) {
      if (this.logindata.password == '' || this.logindata.password == undefined || this.logindata.password == null) {

        // var myPopup = $ionicPopup.show({
        //   template: '<center>Please Enter The Password..</center>',
        //   title: 'Login Failed',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        this.loader.dismissLoading()
        this.alertService.presentAlert('Login Failed', 'Please Enter The Password..');
        this.getcaptcha()
        return false;

      }
    }

    if (this.logindata.password != '' || this.logindata.password != undefined || this.logindata.password != null) {
      if (this.logindata.user_name == undefined || this.logindata.user_name == '' || this.logindata.user_name == null) {

        // var myPopup = $ionicPopup.show({
        //   template: '<center>Please Enter The UserCode..</center>',
        //   title: 'Login Failed',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        this.loader.dismissLoading()
        this.alertService.presentAlert('Login Failed', 'Please Enter The UserCode..');
        this.getcaptcha()
        return false;

      }
    }
    var live_version = parseFloat(localStorage.getItem('live_ver'));
    var app_version = parseFloat(localStorage.getItem('ver'));
    // console.log(parseFloat(localStorage.getItem('live_ver')),parseFloat(localStorage.getItem('ver')));



    // if ((this.logindata.user_name != null || this.logindata.user_name != undefined || this.logindata.user_name != '') && (this.logindata.password != '' || this.logindata.password != undefined || this.logindata.password != null))
      if ((this.logindata.user_name != null || this.logindata.user_name != undefined || this.logindata.user_name != '') && (this.logindata.password != '' || this.logindata.password != undefined || this.logindata.password != null) && (this.logindata.captcha == '' || this.logindata.captcha == undefined || this.logindata.captcha == null)) {
        this.loader.dismissLoading()
        this.alertService.presentAlert('', 'Please Enter The Captcha');
        this.getcaptcha()
        return false;

      } else if (this.logindata.captcha.toUpperCase() != this.captchares) {
        this.loader.dismissLoading()

        this.logindata.captcha = ''
        this.getcaptcha()
        this.alertService.presentAlert('', 'Please Enter The Valid Captcha');

        return false;
        

      } else {
        var userName = this.logindata.user_name.toString();
        this.userEncrypted = CryptoJS.AES.encrypt(userName, base64Key, { iv: iv });
        // console.log('userEncrypted = ' +  this.userEncrypted);
        var userCode = this.userEncrypted.toString();
        window.localStorage['empusercode']=userCode
        this.pwdEncrypted = CryptoJS.AES.encrypt(this.logindata.password, base64Key, { iv: iv });
        // console.log('pwdEncrypted = ' + this.pwdEncrypted);
        var Pwd = this.pwdEncrypted.toString();
        window.localStorage['password']=Pwd

        var obj = {
          strUserCode: userCode,
          strPassword: Pwd,
          
        }
        // this.showspin();
this.loader.presentLoadinglogin('')
        this.authService.getversion().then((resp) => {
          debugger
          this.loader.dismissLoading()
          console.log(resp);
          var response = JSON.parse(resp.data)
          let live_version_resp: any = JSON.parse(response);
          console.log(live_version_resp);
          let live_version: any = parseFloat(live_version_resp.Table[0].Version);
          localStorage.setItem('live_ver', live_version);
          console.log(parseFloat(live_version), parseFloat(localStorage.getItem('ver')));
          var app_version = parseFloat(localStorage.getItem('ver'));

          // if(live_version == app_version){ cmd by ramesh
          // if(live_version == app_version) {
            if(1 == 1)
           {
            console.log("version matched");




            //do login
            this.loader.presentLoadinglogin('')
            this.authService.login(obj).then((resp) => {
              console.log(resp);
              debugger
              this.loader.dismissLoading()
              var response = JSON.parse(resp.data);
              this.mydata = response;
              console.log(this.mydata);
              // if(this.mydata[0].Column1 == "Invalid User Code"){
              //   this.alertService.presentAlert('Login Failed', 'Invalid User Code');
              // } else if(this.mydata[0].Column1 =="Invalid Password"){
              //   this.alertService.presentAlert('Login Failed', 'Invalid Password');
              //   // alert('Invalid User Code')
              // }
              debugger

if(this.mydata[0].Column1 == "Invalid Password"){
  this.mydata[0].Column1="Incorrect Password"
  this.logindata = {}
                this.loader.dismissLoading()
                this.alertService.presentAlert('', this.mydata[0].Column1);
                this.getcaptcha()
                return false
}else if(this.mydata[0].Column1 == "Invalid User Code" || this.mydata[0].Column1 == "User Password Locked" || this.mydata[0].Column1 == "User InActive" || this.mydata[0].Column1 == "User Validity Expired" || this.mydata[0].Column1 == "password Locked" || this.mydata[0].Column1 == 'Mobile Access Not Found' || this.mydata[0].Column1 == 'You do not have any function access'){
  this.logindata = {}
                this.loader.dismissLoading()
                this.alertService.presentAlert('', this.mydata[0].Column1);
                this.getcaptcha()
                return false
}

              // if (this.mydata[0].Column1 == "Invalid User Code" || this.mydata[0].Column1 == "Invalid Password" || this.mydata[0].Column1 == "User Password Locked" || this.mydata[0].Column1 == "User InActive" || this.mydata[0].Column1 == "User Validity Expired" || this.mydata[0].Column1 == "password Locked" || this.mydata[0].Column1 == 'Mobile Access Not Found' || this.mydata[0].Column1 == 'You do not have any function access') {
              //   this.logindata = {}
              //   this.loader.dismissLoading()
              //   this.alertService.presentAlert('', this.mydata[0].Column1);
              //   this.getcaptcha()
              //   return false
              // }


              else {
// this.loader.dismissLoading()
                debugger
                //  this. storeUserCredentials(this.mydata[0].SessionID,this.mydata[0].UserCode);
                //For Production uncomment below
                // if (this.mydata[0].DeviceId == window.localStorage.deviceID) {
                //Testing uncomment below
                // if(1 == 1)
                if (1 == 1)  {
                  window.localStorage['userID'] = this.mydata[0].UserId;
                  window.localStorage['branchID'] = this.mydata[0].BranchId;
                  window.localStorage['branchCode'] = this.mydata[0].BranchCode;
                  window.localStorage['userCode'] = this.mydata[0].UserCode;
                  this.footername = window.localStorage['userCode'];
                  window.localStorage['userName'] = this.mydata[0].UserName;
                  this.username = window.localStorage['userName'];
                  window.localStorage['userType'] = this.mydata[0].UserType;
                  window.localStorage['BranchDescription'] = this.mydata[0].BranchDescription;
                  window.localStorage['mobile'] = this.mydata[0].mobile;
                  this.branchposition = false;

                  debugger
this.authService.userlogininfo(window.localStorage['userID'],window.localStorage.deviceID,window.localStorage['logintype']).then((res:any)=>{

})

                  this.authService.updateversion(this.mydata[0].BranchId, this.mydata[0].UserId, localStorage.getItem('ver')).then((resp) => {
                    console.log(resp)
                  })
                  // .error((err){
                  //   console.log(err);
                  // })
                  debugger
                  // this.menuCtrl.enable(true)
                  // this.logindata = {}
                  // this.authService.notifyarray=[]
                  // this.authService.setData(this.mydata[0].UserType);
                  // if (window.localStorage['userType'] == 17) {
                  //   // $state.go('app.newsummary');
                  //   this.router.navigate(['/newsummary']);
                
                  // } else if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
                   
                  //   this.popupshow()
                
                  // } else if(window.localStorage['userType'] == 30){
                  //   this.router.navigate(['/advancecommitmentsummary']);
                  // }
                  // else {
                  //   this.router.navigate(['/myplanner']);
                    
                  // }
this.loader.dismissLoading()
                  this.popupshow()

                } else {
                  if (this.mydata[0].DeviceId == '' || this.mydata[0].DeviceId ==null) {
                    this.loader.dismissLoading()
                    this.checkdeviceid()

                  } else {
                    this.loader.dismissLoading()
                    this.alertService.presentAlert('Login Failed', 'Invalid Device');
                    this.getcaptcha()
                  }
                }
              }
            }, (err) => {
              debugger
              this.loader.dismissLoading()
              console.log(err)
              this.alertService.presentAlert("", err.error)
            })
          } else {

            console.log("version mismatched");
            
            this.mismatched()
            // this.alertService.presentAlert('Login Failed', 'Your App has been outdated. Please download and install the latest app to continue using Telesmart. ');
          }

        }, (err) => {
          debugger
          this.loader.dismissLoading()
          console.log(err);

          this.alertService.presentAlert("",err.error)
        })



      }
    

  }
  popupshow(){
debugger
   
      this.authService.Getmobileappnotificationlogin().then((res)=>{
        debugger
      this.authService.notifyarray.push('1')

if(JSON.parse(res.data) == 'No record'){
  this.menuCtrl.enable(true)
  this.logindata = {}
  this.authService.notifyarray=[]
  this.authService.setData(this.mydata[0].UserType);
  if (window.localStorage['userType'] == 17) {
    // $state.go('app.newsummary');
    this.router.navigate(['/newsummary']);

  } else if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
   
    this.router.navigate(['/regionsummary']);

  } else if(window.localStorage['userType'] == 30){
    this.router.navigate(['/advancecommitmentsummary']);
  }
  else {
    this.router.navigate(['/myplanner']);
    
  }
} else{
  this.notifyjson=JSON.parse(JSON.parse(res.data))
      
  let date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
  this.notifydate = this.datepipe.transform( this.notifyjson[0].ExpiryDate,'YYYY-MM-dd')
  
  
  if(this.notifydate<date){
  // hide notification
 

  this.menuCtrl.enable(true)
  this.logindata = {}
  this.authService.notifyarray=[]
  this.authService.setData(this.mydata[0].UserType);
  if (window.localStorage['userType'] == 17) {
    // $state.go('app.newsummary');
    this.router.navigate(['/newsummary']);

  } else if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
   
    this.router.navigate(['/regionsummary']);

  } else if(window.localStorage['userType'] == 30){
    this.router.navigate(['/advancecommitmentsummary']);
  }
  else {
    this.router.navigate(['/myplanner']);
    
  }



  console.log("date expiry")
  }else{
    this.menuCtrl.enable(true)
  this.logindata = {}
  this.authService.notifyarray=[]
  this.authService.setData(this.mydata[0].UserType);
  if (window.localStorage['userType'] == 17) {
    // $state.go('app.newsummary');
    this.router.navigate(['/newsummary']);

  } else if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
   
    this.router.navigate(['/regionsummary']);

  } else if(window.localStorage['userType'] == 30){
    this.router.navigate(['/advancecommitmentsummary']);
  }
  else {
    this.router.navigate(['/myplanner']);
    
  }

    if(this.notifyjson[0].Content == undefined){
      this.notifycontent=''
      this.modalp()
    }else{
      this.notifycontent=this.notifyjson[0].Content
      this.modalp()
    }
  
   
   
  }
}

    
      })
    
    
     
     }
     async modalp (){
      debugger
      const modal = await this.modalController.create({
       component: TrialnotifyPage,
       componentProps: { },
       cssClass: "image-popup-modal-css"
     });
     return await modal.present();
       // console.log("12",item);
   
       // this.branchdata = item;
       // this.branchid = item.BranchID;
       // console.log("branchData",this.branchdata)
       // this.RDMbranchEmployees.show();
   
     }
 

  async mismatched() {
    const alert = await this.alert.create({
      header: 'Your App has been outdated. Please download and install the latest app to continue using Telesmart. ',
      cssClass: 'alertHeader',
      // subHeader: 'Subtitle',
      message: '',
      buttons: [{
        text: 'Proceed',


        handler: () => {

          window.open('https://cityunionbank.com/telesmart/', '_system');




        }
      },


      ]
    });
    await alert.present()

  }
  verifyotp(otpentered) {
    debugger
    var userName = this.logindata.user_name.toString();


    if (otpentered.toString().length == 4) {
      if (otpentered == this.randomotp) {
        this.invalidOTP = false;
        // var xml_data = '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><VerifySMS xmlns="http://tempuri.org/"><strUserCode>' + userEncrypted + '</strUserCode><DeviceId>' + DeviceEncrypted + '</DeviceId></VerifySMS></soap:Body></soap:Envelope>';
        var xml_data = {
          strUserCode: userName,
          DeviceId: window.localStorage.deviceID
        }
        // this.showspin();
        this.authService.storedeviceId(xml_data).then((resp: any) => {
          debugger


          this.alertService.presentAlert("", resp.data)

        })
        this.logindata.otp = undefined;
        this.showotpdiv = false;
        this.loginpage = true
      } else {
        this.invalidOTP = true;
      }
    } else {
      this.invalidOTP = true;
    }
  };
  async checkdeviceid() {

    debugger
    var base64Key = CryptoJS.enc.Utf8.parse('7b3e4c8e58d5c4f22e86c92a4a3a8a25');
    console.log(base64Key)
    var iv = CryptoJS.enc.Utf8.parse('2a4fc2da7e2a9e68');

    const alert = await this.alert.create({
      header: 'Your device is not verified yet,please verify your device to continue',
      cssClass: 'alertHeader',
      // subHeader: 'Subtitle',
      message: '',
      buttons: [{
        text: 'Yes',


        handler: () => {


          debugger
          if (this.logindata.user_name == '') {
            this.alertService.presentAlert('Login Failed', "Please enter the user code")
            return false;
          }
          //  this.verifydevice1();

          var userName = this.logindata.user_name.toString();


          var object = {
            strUserCode: userName,
            Version:parseFloat(localStorage.getItem('ver'))
          }
          this.loader.presentLoadinglogin('')
          this.authService.getusermobile(object).then((resp: any) => {
            debugger
            this.loader.dismissLoading()
            // this.mydata1 = JSON.parse(resp.data);
            if(JSON.parse(resp.data) == 'Kindly Download telesmart app www.cityunionbank.com/telesmart'){
this.godownload()
            }else
            if (JSON.parse(resp.data).length == 0) {


              this.alertService.presentAlert("", "Please enter valid user code")
              return false;
            } else {
              this.loginpage = false
              this.showotpdiv = true;
              this.randomotp = Math.floor(Math.random() * 9000) + 1000;
              var msg_content = 'Hi ' + JSON.parse(resp.data)[0].UserName + '. Your OTP is ' + this.randomotp;
              var mobile = JSON.parse(resp.data)[0].Mobile;



              var userNamesms = this.logindata.user_name.toString();
              this.userEncryptedsms = CryptoJS.AES.encrypt(userNamesms, base64Key, { iv: iv });
              var uname = this.userEncryptedsms.toString();
              // console.log('userEncrypted = ' +  $scope.userEncrypted);
              var messagecontent = msg_content.toString();
              this.messagecontentsms = CryptoJS.AES.encrypt(messagecontent, base64Key, { iv: iv });
              // console.log('pwdEncrypted = ' + $scope.pwdEncrypted);
              var content = this.messagecontentsms.toString();

              var mobilesms = mobile.toString();
              this.mobilesms = CryptoJS.AES.encrypt(mobilesms, base64Key, { iv: iv });
              // console.log('pwdEncrypted = ' + $scope.pwdEncrypted);
              var smobile = this.mobilesms.toString();
var vversion=localStorage.getItem('ver').toString()
this.bbbvversion = CryptoJS.AES.encrypt(vversion, base64Key, { iv: iv });
// console.log('pwdEncrypted = ' + $scope.pwdEncrypted);
var vrversion = this.bbbvversion.toString();



              var body = {
                strUserCode: uname,
                Mobile: smobile,
                Message: content,
                // Version:vrversion
              }

              this.authService.sendverificationsms(body).then((res:any)=>{
                debugger
              });
              debugger
              this.alertService.presentAlert("", "Verificartion SMS with OTP has been sent to your registered mobile number..")
              // var myPopup = $ionicPopup.show({
              //   template: '<center>Verificartion SMS with OTP has been sent to your registered mobile number..</center>',
              //   title: 'Message',
              //   scope: this,
              //   buttons: [{
              //     text: 'OK',
              //     type: 'button button-clear button-assertive'
              //   }]
              // });
            }
          })



        }
      },

      {
        text: 'No',


        handler: () => {

        }
      }
      ]
    });
    await alert.present()

  }

  async godownload(){
    debugger
    const alert = await this.alert.create({
      header: '',
      cssClass: 'alertHeader',
      // subHeader: 'Subtitle',
      message: 'Kindly Download telesmart app www.cityunionbank.com/telesmart',
      buttons: [{
        text: 'Ok',


        handler: () => {
          window.open('https://cityunionbank.com/telesmart/', '_system');
        }
      }],
      // {
      //     text: 'No',
    
      //     handler: () => {
          
      //     }}]
    })
    await alert.present()
  }


  storeUserCredentials(token, usercode) {
    debugger
    var LOCAL_TOKEN_KEY = 'Token';
    window.localStorage.setItem(LOCAL_TOKEN_KEY, token);
    window.sessionStorage.setItem('sessionid', token + '_' + usercode);
    //useCredentials(token);
  }
  getGeolocation() {
    debugger
this.loader.presentLoading('')
    navigator.geolocation.getCurrentPosition((resp) => {
      debugger
      this.loader.dismissLoading()
      this.latitude = resp.coords.latitude;
      this.longitude = resp.coords.longitude;
      this.accuracy = resp.coords.accuracy;
      this.timestamp = resp.timestamp;

      window.localStorage['latitude'] = this.latitude
      window.localStorage['longitude'] = this.longitude
      window.localStorage['accuracy'] = this.accuracy
window.localStorage['timestamp']=this.timestamp

      // this.doLogingeo()
      // this.getGeoencoder(resp.coords.latitude, resp.coords.longitude);
      this.doLogingeo()

    },err=>{
      debugger
      this.loader.dismissLoading()
      this.alertService.presentAlert("",err.message)
    })




//     this.geolocation.getCurrentPosition({
//       timeout: 10000,
//       enableHighAccuracy: true
//     }

//     ).then((resp) => {
//       debugger
//       this.latitude = resp.coords.latitude;
//       this.longitude = resp.coords.longitude;
//       this.accuracy = resp.coords.accuracy;
//       this.timestamp = resp.timestamp;

//       window.localStorage['latitude'] = this.latitude
//       window.localStorage['longitude'] = this.longitude
//       window.localStorage['accuracy'] = this.accuracy
// window.localStorage['timestamp']=this.timestamp

//       // this.doLogingeo()
//       this.getGeoencoder(resp.coords.latitude, resp.coords.longitude);
//       this.doLogingeo()

//     })
//       .catch((error) => {
//         debugger
//         // alert('Error getting location' + JSON.stringify(error));
//         this.alertService.presentAlert("", error)
//       });

  }

  //geocoder method to fetch address from coordinates passed as arguments
  getGeoencoder(latitude, longitude) {
    debugger
    this.nativeGeocoder.reverseGeocode(latitude, longitude, this.geoencoderOptions)
      .then((result: NativeGeocoderResult[]) => {
        debugger
        this.address = this.generateAddress(result[0]);
      })
      .catch((error: any) => {
        // this.alertService.presentAlert("",'Error getting location' + JSON.stringify(error));
      });
  }

  //Return Comma saperated address
  generateAddress(addressObj) {
    debugger
    let obj = [];
    let address = "";
    for (let key in addressObj) {
      obj.push(addressObj[key]);
    }
    obj.reverse();
    for (let val in obj) {
      if (obj[val].length)
        address += obj[val] + ', ';
    }
    return address.slice(0, -2);
  }
  showcaptcha(name: any) {
    debugger


    if (name.length >= 4) {
      this.getcpt1()
      // this.capthchhide=true
    }


    else {
      this.capthchhide = false
    }
  }

}
