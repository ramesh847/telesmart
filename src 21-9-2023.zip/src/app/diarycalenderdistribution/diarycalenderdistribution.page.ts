import { Component, OnInit } from '@angular/core';
import {ApiServiceService } from './../service/api-service.service';
import {Router } from '@angular/router';
import { ToastServiceService } from '../service/toast-service.service';
import { AlertServiceService } from '../service/alert-service.service';
import { RMCustViewPage } from '../modal/rmcust-view/rmcust-view.page';
import { ModalController } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';

@Component({
  selector: 'app-diarycalenderdistribution',
  templateUrl: './diarycalenderdistribution.page.html',
  styleUrls: ['./diarycalenderdistribution.page.scss'],
  providers:[Idle]
})
export class DiarycalenderdistributionPage implements OnInit {
  userType : any;
  wishdataresp: any;
  dataresp: any;
  datarespending: any;
  data :any = {};
  custID: any;
  wishdatapendingresp: any;
  datarespendinglength: any;
  datarespendingbool:boolean
  wishbool:boolean
  userid: any;
  branchid: any;
  datarespRM: any;
  datarespRMlength: any;
  idleState: string;
  getnummmm:any;
  constructor(private apiService: ApiServiceService, private router: Router,private loader:ToastServiceService,
    private AlertService:AlertServiceService, public modalController: ModalController,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(2*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      );}

  ngOnInit() {
    

    // this.datarespendingbool=false
    this. userid = window.localStorage['userID'];;
    this. branchid = window.localStorage['branchID'];
    this.userType = window.localStorage['userType'];
    // this.getSummary();
    if(this.userType != 14){
      this.getSummary();
    }else{
      this.getRMBranches();
    }
    // this.reset()
  }
  clicknumberstar(num:any){
    debugger
   this.getnummmm= this.apiService.firstfivexxxx(num)
  }
  reset(){
    this.idle.watch()
  }
 getRMBranches() {
    // $scope.showspi
    ;
    // var userid = window.localStorage['userID'];;
    // var branchid = window.localStorage['branchID'];
    // var userType = window.localStorage['userType'];
    var code ='RM'
    this.loader.presentLoading('')
    this.apiService.getRMBrancheList(this.userid,code)
      .then((response:any)=> {
        this.loader.dismissLoading()
      //  console.log(response);
        // $scope.hidespin();
        response = JSON.parse(JSON.parse(response.data));
        this.datarespRM = response;
        this.datarespRMlength=response.length
      //  console.log($scope.datarespRM)
      },err=>{
        this.loader.dismissLoading()
        this.AlertService.presentAlert("Error",err.status)
      })
      
  }


  async RMCustSummaryclick(item){
    
 const modal = await this.modalController.create({
     component: RMCustViewPage,
     componentProps: { Data: item }
   });
   return await modal.present();
  }

  

 getSummary() {
   debugger
    // this.showspin();
   
    // var userType = window.localStorage['userType'];
    this.loader.presentLoading('')
    this.apiService.getsummaryGrid(this.userid, this.branchid, this.userType).then(response => {
      debugger
      this.loader.dismissLoading()
      var res = JSON.stringify(response.data)
      
      res = JSON.parse(res);
      
      res = JSON.parse(res);
      res = JSON.parse(res);
      
      this.dataresp = res['Table'][0];
      
    })
     
    this.apiService.getwishlistsummaryGrid(this.userid, this.branchid, this.userType).then(response => {
      // this.hidespin();
      debugger
      var resp = JSON.stringify(response.data);
      
      resp = JSON.parse(resp);
      
      resp = JSON.parse(resp);
      resp = JSON.parse(resp);
      
      this.wishdataresp = resp['Table'][0];
    })
  }

  getwishPendingsum () {
    // this.showspin();
  //  console.log("TEST")
  debugger
    this.datarespending='';
    
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    if(this.data.customerid == undefined){
      this.custID = 0 ;
    }else{
      this.custID = this.data.customerid ;
    }
    this.loader.presentLoading('')
    this.apiService.getwishpendingList(userid, branchid, userType)
      .then((response:any)=> {
        debugger
        // this.loader.dismissLoading()
     
        response =JSON.parse( JSON.parse(JSON.parse(JSON.stringify(response.data))));
        console.log(response);
        this.loader.dismissLoading()
        this.wishdatapendingresp = response.Table;
        if(this.wishdatapendingresp.length==0)
        {
this.wishbool=false
        }else{
          this.wishbool=true
          this.datarespendingbool=false
        }
      //  console.log(this.datarespending)
      })
     
  }
 getPendingsum () {
   debugger
    // this.showspin();
  //  console.log("TEST")
    this.datarespending='';
    
    var userid = window.localStorage['userID'];
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    if(this.data.customerid == undefined || this.data.customerid == ''){
      var custID = 0 ;
    }else{
      custID = this.data.customerid ;
    }
    this.loader.presentLoading('')
    this.apiService.getpendingList(userid, branchid, userType,custID).then(response => {
      debugger
      var res = JSON.stringify(response.data)
      res = JSON.parse(res);
      res = JSON.parse(res);
      console.log(response);
      this.loader.dismissLoading()
      // this.hidespin();
      this.datarespending = JSON.parse(res).Table;
    this.datarespendinglength = JSON.parse(res).Table.length
      if(this.datarespending.length==0){
        this.datarespendingbool=false
      }else{
        this.datarespendingbool=true
        this.wishbool=false
      }
    })
  
  }
  gotoAssigned() {
     this.router.navigateByUrl('/diarycalenderd-assigned-customer')
  }
  gotoReport() {
    this.router.navigateByUrl('/diarycalenderd-view-reports');
  }
  gotoOthers() {
    this.router.navigateByUrl('/diarycalenderd-other-customers');
  }
  gotoWishlist() {
    this.router.navigateByUrl('/diarywishlist');
  }
  goToMyplannerPage() {
if(this.userType=='14'){
  this.router.navigateByUrl('/regionsummary')
}else if(this.userType=='17'){

    this.router.navigateByUrl('/newsummary');
  }else{
    this.router.navigateByUrl('/myplanner');
  }
}


gotoBranchSummary(){
  // this.router.navigateByUrl('/checkrmcustview')
  this.router.navigateByUrl('/dairybranchsummary')


}


}
