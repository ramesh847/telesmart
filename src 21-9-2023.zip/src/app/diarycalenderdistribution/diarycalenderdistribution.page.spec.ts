import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DiarycalenderdistributionPage } from './diarycalenderdistribution.page';

describe('DiarycalenderdistributionPage', () => {
  let component: DiarycalenderdistributionPage;
  let fixture: ComponentFixture<DiarycalenderdistributionPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DiarycalenderdistributionPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DiarycalenderdistributionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
