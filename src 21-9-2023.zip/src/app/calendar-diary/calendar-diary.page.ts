import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calendar-diary',
  templateUrl: './calendar-diary.page.html',
  styleUrls: ['./calendar-diary.page.scss'],
})
export class CalendarDiaryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
