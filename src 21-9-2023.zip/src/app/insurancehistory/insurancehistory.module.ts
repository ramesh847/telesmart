import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InsurancehistoryPageRoutingModule } from './insurancehistory-routing.module';

import { InsurancehistoryPage } from './insurancehistory.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InsurancehistoryPageRoutingModule
  ],
  declarations: [InsurancehistoryPage]
})
export class InsurancehistoryPageModule {}
