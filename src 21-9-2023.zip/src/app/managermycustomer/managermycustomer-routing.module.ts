import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ManagermycustomerPage } from './managermycustomer.page';

const routes: Routes = [
  {
    path: '',
    component: ManagermycustomerPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManagermycustomerPageRoutingModule {}
