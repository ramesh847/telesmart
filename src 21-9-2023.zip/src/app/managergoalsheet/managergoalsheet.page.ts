import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';

@Component({
  selector: 'app-managergoalsheet',
  templateUrl: './managergoalsheet.page.html',
  styleUrls: ['./managergoalsheet.page.scss'],
  providers:[Idle]
})
export class ManagergoalsheetPage implements OnInit {
  userid: any;
  branchid: any;
  UserType: any;
  targetbranchdata: any;
  username: any;
  targetuserdata: any;
  targetbranchuserdata: any;
  BranchId: any;
  Deposit: any;
  CASA: any;
  advance: any;
  Existing5: any;
  Existing4: any;
  new5: any;
  Others: any;
  NPA: any;
  Existing6: any;
  New5: any;
  New3: any;
  Existing3: any;
  New2: any;
  Existing2: any;
  New1: any;
  Existing1: any;
  Existing7: any;
  rowindex:any;
  Existing14: any;
  idleState: string;
  constructor(public router:Router,public apiservice:ApiServiceService,
    public alert:AlertServiceService,private modalController:ModalController,
    private loader:ToastServiceService,private idle:Idle) {// sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>{
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); }


  ngOnInit() {
    
    this.userid= window.localStorage['userID']
    this.branchid= window.localStorage['branchID']
   this. UserType=window.localStorage['userType']
    this.getuserlist()
    // this.reset()
  }
reset(){
  this.idle.watch()
}
  modeldissmiss(){
    this.modalController.dismiss()
  }
 getuserlist() {
   
    // this.showspin();
    this.loader.presentLoading('')
    this.apiservice.targetbranchdatas(this.branchid, this.UserType).
    then( (response:any)=> {
        // this.hidespin();
        this.loader.dismissLoading()
       
        response =JSON.parse(JSON.parse(response.data));
        console.log(response);
        this.targetbranchdata = response;
        this.username = window.localStorage['userName'];
    },err=>{
      this.alert.presentAlert("ERROR",err.status)
    })

};
opendetails(index,user_id, user_code, branch_id) {
  
  this.gettargetbranchuser(user_id, user_code, branch_id);
  this.gettargetuser(user_id, user_code, branch_id);
  this.rowindex=index
  // $('.alldatalist').hide(); 

 
}
gettargetuser(user_id, user_code, branch_id) {
  
  // $scope.showspin();
  // this.loader.presentLoading('')
  this.apiservice.targetuserdatas(branch_id, user_code, 10).then( (response:any) =>{
      // $scope.hidespin();
      // this.loader.dismissLoading()
      response = JSON.parse(JSON.parse(response.data));
      console.log(response)
      if (response.length > 0) {
          // $scope.showspin();
      }
      for (var i = 0; i < response.length; i++) {
          response[i].BranchId = parseFloat(response[i].BranchId).toFixed(2);
          response[i].Deposit = parseFloat(response[i].Deposit).toFixed(2);
          response[i].CASA = parseFloat(response[i].CASA).toFixed(2);
          response[i].advance = parseFloat(response[i].advance).toFixed(2);
          response[i].Existing5 = parseFloat(response[i].Existing5).toFixed(2);
          response[i].Existing4 = parseFloat(response[i].Existing4).toFixed(2);
          response[i].new5 = parseFloat(response[i].new5).toFixed(2);
          response[i].Others = parseFloat(response[i].Others).toFixed(2);
          response[i].NPA = parseFloat(response[i].NPA).toFixed(2);

          console.log(response[i]);
          if (i == response.length - 1) {
              // $scope.hidespin();
          }
      }
      
     this. BranchId=response[0].BranchId
      this.Deposit=response[0].Deposit
      this.CASA=response[0].CASA
      this.advance=response[0].advance
     this. Existing5=response[0].Existing5
     this. Existing4=response[0].Existing4
      this.new5=response[0].new5
      this.Others=response[0].Others
     this. NPA=response[0].NPA

      // this.targetuserdata = response;
  },err=>{
    this.alert.presentAlert("Error",err.status)
  })

}
gettargetbranchuser(user_id, user_code, branch_id) {
  // $scope.showspin();
  // this.loader.presentLoading('')
  this.apiservice.targetbranchuserdatas(branch_id, user_code, 10).then( (response:any)=> {
      // $scope.hidespin();
      // this.loader.dismissLoading()
      response = JSON.parse(JSON.parse(response.data));
      console.log(response);
      if (response.length > 0) {
          // $scope.showspin();
      }
      for (var i = 0; i < response.length; i++) {
          response[i].UserId = parseFloat(response[i].UserId).toFixed(2);
          response[i].BranchId = parseFloat(response[i].BranchId).toFixed(2);
          response[i].Existing1 = parseFloat(response[i].Existing1).toFixed(2);
          response[i].New1 = parseFloat(response[i].New1).toFixed(2);
          response[i].Existing2 = parseFloat(response[i].Existing2).toFixed(2);
          response[i].New2 = parseFloat(response[i].New2).toFixed(2);
          response[i].Existing3 = parseFloat(response[i].Existing3).toFixed(2);
          response[i].New3 = parseFloat(response[i].New3).toFixed(2);
          response[i].New5 = parseFloat(response[i].New5).toFixed(2);
          response[i].Existing5 = parseFloat(response[i].Existing5).toFixed(2);
          response[i].Existing6 = parseFloat(response[i].Existing6).toFixed(2);
          response[i].Existing4 = parseFloat(response[i].Existing4).toFixed(2);
          if (i == response.length - 1) {
              // $scope.hidespin();
          }
          console.log(response[i]);
      }



     this. Existing1=response[0].Existing1
     this.New1=response[0].New1
     this. Existing2=response[0].Existing2
     this. New2=response[0].New2
     this. Existing3=response[0].Existing3
     this. New3=response[0].New3
     this. New5=response[0].New5
     this. Existing7=response[0].Existing5
     this. Existing6=response[0].Existing6
     this. Existing14=response[0].Existing4

      // this.targetbranchuserdata = response;
      // console.log(this.targetbranchuserdata);
      this.username = window.localStorage['userName'];
  },err=>{
    this.alert.presentAlert("Error",err.status)
  })

};
goToMyplannerPage(){
  this.router.navigateByUrl('/newsummary')
}
}
