import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ManagergoalsheetPageRoutingModule } from './managergoalsheet-routing.module';

import { ManagergoalsheetPage } from './managergoalsheet.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ManagergoalsheetPageRoutingModule
  ],
  declarations: [ManagergoalsheetPage]
})
export class ManagergoalsheetPageModule {}
