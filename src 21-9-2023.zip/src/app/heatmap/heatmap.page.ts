import { Component, OnInit } from '@angular/core';
import{ ApiServiceService} from './../service/api-service.service';
import {Router } from '@angular/router';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
@Component({
  selector: 'app-heatmap',
  templateUrl: './heatmap.page.html',
  styleUrls: ['./heatmap.page.scss'],
  providers:[Idle]
})
export class HeatmapPage implements OnInit {
  staff : any = [];
  individuals: any = [];
  mangermap: any = [];
  username: any;
  code: any;
  staffmapdata: any =[];
  assignstartdate: any;
  assignstartend: any;
  idleState: string;
  constructor(private router: Router, private apiService : ApiServiceService,private idle:Idle) {// sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(2*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
      {
        let idleState = countdown
        let minutes = Math.floor((idleState)/ 60);
        let extraSeconds = (idleState) % 60;
       let minutes1 = minutes < 10 ? "0" + minutes : minutes;
       let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
       this.idleState=minutes1 +':'+ extraSeconds1
       console.log(this.idleState)
      }
        // (this.idleState = countdown.toString() )
    ); }

  ngOnInit() {

    var userid = window.localStorage['branchID'];
      var branchid = window.localStorage['branchID'];
    this.apiService.getheapmapstaff(userid, branchid).then(response => {
      console.log(response)

      // var user = JSON.stringify(userDetails.data);
      // this.profileData = JSON.parse(user);
      // this.profileData = JSON.parse(this.profileData);
      // this.profileData = JSON.parse(this.profileData);
      var Value = JSON.stringify(response.data)
      Value = JSON.parse(Value);
      Value = JSON.parse(Value);
      Value = JSON.parse(Value);
  
      this.staff =Value;
      console.log("this.staff",this.staff);
            //  this.staff =result;
    })

  
    this.apiService.getheapmapbranchname(userid, branchid).then(response => {
      console.log('laptop',response)
      var Value = JSON.stringify(response.data)
      Value = JSON.parse(Value);
      Value = JSON.parse(Value);
      Value = JSON.parse(Value);
     
      this.individuals =Value;
      console.log("this.individuals",this.individuals);
    
    });


    this.apiService.getheapmap(userid, branchid).then(response => {
      var Value = JSON.stringify(response.data)
      Value = JSON.parse(Value);
      Value = JSON.parse(Value);
      Value = JSON.parse(Value);
   
      this.mangermap =Value;
      console.log("this.mangermap",this.mangermap);
    
    });


    this.apiService.AssigneDdate().then(response => {
      var Value = JSON.stringify(response.data)
      Value = JSON.parse(Value);
      Value = JSON.parse(Value);
      Value = JSON.parse(Value);
      console.log("working",Value);
      this.assignstartdate =Value[0]['EndDate'];
      this.assignstartend=Value[0]['StartDate'];
      // this.mangermap =Value;

    //   response = JSON.parse(response);
    //   console.log(response);
    //  $scope.assignstartdate =response[0].EndDate;
    //  $scope.assignstartend=response[0].StartDate;
    
    });
  
//  this.reset()
  }

reset(){
  this.idle.watch()
}
 openstaff(obj) {
    /*  debugger;*/
      console.log(obj)
    /*  window.location.href = "#/app/HeatMap";*/
    // var userid =obj.USERID;
    var userid = window.localStorage['branchID'];
    var branchid = window.localStorage['branchID'];
          // this.UpdateModal.show();
          this.username=obj.UserName;
            this.code=obj.UserCode;
        
          console.log(this.code);
          
  
       

              this.apiService.getstaffheatmap(userid, branchid).then(response => {
                var Value = JSON.stringify(response.data)
                Value = JSON.parse(Value);
                Value = JSON.parse(Value);
                Value = JSON.parse(Value);
               
                this.staffmapdata =Value;
                console.log("this.staffmapdata",this.staffmapdata);
              
              });
   
          // $('.userDetails' + index_val).toggle();
     
     
  
      }
      doRefresh(event){
        setTimeout(() => {
          console.log('Async operation has ended');
          event.target.complete();
        }, 2000);
      }
      goToMyplannerPage() {
        if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
          this.router.navigate(['/regionsummary']);
    }else
        if(window.localStorage['userType']=='17')
      { this.router.navigate(['/newsummary']);}else{
        this.router.navigateByUrl('/myplanner');
      }
        // this.router.navigateByUrl('/myplanner');
      }
}
