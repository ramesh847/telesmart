import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService} from 'src/app/service/api-service.service';


@Component({
  selector: 'app-check',
  templateUrl: './check.page.html',
  styleUrls: ['./check.page.scss'],
  providers:[DatePipe,Idle]
})
export class CheckPage implements OnInit {
  data: any = {};
  Cusdata: any;
 
  startDate: any;
  showFollowupDateTime: boolean = false;
  showLocation: boolean = false;
 
  jointvisitChecked: boolean = false;
  showEmployeeDetails: boolean = false;
  CallOutcomeItems: any = [];
  CallTypeItem: any;
  customerid: any;
  assigned :any= {};
  enable = false;
  assigneddata = {};
  // assignedcallscustomerdata = [];
  fullname: any;
  purposeid: any;
  purpose: any;
  assignedcallscustomerdata: any;
  firstWords: any[];
  firstname1: any;
  myvalue: boolean;
  addressname: any;
  calltype: any;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  cusdata1: any;
  businessunit: any;
  callOutCome: any;

  followdate:any;
  getfollowdates: string;
  Collectiondate1: any;
  mobile1: any;
  remarks1: any;
  lastname1: any;
  customername1: any;
  responseid: any;
  cbsid: any;
  BusinessUnit: number;
  remarks: any;
  callid: any;
  callid1: any;
  mobile: any;
  firstname: any;
  lastname: any;
  customername: any;
  collectionmode: string;
  collectiondate: string;
  accountno: any;
  amount: any;
  date: string;
  nextcalldate1: string;
  nextcalldate: string;
  jointvisit: string;
  jointusername:any;
  jointcode: any;
  Endtime: any;
  Totime: any;
  latvalue: any;
  langvalue: any;
  address: any;
  success: any;
  assignedcallsdata: any;
  username: any;
  branchid: any;
  usercode: any;
  CallerId: any;
  userid: any;
  usertype: any;
  Customerid: string;
  CustomerName: string;
  Purpose: string;
  mode: string;
  getusername: any;
  hidecalloutcome:boolean=false
  idleState: string;
  constructor(private router: Router,
   private apiservice:ApiServiceService,
    private alertService:AlertServiceService,
    public modalController: ModalController,
    private formBuilder: FormBuilder, private datepipe: DatePipe,private alert1:AlertController,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = "No longer idle."));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          (this.idleState = countdown.toString() )
      ); }
    ngOnInit() {
      debugger
      this. branchid = window.localStorage['branchID'];
      this. usercode = window.localStorage['userCode'];
      this. username = window.localStorage['userName'];
      this. CallerId = window.localStorage['userID'];
      this. userid = window.localStorage['userID'];
      this. callid = window.localStorage['Callid'];
      this. usertype = window.localStorage['userType']
      this. Customerid = "null";
      this. CustomerName = "null";
      this. Purpose = "null";
      this. mode = "T";
    
      this.getcalloutCome();
     this.getbusinessunit();
    this.Cusdata= this.apiservice.assignedcallconnectarray[0]
      // this.cusdata1=this.apiservice.assignedcallarray
     
      // this.Cusdata=this.cusdata1[0]
      console.log( this.Cusdata);
  
  
  this.assignedcallsUpdmodal(this.Cusdata)
  this.reset()
    
    }
  reset(){
    this.idle.watch()
  }
    assignedcallsUpdmodal(obj) {
      debugger
      this.myvalue = false;
      console.log(obj)
      // this.showspin();
  /*this.lat1 = "";
  this.lng1 = "";
  this.addbaselocno = "";
  $("#mapshowimage").html("");
  $("#showdivs").html("");*/
      // this.UpdateModal.show();
      this.assigned.custname = obj.firstname;
  
      this.purpose = obj.Purpose;
      this.assigned.current = "";
      // if (this.assigned.current == "") {
      this.assigned.collected_date = "";
      this.assigned.collected_accno = "";
      this.assigned.collectamount = "";
      // }
      this.assigned.calloutcome = "";
      // if (this.assigned.calloutcome == "Calls-FollowUp") {
      this.assigned.calloutcome = "";
      this.assigned.followdate = "";
      this.assigned.followtime = "";
      // }
       this.assigned.calltype = 'T';
      this.assigned.JointVisit = "";
      this.assigned.jointusername = "";
      this.assigned.jointcode = "";
      //address 
      this.assigned.addressname="";
      
      // if (this.assigned.JointVisit == "Y") {
      //     this.assigned.jointcode = "";
      // }
      this.assigned.remarks = "";
      var customerid = obj.CBSCustomerID;
      this.customerid = obj.CBSCustomerID;
      this.fullname = obj.CustomerName;
      window.localStorage['Customerid'] = obj.CBSCustomerID;
      window.localStorage['Callid'] = obj.Callid;
      // window.localStorage['nextcalldate']
      // var date=obj.NEXT_CALL_DATE;
      window.localStorage['Purpose'] = obj.purposeVal;
      this.purposeid = obj.purposeVal;
      // var newdate = $filter('date')(new Date(), 'yyyy-MM-dd');
      // window.localStorage['nextcalldate'] = newdate;
      // window.localStorage['amount'] = obj.DNPAAmount;
      // window.localStorage['accountno'] = obj.AccountNumber;
   
  
  //Condition to hide call closed option for NPA followup and VVIP Visits purposes
  if(this.purpose != "NPA followup" && this.purpose != "VVIP Visits"){
    this.hidecalloutcome = false;
  }else{
    this.hidecalloutcome = true;
  }
  
      if (customerid == null) {
  
        this.enable = false;
  
      }
      if (customerid != null) {
        this.enable = true;
        // this.showspin();
        this.apiservice.getcustomerdetails(customerid)
          .then((response:any) =>{
            debugger
            // this.hidespin();
          
           var res =JSON.parse(JSON.parse(JSON.parse(response.data)));
            this.assignedcallscustomerdata = res;
  
            if(this.assignedcallscustomerdata != "" && this.assignedcallscustomerdata != undefined)
            {
            console.log(this.assignedcallscustomerdata);
            this.assigned.customerid = customerid;
            this.assigned.firstname = this.assignedcallscustomerdata[0].Nfirstname;
            this.assigned.lastname = this.assignedcallscustomerdata[0].Nlastname;
            this.assigned.mobile = this.assignedcallscustomerdata[0].Nmobile;
            this.assigned.resphnno = this.assignedcallscustomerdata[0].Nresidencephone;
            this.assigned.email = this.assignedcallscustomerdata[0].Nemail;
  
            console.log(this.assigned);
            console.log(this.assignedcallscustomerdata);
  
            this.firstWords = [];
  
            var firstname = [];
  
            for (let i = 0; i < this.assignedcallscustomerdata.length; i++) {
  
              firstname = this.assignedcallscustomerdata[i].Nfirstname.split(" ");
  
              this.firstWords.push(firstname[0]);
              this.assignedcallscustomerdata[i].firstname = this.firstWords[i];
              console.log(this.assignedcallscustomerdata)
              this.firstname1 = this.assignedcallscustomerdata[0].firstname;
  
            }
            console.log(this.assigned);
          console.log(this.firstname1);
          console.log(this.assignedcallscustomerdata[0].Add1);
          if(this.assignedcallscustomerdata[0].Add1 != undefined || this.assignedcallscustomerdata[0].Add2 != undefined || this.assignedcallscustomerdata[0].Add3 != undefined || this.assignedcallscustomerdata[0].Add4 != undefined || this.assignedcallscustomerdata[0].PIN != undefined){
            var respAdd1= this.assignedcallscustomerdata[0].Add1;
            var add1 = respAdd1.replace("/", "-");
            console.log(add1);
            var respAdd2= this.assignedcallscustomerdata[0].Add2;
            var add2 = respAdd2.replace("/", "-");
            console.log(add2);
          this.assigned.addressname = add1+' '+add2+' '+this.assignedcallscustomerdata[0].Add3+' '+this.assignedcallscustomerdata[0].Add4+' '+this.assignedcallscustomerdata[0].PIN;
          console.log(this.assigned.addressname);
          }
          if(this.assigned.addressname != "" && this.assigned.addressname != undefined)
          { 
            console.log(this.assigned.addressname);
           this.myvalue = true;
           //this.data.selectele='P';
          //  this.setlatlong(this.assigned.addressname);
          }
            }
          })
          
        
      }
      console.log(this.assigned.addressname);
      if(this.assigned.addressname != '' &&this.assigned.addressname != 'undefined' &&this.assigned.addressname != undefined){
        // this.typeshowmap(this.lat1, this.lng1,this.assigned.addressname)
      }
    }
  
  // 31/1/2023
  
  
  
  
  
  
  
  
  
  
  
  
  getbusinessunit() {
    // this.showspin();
    this.apiservice.getbusinessunit()
      .then((response:any) =>{
        // console.log(response);
        response = JSON.parse(response.data);
        this.businessunit =JSON.parse(response);
        // this.hidespin();
  
      },err=>{
        this.alertService.presentAlert("Error",err.status)
      })
   
  }
  
  getcalloutCome() {
     debugger
    this.apiservice.getcalloutcome().then(response => {
      debugger
      var result = response.data;
        result = JSON.parse(result);
        result = JSON.parse(result);
      this.callOutCome = result;
     
    })
  }
  
  verifytime() {
    debugger
    var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
    this.getfollowdates = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
    if (this.getfollowdates <= date) {
      this.alertService.presentAlert("","The Call Back Date should not be same and less than current date")
   return false
    }
   
  }
  checkboxClick(Event){
    debugger
    console.log(Event);
    
    if(Event == true){
      this.assigned.JointVisit = 'N';
    }else{
      this.assigned.JointVisit = "Y";
    }
    // console.log(this.followupvisits.JointVisit)
  }
  
  //end
  
  
    setlatlong(addressname) {
  console.log(addressname)
    }
   
    modelDissmiss() {
      debugger
  //     if(this.cusdata1[1].close=="assigncall" || this.cusdata1[1].close=="endcallassign" ){
  // this.router.navigateByUrl('/myassignedcall')
  //     } else if(this.cusdata1[1].close=="planner"){
  //       this.router.navigateByUrl('/myplanner')
  //     }
  //     else{
  //   this.assigned={}
  this.router.navigateByUrl('/myassignedcall')
      // }
    }
  
    
  
    changeCallType(event) {
      
      if (event.target.value == 'Personal Visit') {
        this.showLocation = true;
        if(this.assigned["addressname"] != 'undefined' && this.assigned["addressname"] != ' '&& this.assigned["addressname"] != ''&& this.assigned["addressname"] != undefined){
          console.log(this.assigned["addressname"])
          window.localStorage['addressName']  = this.assigned["addressname"];
          this.setlatlong(this.assigned["addressname"]);
        }
      } else {
        this.showLocation = false;
        // this.MyassignCallForm.get('jointvisit').setValue(null);
        // this.MyassignCallForm.get('location').setValue(null);
      }
  
      console.log(event.target.value);
    }
    
    jointVisit(event) {
      // console.log(event.target.value);
      debugger
      if (event == false) {
        debugger
        this.jointvisitChecked = true;
        this.assigned["JointVisit"] = "Y";
        this.showEmployeeDetails = true;
      } else {
        debugger
        this.jointvisitChecked = false;
        this.assigned["JointVisit"] = "";
        this.showEmployeeDetails = false;
      }
  
      // console.log(event.target.value);
    }
  
    
   
   
  
    saveassignedcalls(obj) {
      debugger
      console.log(obj);
  
      // this.showspin();
  
      console.log(this.assigned);
      this. mobile1 = this.assigned.mobile;
      this. calltype = this.assigned.calltype;
      this. remarks1 = this.assigned.remarks;
      this. firstname1 = this.assigned.firstname;
      this. lastname1 = this.assigned.lastname;
      this. purpose = window.localStorage['Purpose'];
      this. customername1 = this.assigned.firstname;
      this. responseid = this.assigned.calloutcome;
      this. cbsid = window.localStorage['Customerid'];
      this. BusinessUnit = 0;
      // var mode = "A";
      // console.log(responseid)
      console.log(this.assigned.JointVisit)
      // this.assigned.addressname=  window.localStorage['addressName'];
      console.log(this.assigned.addressname)
      this. callid1 = window.localStorage['Callid'];
      if (this.callid1 == undefined) {
        this. callid = null;
      } else {
        this. callid = this.callid1;
      }
  
      if (this.remarks1 == "") {
  
        this. remarks = null;
      } else {
        this. remarks = this.remarks1;
      }
  
      if (this.mobile1 == "") {
  
        this. mobile = null;
      } else {
        this. mobile = this.mobile1;
      }
  
      if (this.firstname1 == "") {
  
        this. firstname = null;
      } else {
        this. firstname = this.firstname1;
      }
  
      if (this.lastname1 == "" || this.lastname1 == '.') {
  
        this. lastname = null;
      } else {
        this. lastname =this. lastname1;
      }
  
  
      if (this.customername1 == "") {
  
        this. customername = null;
      } else {
        this. customername = this.customername1;
      }
  
      if (this.purpose == "5" && this.assigned.current == "Y") {
        if ((this.assigned.collected_date == null || this.assigned.collected_date == undefined || this.assigned.collected_date == "") || (this.assigned.collected_accno == null || this.assigned.collected_accno == "" || this.assigned.collected_accno == undefined) || (this.assigned.collectamount == null || this.assigned.collectamount == "" || this.assigned.collectamount == undefined)) {
  this.alertService.presentAlert("","Fill All Details Of Amount Collected")
         
          return false;
  
        } else {
          this. collectionmode = "Y";
          this.Collectiondate1 = this.assigned.collected_date;
          this. collectiondate = this.datepipe.transform( this.Collectiondate1,'yyyy-MM-dd')
          // $filter('date')(this.Collectiondate1, 'yyy/y-MM-dd');
          this. accountno = this.assigned.collected_accno;
          this. amount = this.assigned.collectamount;
        }
  
      }
  
      
      if (this.purpose != "5") {
        this. collectionmode = null;
  
      }
  
      if (this.purpose == "5") {
        if (this.assigned.current == "" || this.assigned.current == undefined || this.assigned.current == null || this.assigned.current == "N") {
          this. collectionmode = null;
        }
      }
  
      if (this.collectionmode == null) {
        this. accountno = null;
        this. amount = null;
        this. collectiondate = null;
  
      }
  
  
      if (this.assigned.calloutcome == "" || this.assigned.calloutcome == undefined || this.assigned.calloutcome == null) {
  this.alertService.presentAlert("","Select Call OutCome")
      
        return false;
      }
  
  
  
      if (this.responseid == "2") {
        if ((this.assigned.followdate == null || this.assigned.followdate == undefined || this.assigned.followdate == "") || (this.assigned.followtime == null || this.assigned.followtime == undefined || this.assigned.followtime == "")) {
          this.alertService.presentAlert("","Provide Followup Details")
    
          return false;
  
  
        } 
        else
      {
        this. date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
        this.getfollowdates = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
        if (this.getfollowdates <= this.date) {
          // this.followupvisits.followdate=''
          // this.followupvisits.followtime=''
          this.alertService.presentAlert("","The Call Back Date should not be same and less than current date")
          return false
        
        }else{
  
       this.nextcalldate1 = this.datepipe.transform(this.assigned.followdate,'yyyy-MM-dd')
     
  
  
       
  
       var time = this.assigned.followtime.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.assigned.followtime];
   
     if (time.length > 1) { // If time format correct
       time = time.slice (1);  // Remove full string match value
       this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
       time[0] = +time[0] % 12 || 12; 
       time[1]="."// Adjust hours
     }
     this.modifytime1= time.join ('');
     if(this.getampm=="AM"){
       this.modifytime2= this.modifytime1+' '+"AM"
     }else{
       this.modifytime2= this.modifytime1+' '+"PM"
     }
   
         this. nextcalldate = this.nextcalldate1 + ' ' +  this.modifytime2;
       
   
    }
       
     }
  
      }
  
  
  
      if (this.responseid != "2") {
        this. nextcalldate = " ";
        //          var Endtime = null;
        // var Totime = null;
  
      }
  
      if (this.assigned.calltype == "" || this.assigned.calltype == undefined || this.assigned.calltype == null) {
        this.alertService.presentAlert("","Select Call Type")
       
        return false;
  
      }
  
      if (this.assigned.calltype == "P" && this.assigned.JointVisit == "Y") {
        if (this.assigned.jointcode == null || this.assigned.jointcode == "" || this.assigned.jointcode == undefined) {
          this.alertService.presentAlert("","Enter Joint Usercode")
     
          return false;
        } else {
          this. jointvisit = "Y";
          this. jointcode = this.assigned.jointcode;
  
        }
  
  
      }
  
      if (this.assigned.calltype == "P") {
        if (this.assigned.JointVisit == "" || this.assigned.JointVisit == undefined || this.assigned.JointVisit == null || this.assigned.JointVisit == "N") {
  
          this. jointvisit = null;
        }
      }
  
      if (this.assigned.calltype != "P") {
  
        this. jointvisit = null;
  
      }
  
      if (this.jointvisit == null) {
        this. jointcode = null;
      }
  
      this. Endtime = null;
      this. Totime = null;
  
  if (this.assigned.calltype == "P")
  {
  console.log(this.assigned.addressname)
    if ((this.assigned.addressname == "") || ((this.assigned.addressname == 'undefined') || (this.assigned.addressname == undefined))) 
    {
      console.log(this.addressname)
      this.alertService.presentAlert("","Enter Your Location")
     
      return false;
  
    }
     else
     {
   
  
      this. latvalue =  window.localStorage['latitude'];
      //console.log(latvalue)
      this. langvalue =   window.localStorage['longitude'] ;
      //console.log(latvalue)
      this. address = this.assigned.addressname;
    } 
  
  
  }
  
  else
  {
  this. latvalue = null;
  this. langvalue = null;
  this. address = null;
  }
  console.log(this.branchid, this.cbsid, this.customername, this.mobile, this.CallerId,this. username, this.calltype, this.remarks, this.purpose, this.responseid,this.nextcalldate, this.firstname, this.lastname, this.usercode, this.callid, this.accountno, this.amount, this.collectiondate,this. collectionmode, this.jointvisit, this.jointcode, this.Endtime, this.Totime, this.BusinessUnit)
  if (this.assigned.calltype == "P") {
    // this.showspin();
    this.apiservice.updateassignedcalls(this.branchid, this.cbsid, this.customername, this.mobile, this.CallerId,this. username, this.calltype, this.remarks, this.purpose, this.responseid,this.nextcalldate, this.firstname, this.lastname, this.usercode, this.callid, this.accountno, this.amount, this.collectiondate,this. collectionmode, this.jointvisit, this.jointcode, this.Endtime, this.Totime, this.BusinessUnit)
      .then((response:any)=> {
          // this.hidespin();
          debugger
  
          response = JSON.parse(response.data);
          var success = [];
          success = JSON.parse(response);
          console.log(response)
  
          if (response !== "") {
            console.log(success, this.latvalue, this.langvalue, this.address,this.purpose, this.cbsid)
  
          
            this.apiservice.saveaddress(success, this.latvalue, this.langvalue, this.address,this. purpose,this.cbsid)
              .then((response:any) =>{
                debugger
                // this.hidespin();
                console.log(response.data)
  
                if(JSON.parse(response.data)=='"Yes"')
                {
  // this.alertService.presentAlert("","Saved Successfully")
  this.assignsave()
  // this.modelDissmiss()
                }
                else
                {
           
  
           this.alertService.presentAlert("","Error While Saving")
                }
              })
          }
        
  
      
  
  
  
  
     
          console.log( "start call myassignedcallsdata() inside update");
          // this.myassignedcallsdata();
          // $state.reload();
        })
            
  }
  //save
  else
  {
    // this.showspin();
    this.apiservice.updateassignedcalls(this.branchid,this. cbsid, this.customername,this. mobile, this.CallerId, this.username, this.calltype,this. remarks, this.purpose, this.responseid, this.nextcalldate, this.firstname, this.lastname,this. usercode, this.callid,this. accountno, this.amount, this.collectiondate, this.collectionmode, this.jointvisit, this.jointcode,this. Endtime, this.Totime,this. BusinessUnit)
        .then((response:any)=> {
          // this.hidespin();
  
  
          var res = JSON.parse(response.data);
          this. success = [];
          this.success = res;
  
  
  
  
          if (this.success == 4) {
  this.alertService.presentAlert("","This Customer Is Not Mapped With You")
            
  
           
  
          } else if (this.success == 2) {
  this.alertService.presentAlert("","This Customer Is Not Mapped With You")
          
  
          } else if (this.success == 3) {
  this.alertService.presentAlert("","This Customer Already Mapped To You. No Need To Convert")
          
  
  
          } else if (this.success[0].response == 1) {
  // this.alertService.presentAlert("","Please Visit Follow Up Screen As It Is In FOLLOW UP Status " + this.success[0].Column1)
  this.assignstatus(this.success[0].Column1)
           
  
          } else {
  // this.alertService.presentAlert("","Saved Successfully")
  this.assignsave()
          // this.modelDissmiss()
  
  
          }
  
          // this.myassignedcallsdata();
          // $state.reload();
        })
       
  }
  
    }
  

    async assignsave(){
      const alert:any = await this.alert1.create({
        header: "",
        cssClass:'alertHeader',
        // subHeader: 'Subtitle',
        message: "Saved Successfully",
        buttons: [{ text     : 'Ok',
       
        
        handler: () => {
         this.modelDissmiss()
        }
      },
     ]
      });
      await alert.present()
    }

    async assignstatus(msg){
      const alert:any = await this.alert1.create({
        header: "",
        cssClass:'alertHeader',
        // subHeader: 'Subtitle',
        message: "Please Visit Follow Up Screen As It Is In FOLLOW UP Status "+msg,
        buttons: [{ text     : 'Ok',
       
        
        handler: () => {
         this.modelDissmiss()
        }
      },
     ]
      });
      await alert.present()
    }
    myassignedcallsdata () {
      debugger
      // this.showspin();
      this.apiservice.myassignedcallsdata(this.branchid, this.userid, this.usertype, this.Customerid, this.CustomerName, this.Purpose,this. mode)
        .then((response:any)=> {
          debugger
          // this.$broadcast('scroll.refreshComplete');
          // this.hidespin();
          // console.log(response);
        var res = JSON.parse(response.data);
          this.assignedcallsdata =JSON.parse(res) ;
          console.log(this.assignedcallsdata)
          this.username = window.localStorage['userName'];
          this.firstWords = [];
          var firstname = [];
  
          console.log( this.assignedcallsdata.length);
          if( this.assignedcallsdata.length > 0){
            //this.showspin();
          }else{
            // this.hidespin();
          }
         
          for (let i = 0; i < this.assignedcallsdata.length; i++) {
            firstname = this.assignedcallsdata[i].CustomerName.split(" ");
            this.firstWords.push(firstname[0]);
            this.assignedcallsdata[i].firstname = this.firstWords[i];
  
  if(i== this.assignedcallsdata.length - 1){
    // this.hidespin();
  }
  
          }
          
        })
       
    }
  
    getamount(customer_id, date, acc_num) {
      debugger
      var formatted_date =this.datepipe.transform(date, 'dd-MM-yyyy')
      //  $filter('date')(date, 'dd-MM-yyyy');
      // this.showspin();
      this.apiservice.getamount(formatted_date, acc_num, customer_id).then((resp:any) =>{
  debugger
        // this.hidespin();
        if (resp.data == '"No collection entry is available.Please check"') {
          this.alertService.presentAlert("","No Collection Entry Is Available.Please Check")
          // var myPopup = $ionicPopup.show({
          //   template: '<center>No Collection Entry Is Available.Please Check</center>',
          //   title: 'Warning',
          //   scope: this,
          //   buttons: [{
          //     text: 'OK',
          //     type: 'button button-clear button-assertive'
          //   }]
          // });
  
  
        } else {
          this. amount = resp.data;
         this. amount = this.amount.replace(/\"/g, "")
          this.data.collectamount = this.amount;
        }
      })
    }
  
    checkusercode(val) {
      debugger
      this. usercode = val;
      this. branchid = window.localStorage['branchID'];
  
      // this.showspin();
      this.apiservice.getusername(this.usercode,this. branchid)
        .then((response:any)=> {
          // this.hidespin();
          debugger
          console.log(response);
          response = JSON.parse(JSON.parse(response.data));
          if (response == "This User Not in this Branch") {
  this.alertService.presentAlert("","Please Enter The Valid Emp Code")
           
            this.assigned.jointusername = "";
            this.assigned.jointcode = "";
  
          } else {
            this.getusername = response;
            this.assigned.jointusername = this.getusername;
            console.log(this.getusername)
          }
  
        })
        
    }

}
