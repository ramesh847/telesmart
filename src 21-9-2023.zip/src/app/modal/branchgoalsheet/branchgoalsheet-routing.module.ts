import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BranchgoalsheetPage } from './branchgoalsheet.page';

const routes: Routes = [
  {
    path: '',
    component: BranchgoalsheetPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BranchgoalsheetPageRoutingModule {}
