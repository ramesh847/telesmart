import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BranchgoalsheetPageRoutingModule } from './branchgoalsheet-routing.module';

import { BranchgoalsheetPage } from './branchgoalsheet.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BranchgoalsheetPageRoutingModule
  ],
  declarations: [BranchgoalsheetPage]
})
export class BranchgoalsheetPageModule {}
