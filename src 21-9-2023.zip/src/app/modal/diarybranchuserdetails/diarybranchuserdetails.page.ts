import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { NavParams } from 'node_modules/@ionic/angular';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';

@Component({
  selector: 'app-diarybranchuserdetails',
  templateUrl: './diarybranchuserdetails.page.html',
  styleUrls: ['./diarybranchuserdetails.page.scss'],
  providers:[DatePipe,Idle]
})
export class DiarybranchuserdetailsPage implements OnInit {
  data: any;
  date: any;
  data1:any;
  fromdate: string;
  todate: string;
  getstaffmanagerdetails: any;
  getstaffmanagerdetailslength: any;
  cusdata: any;
  idleState: string;

  constructor(private loader:ToastServiceService,private datepipe:DatePipe,
    private modalController:ModalController,private Apiservice:ApiServiceService,private navParams:NavParams,
    private router:Router,public alertservice:AlertServiceService,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = "No longer idle."));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    debugger
    // this.cusdata=this.Apiservice.dairyuserdetails
    this.cusdata=this.navParams.get('Data')
    this.data1=this.cusdata.Usercode
    this.date=this.navParams.get('date')
    this.getuserdetails(this.data1,this.date.fromdate,this.date.todate)
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  modeldissmiss(){
    debugger
    this.modalController.dismiss()
    // this.router.navigateByUrl('/mydiarybranch')
  }
  getuserdetails(usercode,fromdate,todate) {
debugger
    // this.getstaffmanagerdetails = "";
    
    var userid = usercode;
    var branchid = window.localStorage['branchID'];
    this. fromdate = this.datepipe.transform(fromdate,'dd.MM.yyyy')
    // $filter("date")(this.diary.fromdate, 'dd.MM.yyyy');
    this. todate = this.datepipe.transform(todate,'dd.MM.yyyy')
    // $filter("date")(this.diary.todate, 'dd.MM.yyyy');

    // this.showspin();
    this.Apiservice.getstaffdiarydetails(userid, branchid, this.fromdate, this.todate)
        .then( (response:any)=> {
          debugger
            // this.hidespin();
            response = JSON.parse(JSON.parse(response.data));
            console.log(response)
            this.getstaffmanagerdetails = response;
            this.getstaffmanagerdetailslength=response.length


        })
       
    // this.UpdateModal.show();

}
}
