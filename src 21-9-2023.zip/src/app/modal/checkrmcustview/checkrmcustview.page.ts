import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';
import { BranchsummarypendingPage } from '../branchsummarypending/branchsummarypending.page';
import { SummarywishlistPage } from '../summarywishlist/summarywishlist.page';

@Component({
  selector: 'app-checkrmcustview',
  templateUrl: './checkrmcustview.page.html',
  styleUrls: ['./checkrmcustview.page.scss'],
  providers:[NavParams,DatePipe,Idle]
})
export class CheckrmcustviewPage implements OnInit {
  Cusdata: any;
  userid: any;
  userType: any;
  branchid: any;
data:any={}
  custID: number;
  RMdataresp: any;
  viewUserid: any;
  viewbranchid: any;
  viewuserType: any;
  datarespview: any;
  PendingUserid: any;
  Pendingbranchid: any;
  PendinguserType: any;
  Pendingdataresp: any;
  wishdatapendingresp: any;
  RMdataresplength: any;
  branchreportview:boolean=false
  rmddistibution:boolean=true
  datarespviewlength: any;
  cusdata: any;
  datarespendingsummary: any;
  dataresTable1: any;
  dataresTable2: any;
  dataresp: any;
  dataresplength: any;
  custMobile: any;
  customerType: any;
  // Cusdata: any;
  // viewUserid: any;
  // viewbranchid: any;
  // viewuserType: any;
  // data: any={};
  // custID: number;
  // datarespview: any;
  // datarespviewlength: any;
  relativeList: any;
  vreportbranch:boolean=false
  idleState: string;
  constructor( private apiService:ApiServiceService,
    private navParams: NavParams,
    private alertService: AlertServiceService,private datepipe: DatePipe,
    public modalController: ModalController,private loader:ToastServiceService,
    public router:Router,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>{
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    debugger
    this.rmddistibution=true
    this.vreportbranch=false
    this.branchreportview=false
    this. userid = window.localStorage['userID'];
   
    this. userType = window.localStorage['userType'];;
    // this.Cusdata = this.navParams.get('Data');
    this.getBranchSummarylist ()
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
branchreportCust1(item){
  this.rmddistibution=false
  this.vreportbranch=false
  this.branchreportview=true
  // this.Cusdata = this.navParams.get('Data');
  this.reportCust(item)
}
reportCust (item){
  debugger
   //  console.log(item);
     // this.showspin();
     this.viewUserid = item.CallerId;
     this.viewbranchid = item.BranchId;
     this.viewuserType = item.UserType;
     if(this.data.customerid == undefined){
     this. custID = 0 ;
     }else{
     this. custID = this.data.customerid ;
     }
     this.loader.presentLoading('')
     this.apiService.getviewreportGrid(this.viewUserid, this.viewbranchid, this.viewuserType, this.custID)
     .then((response:any) =>{
       debugger
       this.loader.dismissLoading()
       //  console.log(response);
         // this.hidespin();
         response = JSON.parse(JSON.parse(response.data));
         this.datarespview = response.Table;
         this.datarespviewlength=this.datarespview.length
       //  console.log(this.datarespview)
         // this.viewReportaction.show();
     },err=>{
       this.loader.dismissLoading()
       this.alertService.presentAlert("Error",err.status)
     })
    
      
 }
getViewReport() {
debugger
   var userid = this.viewUserid;
   var branchid = this.viewbranchid;
   var userType =  this.viewuserType;
   if(this.data.customerid == undefined){
   this. custID = 0 ;
   }else{
   this. custID = this.data.customerid ;
   }
   this.apiService.getviewreportGrid(userid, branchid, userType, this.custID)
   .then((response:any)=> {
     //  console.log(response);
     debugger
       // this.hidespin();
       response =JSON.parse(JSON.parse(response.data));
       this.datarespview = response.Table;
     //  console.log(this.datarespview)
   },err=>{
     this.alertService.presentAlert("Error",err.status)
   })
  
}
 
branchreportCustSummary1 (item){
    debugger
    this.rmddistibution=false
    this.vreportbranch=true
    this.branchreportview=false
this.reportCustSummary(item)
  }
  reportCustSummary(item){
    debugger
    //console.log(item)
    //  this.showspin();
     var userid = item.CallerId;
     var branchid = item.BranchId;
     var userType = window.localStorage['userType'];
       var custID = item.CBSCustomerId;
      //  this.loader.presentLoading('')
     this.apiService.getproductAvail(userid, branchid, userType, custID)
       .then((response:any) =>{
         debugger
        //  this.loader.dismissLoading()
       //  console.log(response);
        //  this.viewReportSummaryaction.show();
        //  this.hidespin();
         response = JSON.parse(JSON.parse(response.data));
         this.datarespendingsummary = response.Table;
         this.dataresTable1 = response.Table1[0];
         this.dataresTable2 = response.Table2[0];
       //  console.log(this.dataresTable2.Task_Submit)
         this.custID = this.datarespendingsummary[0].CBSCustomerId;
         this.custMobile = this.datarespendingsummary[0].Mobile;
         this.customerType = response.Table1[0].CustomerType;
         this.data.diarygiven = response.Table2[0].NoofDairiesGiven;
         this.data.calendargiven = response.Table2[0].NoofCalendarsGiven;
         this.getRelative();
         // console.log(this.data.diarygiven);
         // console.log(this.data.diarygiven);
         debugger
         if(this.dataresTable2.Task_Submit != null){
           this.data.mobileNo= this.dataresTable2.Mobile_TC;
         //  console.log(this.data.mobileNo)
           this.data.emailId=this.dataresTable2.Email_TC;;
           this.data.panNo=this.dataresTable2.Pan_TC;;
           this.data.netBanking=this.dataresTable2.NetBanking_TC;;
           this.data.mobileBanking=this.dataresTable2.MobileBanking_TC;;
           this.data.debit=this.dataresTable2.ATMCard_TC;;
           this.data.aadhar=this.dataresTable2.AAdhaarLinked_TC;;
           //this.data.gas=this.dataresTable2.Mobile_TC;;
           this.data.creditCard=this.dataresTable2.SbiCreditCard_TC;;
           this.data.mutual=this.dataresTable2.MutualFund_TC;;
           this.data.insur=this.dataresTable2.InsurancePolicyWithus_TC;;
           this.data.health=this.dataresTable2.HealthInsurance_TC;;
           this.data.group=this.dataresTable2.GroupInsurance_TC;;
           this.data.pos=this.dataresTable2.POS_TC;;
           this.data.bharat=this.dataresTable2.BharatQr_TC;;
           this.data.fastag=this.dataresTable2.Fastag_TC;;
           this.data.gold=this.dataresTable2.SGBIntersted_TC;;
           this.data.demat=this.dataresTable2.Demat_TC;;
           this.data.asba=this.dataresTable2.OnlineAsba_TC;;
           this.data.fd=this.dataresTable2.FDLoanWithoutSb_TC;;
           this.data.locker=this.dataresTable2.Locker_TC;;
         }else{
           //  console.log("checking")
           this.data.mobileNo="N";
           this.data.emailId="N";
           this.data.panNo="N";
           this.data.netBanking="N";
           this.data.mobileBanking="N";
           this.data.debit="N";
           this.data.aadhar="N";
           this.data.gas="N";
           this.data.creditCard="N";
           this.data.mutual="N";
           this.data.insur="N";
           this.data.health="N";
           this.data.group="N";
           this.data.pos="N";
           this.data.bharat="N";
           this.data.fastag="N";
           this.data.gold="N";
           this.data.demat="N";
           this.data.asba="N";
           this.data.fd="N";
           this.data.locker="N";
         }
   
        // console.log(this.custID)
       },err=>{
         this.loader.dismissLoading()
         this.alertService.presentAlert("Error",err.status)
       })
      
   }
   getRelative(){
     debugger
    // this.relativeList={};
    // this.showspin();
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
  
    this.apiService.getleadcust(this.custID, this.customerType)
    .then((response:any)=> {
      debugger
      //console.log(response)
      // this.loader.dismissLoading()
      response = JSON.parse(JSON.parse(response.data));
      this.relativeList = response.Table;
      // this.hidespin();
      //this.relativeList.push(response);
    },err=>{
      this.alertService.presentAlert("Error",err.status)
    })
   
  }
  goToMyplannerPage(){
    this.router.navigateByUrl('/diarycalenderdistribution')
  }
  goToMyplannerPag1(){
   
    this.branchreportview=false
    this.rmddistibution=true
  this.vreportbranch=false

  }
  goToMyplannerPag2(){
    debugger
    this.branchreportview=false
    this.rmddistibution=true
  this.vreportbranch=false
  // this.getBranchSummarylist()
    // this.vreportbranch=false
  }
  calendarprocessSave(){
    debugger
      console.log(this.data.mobileNo)
      console.log(this.data.group)
      var userid = window.localStorage['userID'];
      var custID = this.custID;
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.mobileNo == undefined || this.data.mobileNo == '' || this.data.mobileNo == null){
          var RdoMob = 'N'
        }else{
          RdoMob = this.data.mobileNo;
        }
      }else{
        RdoMob = this.data.mobileNo
      }
      
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.emailId == undefined || this.data.emailId == '' || this.data.emailId == null){
          var RdoEmail = 'N'
        }else{
          RdoEmail = this.data.emailId;
        }
      }else{
        RdoEmail = this.data.emailId;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.panNo == undefined || this.data.panNo == '' || this.data.panNo == null){
          var RdoPan = 'N'
        }else{
          RdoPan = this.data.panNo;
        }
      }else{
        RdoPan = this.data.panNo;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.netBanking == undefined || this.data.netBanking == '' || this.data.netBanking == null){
          var RdoNetBank = 'N'
        }else{
          RdoNetBank = this.data.netBanking;
        }
      }else{
        RdoNetBank = this.data.netBanking;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.mobileBanking == undefined || this.data.mobileBanking == '' || this.data.mobileBanking == null){
          var RdoMobBank = 'N'
        }else{
          RdoMobBank = this.data.mobileBanking;
        }
      }else{
        RdoMobBank = this.data.mobileBanking;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.debit == undefined || this.data.debit == '' || this.data.debit == null){
          var RdoDebit = 'N'
        }else{
          RdoDebit = this.data.debit;
        }
      }else{
        RdoDebit = this.data.debit;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.aadhar == undefined || this.data.aadhar == '' || this.data.aadhar == null){
          var RdoAadhar = 'N'
        }else{
          RdoAadhar = this.data.aadhar;
        }
      }else{
        RdoAadhar = this.data.aadhar;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.creditCard == undefined || this.data.creditCard == '' || this.data.creditCard == null){
          var RdoCreditcard = 'N'
        }else{
          RdoCreditcard = this.data.creditCard;
        }
      }else{
        RdoCreditcard = this.data.creditCard;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.mutual == undefined || this.data.mutual == '' || this.data.mutual == null){
          var RdoMutual = 'N'
        }else{
          RdoMutual = this.data.mutual;
        }
      }else{
        RdoMutual = this.data.mutual;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.insur == undefined || this.data.insur == '' || this.data.insur == null){
          var RdoInsPolicy = 'N'
        }else{
          RdoInsPolicy = this.data.insur;
        }
      }else{
        RdoInsPolicy = this.data.insur;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.health == undefined || this.data.health == '' || this.data.health == null){
          var RdoHealthIns = 'N'
        }else{
          RdoHealthIns = this.data.health;
        }
      }else{
        RdoHealthIns = this.data.health;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.group == undefined || this.data.group == '' || this.data.group == null){
          var RdoGrpIns = 'N'
        }else{
          RdoGrpIns = this.data.group;
        }
      }else{
        RdoGrpIns = this.data.group;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.pos == undefined || this.data.pos == '' || this.data.pos == null){
          var RdoPOS = 'N'
        }else{
          RdoPOS = this.data.pos;
        }
      }else{
        RdoPOS = this.data.pos;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.bharat == undefined || this.data.bharat == '' || this.data.bharat == null){
          var RdoBharat = 'N'
        }else{
          RdoBharat = this.data.bharat;
        }
      }else{
        RdoBharat = this.data.bharat;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.fastag == undefined || this.data.fastag == '' || this.data.fastag == null){
          var RdoFastag = 'N'
        }else{
          RdoFastag = this.data.fastag;
        }
      }else{
        RdoFastag = this.data.fastag;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.gold == undefined || this.data.gold == '' || this.data.gold == null){
          var RdoGold = 'N'
        }else{
          RdoGold = this.data.gold;
        }
      }else{
        RdoGold = this.data.gold;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.demat == undefined || this.data.demat == '' || this.data.demat == null){
          var RdoDemat = 'N'
        }else{
          RdoDemat = this.data.demat;
        }
      }else{
        RdoDemat = this.data.demat;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.asba == undefined || this.data.asba == '' || this.data.asba == null){
          var RdoAsba = 'N'
        }else{
          RdoAsba = this.data.asba;
        }
      }else{
        RdoAsba = this.data.asba;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.fd == undefined || this.data.fd == '' || this.data.fd == null){
          var RdoFDSB = 'N'
        }else{
          RdoFDSB = this.data.fd;
        }
      }else{
        RdoFDSB = this.data.fd;
      }
  
      if(this.dataresTable2.Task_Submit == null){
        if(this.data.locker == undefined || this.data.locker == '' || this.data.locker == null){
          var RdoLocker = 'N'
        }else{
          RdoLocker = this.data.locker;
        }
      }else{
        RdoLocker = this.data.locker;
      }
      console.log(RdoMob);
      this.apiService.diarySaveProcess(custID, userid, RdoMob, RdoEmail, RdoPan, RdoNetBank, RdoMobBank, RdoDebit, RdoAadhar, RdoCreditcard, RdoMutual, RdoInsPolicy, RdoHealthIns, RdoGrpIns, RdoPOS,RdoBharat, RdoFastag, RdoGold, RdoDemat, RdoAsba, RdoFDSB, RdoLocker)
      .then((response:any) =>{
        // console.log(response);
        debugger
        // this.hidespin();
        //response = JSON.parse(response);
       this.alertService.presentAlert("","save Successfully")
    this.goToMyplannerPag2()
    // this.router.navigateByUrl('/dairybranchsummary')
    //  this.router.navigateByUrl('/dairybranchsummary')
        // this.getBranchSummarylist();
      })
     
    }
    getBranchSummarylist() {
      // this.showspin();
      debugger
      var userid = window.localStorage['userID'];
      var branchid = window.localStorage['branchID'];
      var userType = window.localStorage['userType'];
      if(this.data.customerid == undefined){
        var custID = 0 ;
      }else{
        custID = this.data.customerid ;
      }
      this.loader.presentLoading('')
      this.apiService.getBranchsummaryGrid(userid, branchid, userType,custID)
        .then((response:any)=> {
          this.loader.dismissLoading()
          // this.hidespin();
          console.log(response);
          response =JSON.parse(JSON.parse(response.data));
          this.dataresp = response.Table;
          console.log(this.dataresp)
  
        })
       
    }
    async branchpendingList1(item){
      const modal = await this.modalController.create({
        component:BranchsummarypendingPage,
        componentProps: { Data: item }
      });
      return await modal.present();
    }
    async branchwishpendingList1(item){
      const modal = await this.modalController.create({
        component:SummarywishlistPage,
        componentProps: { Data: item }
      });
      return await modal.present();
    }
}
