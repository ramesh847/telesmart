import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CheckrmcustviewPageRoutingModule } from './checkrmcustview-routing.module';

import { CheckrmcustviewPage } from './checkrmcustview.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CheckrmcustviewPageRoutingModule
  ],
  declarations: [CheckrmcustviewPage]
})
export class CheckrmcustviewPageModule {}
