import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';
import { AlertServiceService } from '../../service/alert-service.service'
@Component({
  selector: 'app-commoncallmodal',
  templateUrl: './commoncallmodal.page.html',
  styleUrls: ['./commoncallmodal.page.scss'],
})
export class CommoncallmodalPage implements OnInit {
  savebool:boolean
  assignedcallscustomerdata: any;
  dateToday: any;
  assigned: any = {};
  enable: boolean;
  assigneddata: any = {};
  customerid: any;
  Collectiondate1: any;
  commoncallsdata: any;
  loaddata: boolean;
  Purpose: any;
  hidecalloutcome: any;
  purposeid: any;
  callOutCome: any;
  getusername: any;
  callPurpose: any;
  businessunit: any;
  commoncallsdataonload: any;
  firstWords: any;
  firstname1: any;
  myvalue: any;
  purpose: any;
  nextcalldate1: any;
  followuptime: any;
  lat1: any;
  lng1: any;
  datatofilter: any;
  getfollowdates: string;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  constructor(private datepipe: DatePipe, private apiservice: ApiServiceService,
    private loader:ToastServiceService,private AlertService:AlertServiceService) { }

  ngOnInit() {
    this.dateToday = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
    console.log(this.dateToday);
    // var hostLink = httpLinkManager.getnewLocalLink();
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    var calltype = "T";
    var custid = " ";
    var name = null;

    this.assigned = {};
    this.enable = false;
    this.assigneddata = {};
    this.assignedcallscustomerdata = [];

    this.assigned = {};
    var usercode = window.localStorage['userCode'];
    var username = window.localStorage['userName'];
    var branchid = window.localStorage['branchID'];
    var CallerId = window.localStorage['userID'];
  }
  verifytime() {
    debugger
    var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
    this.getfollowdates = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
    if (this.getfollowdates <= date) {
      this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
   return false
    }
   
  }
  checkusercode(val) {
    var usercode = val;
    var branchid = window.localStorage['branchID'];

    this.apiservice.getusername(usercode, branchid)
      .then(response => {
        console.log(response);
        var responses = JSON.stringify(response.data);
        if (responses == "This User Not in this Branch") {

          // var myPopup = $ionicPopup.show({
          //   template: '<center>Please Enter The Valid Emp Code</center>',
          //   title: 'Warning',
          //   scope: this,
          //   buttons: [{
          //     text: 'OK',
          //     type: 'button button-clear button-assertive'
          //   }]
          // });
          this.assigned.jointusername = "";
          this.assigned.jointcode = "";

        } else {
          this.getusername = response;
          this.assigned.jointusername = this.getusername;
          console.log(this.getusername)
        }

      })
    // .error(function(response) {
    //   console.log(response);
    // });
  }

  getamount(customer_id, date, acc_num) {
    var formatted_date = this.datepipe.transform(date, 'dd-MM-yyyy');
    this.apiservice.getamount(formatted_date, acc_num, customer_id).then(function (resp) {
      if (resp.data == '"No collection entry is available.Please check"') {
        // var myPopup = $ionicPopup.show({
        //   template: '<center>No Collection Entry Is Available.Please Check</center>',
        //   title: 'Warning',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });


      } else {
        var amount = resp.data;
        amount = amount.replace(/\"/g, "")
        this.data.collectamount = amount;
      }
    })
  }

  getpurpose() {
    var count = 0;
    // this.showspin();

    this.apiservice.getpurposenew()
      .then(response => {
        console.log(response);
        response = JSON.parse(response.data);
        this.callPurpose = response;

        // this.hidespin();

      })
      // .error(response => {
      //   console.log(response);
      //   count++;
      //   if (count <= 2) {
      //     this.getpurpose();
      //   } else {
      //     // this.hidespin();
      //     // this.showToast('Server Error, Purpose is not loaded.' )
      //   }
      // });
  }

  getcalloutcome() {
    // this.showspin();
    this.apiservice.getcalloutcome1()
      .then(response => {
        console.log(response);
        this.purposeid = response['PurposeId'];
        response = JSON.parse(response.data);
        this.callOutCome = response;
        // this.hidespin()


      })
      // .error(function (response) {
      //   console.log(response);
      //   count++;
      //   if (count <= 2) {
      //     this.getcalloutcome();
      //   } else {
      //     // this.hidespin();
      //     this.showToast('Server Error, Call Outcome is not loaded.')
      //   }

      // });
  }

  getbusinessunit() {
    // this.showspin();

    this.apiservice.getbusinessunit()
      .then(response => {
        console.log(response);
        response = JSON.parse(response.data);
        this.businessunit = response;
        // this.hidespin();


      })
      // .error(function (response) {
      //   console.log(response);
      //   count++;
      //   if (count <= 2) {
      //     this.getbusinessunit();
      //   } else {
      //     // this.hidespin();
      //     this.showToast('Server Error, Business Unit is not loaded.')
      //   }

      // });


  }

  getCommoncallsonload() {
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    var calltype = "T";
    var custid = window.localStorage['Customerid'];
    // this.showspin();
    this.commoncallsdata = [];
    this.loaddata = true;
   var  fromdate = this.datepipe.transform(new Date(), 'dd-MM-yyyy');
   var  todate = this.datepipe.transform(new Date(), 'dd-MM-yyyy');
    console.log(fromdate, todate);
    //this.apiservice.getcomcalls(userid, branchid, calltype, custid, name)
    this.apiservice.getcomcalls(1, branchid, calltype, custid)
      .then(response => {

        // console.log(response);
        response = JSON.parse(response.data);
        this.commoncallsdataonload = response;
        console.log(this.commoncallsdataonload)
        var firstname = [];
        this.firstWords = [];

        for (var i = 0; i < this.commoncallsdataonload.length; i++) {
          firstname = this.commoncallsdataonload[i].CustomerName.split(" ");
          this.firstWords.push(firstname[0]);
          this.commoncallsdataonload[i].firstname = this.firstWords[i];
           var date = this.commoncallsdataonload[i].ToCallDate.split('/');
          var date_a = date[1] + '/' + date[0] + '/' + date[2];
          this.commoncallsdataonload[i].tofiltercalldate = date_a;
        }
        this.datatofilter = this.commoncallsdataonload;
        //   this.commoncallsdataonload.sort(function(a, b) {
        //     date1 = a.ToCallDate.split('/');
        //     date_a = date1[1]+'/'+date1[0]+'/'+date1[2];
        //     date2 = b.ToCallDate.split('/');
        //     date_b = date2[1]+'/'+date2[0]+'/'+date2[2];
        //     // console.log(date_a,date_b);
        //     var c = new Date(date_a);
        //     var d = new Date(date_b);

        //     return d-c;
        // })
        console.log(this.commoncallsdataonload)
        // $ionicLoading.hide();
      })
    // .error(function(response) {
    //   console.log(response);
    //   // $ionicLoading.hide();
    // });

  }

  commoncallsUpdmodal(obj) {
    console.log(obj)
    this.assigned.custname = obj.firstname;
    this.assigned.fullname = obj.CustomerName;
    this.Purpose = obj.Purpose;
    console.log(this.Purpose)

    //Condition to hide call closed option for NPA followup and VVIP Visits purposes
    if (this.purpose != "NPA followup" && this.purpose != "VVIP Visits") {
      this.hidecalloutcome = false;
    } else {
      this.hidecalloutcome = true;
    }



    //address
    this.assigned.addressname = "";
    //  $("#showdivscalls").css("display", "none");

    this.assigned.current = "";
    this.assigned.collected_date = "";
    this.assigned.collected_accno = "";
    this.assigned.collectamount = "";
    this.assigned.calloutcome = "";
    this.assigned.followdate = "";
    this.assigned.followtime = "";
    this.assigned.calltype = 'T';
    this.assigned.JointVisit = "";
    this.assigned.jointusername = "";
    this.assigned.jointcode = "";
    this.assigned.remarks = "";
    var customerid = obj.CBSCustomerID;
    this.customerid = obj.CBSCustomerID;
    window.localStorage['Customerid'] = obj.CBSCustomerID;
    window.localStorage['Callid'] = obj.CallID;

    window.localStorage['PurposeId'] = obj.PurposeId;
    this.purposeid = obj.PurposeId;



    // this.UpdateModal.show();
    if (customerid == null) {

      this.enable = false;

    }
    if (customerid != null) {
      this.enable = true;
      this.apiservice.getcustomerdetails(customerid)
        .then(response => {
          var responses = JSON.parse(response.data);
          responses = JSON.parse(responses);
          this.assignedcallscustomerdata = responses;
          if (this.assignedcallscustomerdata != "" && this.assignedcallscustomerdata != undefined) {
            this.assigned.customerid = customerid;
            this.assigned.firstname = this.assignedcallscustomerdata[0].Nfirstname;
            this.assigned.lastname = this.assignedcallscustomerdata[0].Nlastname;
            this.assigned.mobile = this.assignedcallscustomerdata[0].Nmobile;
            this.assigned.resphnno = this.assignedcallscustomerdata[0].Nresidencephone;
            this.assigned.email = this.assignedcallscustomerdata[0].Nemail;
            this.assigned.Purpose = this.assignedcallscustomerdata[0].Purpose;
            console.log(this.assigned);

            this.firstWords = [];

            var firstname = [];

            for (var i = 0; i < this.assignedcallscustomerdata.length; i++) {

              firstname = this.assignedcallscustomerdata[i].Nfirstname.split(" ");

              this.firstWords.push(firstname[0]);
              this.assignedcallscustomerdata[i].firstname = this.firstWords[i];
              this.firstname1 = this.assignedcallscustomerdata[i].firstname;

            }

            console.log(this.assignedcallscustomerdata[0].Add1);
            if (this.assignedcallscustomerdata[0].Add1 != undefined || this.assignedcallscustomerdata[0].Add2 != undefined || this.assignedcallscustomerdata[0].Add3 != undefined || this.assignedcallscustomerdata[0].Add4 != undefined || this.assignedcallscustomerdata[0].PIN != undefined) {
              var respAdd1 = this.assignedcallscustomerdata[0].Add1;
              var add1 = respAdd1.replace("/", "-");
              console.log(add1);
              var respAdd2 = this.assignedcallscustomerdata[0].Add2;
              var add2 = respAdd2.replace("/", "-");
              console.log(add1);

              this.assigned.addressname = add1 + ' ' + add2 + ' ' + this.assignedcallscustomerdata[0].Add3 + ' ' + this.assignedcallscustomerdata[0].Add4 + ' ' + this.assignedcallscustomerdata[0].PIN;
              console.log(this.assigned.addressname);
            }
            if (this.assigned.addressname != "" && this.assigned.addressname != undefined) {
              console.log(this.assigned.addressname);
              this.myvalue = true;
              //this.data.selectele='P';
              // this.setlatlong(this.assigned.addressname);
            }

          }

        })
        // .error(function (response) {
        //   console.log(response);
        // });
    }
    // console.log(obj);
    console.log(this.assigned.addressname);
    if (this.assigned.addressname != '' && this.assigned.addressname != 'undefined' && this.assigned.addressname != undefined) {
      //  this.typeshowmap(this.lat1, this.lng1,this.assigned.addressname)
    }
  }

  savecommoncalls(obj) {
    console.log(obj);
    //console.log(this.followup.deposits);
    // this.showspin($ionicLoading);
    var cbsid = window.localStorage['Customerid'];
    console.log(cbsid)

    var mobile1 = this.assigned.mobile;
    var calltype = this.assigned.calltype;
    var remarks1 = this.assigned.remarks;
    var firstname1 = this.assigned.firstname;
    var lastname1 = this.assigned.lastname;
    var purpose = window.localStorage['PurposeId'];
    var customername1 = this.assigned.firstname;
    var responseid = this.assigned.calloutcome;
    var callid = window.localStorage['Callid'];
    var BusinessUnit = 0;
    var usercode = window.localStorage['userCode'];
    var username = window.localStorage['userName'];
    var branchid = window.localStorage['branchID'];
    var CallerId = window.localStorage['userID'];
    console.log(responseid)


    if (mobile1 == "") {

      var mobile = null;
    } else {
      var mobile = mobile1;
    }

    if (customername1 == "") {

      var customername = null;
    } else {
      var customername = customername1;
    }


    if (firstname1 == "") {

      var firstname = null;
    } else {
      var firstname = firstname1;
    }

    if (lastname1 == "") {

      var lastname = null;
    } else {
      var lastname = lastname1;
    }

    if (remarks1 == "") {

      var remarks = null;
    } else {
      var remarks = remarks1;
    }

    if (purpose == "5" && this.assigned.current == "Y") {
      if ((this.assigned.collected_date == null || this.assigned.collected_date == undefined || this.assigned.collected_date == "") || (this.assigned.collected_accno == "" || this.assigned.collected_accno == undefined || this.assigned.collected_accno == null) || (this.assigned.collectamount == undefined || this.assigned.collectamount == "" || this.assigned.collectamount == null)) {

        // var myPopup = $ionicPopup.show({
        //   template: '<center>Fill All Details Of Amount Collected</center>',
        //   title: 'Warning',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        return false;

      } else {
        var collectionmode = "Y";
        this.Collectiondate1 = this.assigned.collected_date;
        var collectiondate = this.datepipe.transform(this.Collectiondate1, 'yyyy-MM-dd');
        var accountno = this.assigned.collected_accno;
        var amount = this.assigned.collectamount;
      }

    }
    console.log(this.assigned.current)
    console.log(this.assigned.JointVisit)

    if (purpose != "5") {
      collectionmode = null;

    }

    if (purpose == "5") {
      if (this.assigned.current == "" || this.assigned.current == undefined || this.assigned.current == null || this.assigned.current == "N") {
        collectionmode = null;

      }
    }

    if (collectionmode == null) {
      var accountno = null;
      var amount = null;
      collectiondate = null;
    }


    if (this.assigned.calloutcome == "" || this.assigned.calloutcome == undefined || this.assigned.calloutcome == null) {

      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Call OutCome</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;
    }



    if (responseid == "2") {
      if ((this.assigned.followdate == null || this.assigned.followdate == "" || this.assigned.followdate == undefined) || (this.assigned.followtime == null || this.assigned.followtime == undefined || this.assigned.followtime == "")) {
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Provide Followup Details</center>',
        //   title: 'Warning',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        // return false;
        this.AlertService.presentAlert("","Provide Followup Details")
    
      return false;



      } 
      else
      {
  
        var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
        this.getfollowdates = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
        if (this.getfollowdates <= date) {
          // this.followupvisits.followdate=''
          // this.followupvisits.followtime=''
          this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
          return false
        
        }else{
  
       this.nextcalldate1 = this.datepipe.transform(this.assigned.followdate,'yyyy-MM-dd')
       //$filter('date')(this.assignedvisit.followdate, 'yyyy-MM-dd');
       // this.followuptime = this.datepipe.transform( this.assignedvisit.followtime, 'h.mm a')
       //$filter('date')(this.assignedvisit.followtime, 'h.mm a');
  
  
       
       //  $filter('date')(this.followupvisits.followdate, 'yyyy-MM-dd');
       var time = this.assigned.followtime.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.assigned.followtime];
   
     if (time.length > 1) { // If time format correct
       time = time.slice (1);  // Remove full string match value
       this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
       time[0] = +time[0] % 12 || 12; 
       time[1]="."// Adjust hours
     }
     this.modifytime1= time.join ('');
     if(this.getampm=="AM"){
       this.modifytime2= this.modifytime1+' '+"AM"
     }else{
       this.modifytime2= this.modifytime1+' '+"PM"
     }
   
         var nextcalldate = this.nextcalldate1 + ' ' +  this.modifytime2;
       
   
    }
       // var nextcalldate = this.nextcalldate1 + ' ' + this.followuptime;
     }

    }

    if (responseid != "2") {
      var nextcalldate = " ";
      //          var Endtime = null;
      // var Totime = null;

    }

    if (this.assigned.calltype == "" || this.assigned.calltype == undefined || this.assigned.calltype == null) {
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Call Type</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;

    }

    if (this.assigned.calltype == "P" && this.assigned.JointVisit == "Y") {
      if (this.assigned.jointcode == null || this.assigned.jointcode == "" || this.assigned.jointcode == undefined) {
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter Joint Usercode</center>',
        //   title: 'Warning',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        return false;
      } else {
        var jointvisit = "Y";
        var jointcode = this.assigned.jointcode;

      }

    }

    if (this.assigned.calltype == "P") {
      if (this.assigned.JointVisit == "" || this.assigned.JointVisit == null || this.assigned.JointVisit == undefined || this.assigned.JointVisit == "N") {

        jointvisit = null;
      }
    }

    if (this.assigned.calltype != "P") {

      jointvisit = null;

    }

    if (jointvisit == null) {
      var jointcode = null;
    }

    console.log(this.Purpose)
    if (this.Purpose == 'Lead Generation') {

      if ((this.assigned.casa != "" && this.assigned.casa != undefined) || (this.assigned.deposits != "" && this.assigned.deposits != undefined) || (this.assigned.advance != "" && this.assigned.advance != undefined) || (this.assigned.insurance != "" && this.assigned.insurance != undefined)) {
        console.log(this.assigned.casa);
        var casaVal = this.assigned.casa;
        console.log(casaVal)
        var depositVal = this.assigned.deposits;
        console.log(depositVal)
        var AdvanceVal = this.assigned.advance;
        console.log(AdvanceVal)
        var InsuranceVal = this.assigned.insurance;
        console.log(InsuranceVal)

      } else {
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Fill Details Of Expected Business</center>',
        //   title: 'Warning',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        return false;
      }

      if (this.assigned.casa == undefined || this.assigned.casa == "") {

        casaVal = 0;
      } else {
        var casaVal = this.assigned.casa;
      }
      if (this.assigned.deposits == undefined || this.assigned.deposits == "") {
        depositVal = 0;
      } else {
        var depositVal = this.assigned.deposits;
      }

      if (this.assigned.advance == undefined || this.assigned.advance == "") {
        AdvanceVal = 0;
      } else {
        AdvanceVal = this.assigned.advance;
      }

      if (this.assigned.insurance == undefined || this.assigned.insurance == "") {
        InsuranceVal = 0;
      } else {
        var InsuranceVal = this.assigned.insurance;
      }

    } else {
       casaVal = 0;
       depositVal = 0;
       AdvanceVal = 0;
       InsuranceVal = 0;
    }

    var Endtime = null;
    var Totime = null;
    console.log(this.assigned.followdate)
    console.log(this.assigned.followtime)
    console.log(this.assigned.JointVisit)

    if (this.assigned.calltype == "P") {

      if ((this.assigned.addressname == "") || ((this.assigned.addressname == 'undefined') || (this.assigned.addressname == undefined))) {
        console.log(this.assigned.addressname)
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter Your Location</center>',
        //   title: 'Warning',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        return false;

      } else {
        //alert(latvalue);
        var latvalue = this.lat1;
        //console.log(latvalue)
        var langvalue = this.lng1;
        //console.log(latvalue)
        var address = this.assigned.addressname;
      }


    } else {
      var latvalue = null;
      var langvalue = null;
      var address = null;
    }
    console.log(purpose);
    if (lastname == '.') lastname = null;
    // console.log(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
    if (this.assigned.calltype == "P") {

      console.log("call type is pv");
      this.loader.presentLoading('')
      this.savebool=true
      this.apiservice.updatecommoncalls(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
        .then(function (response) {
          this.loader.dismissLoading();
          // this.hidespin($ionicLoading);
          console.log(response);
         var responses = JSON.parse(response.data);
          var then = [];
          then = responses;
this.savebool=false
          if (responses !== "") {
            //debugger;
            console.log(then, latvalue, langvalue, address, purpose, cbsid)
            this.apiservice.saveaddress(then, latvalue, langvalue, address, purpose, cbsid)
              .then(function (response) {
                console.log(response)
                if (response == '"Yes"') {

                  // var alertPopup = $ionicPopup.alert({
                  //   title: 'then',
                  //   template: 'Saved thenfully'
                  // });
                  this.searchCommonCalls(localStorage.getItem('CCpurposeselected'), '');
                  // alertPopup.then(function (res) {
                  //   this.UpdateModal.hide();
                  //   // Custom functionality....
                  // });
                }

                else {
                  // var alertPopup = $ionicPopup.alert({
                  //   title: 'Error',
                  //   template: 'Error While Saving'
                  // });

                  // alertPopup.then(function (res) {
                  //   this.UpdateModal.hide();
                  //   // Custom functionality....
                  // });
                }

              })
          }
          /*if (then[0].response == 1) {
  
  
            var alertPopup = $ionicPopup.alert({
              title: 'Warning',
              template: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + then[0].Column1
            });
  
            alertPopup.then(function(res) {
              this.UpdateModal.hide();
              // Custom functionality....
            });
  
          } else */
          /* {
             var alertPopup = $ionicPopup.alert({
               title: 'then',
               template: 'Saved thenfully'
             });
   
             alertPopup.then(function(res) {
               this.UpdateModal.hide();
   
               // Custom functionality....
             });
           }
   */
          // this.getCommoncallsonload();

        })
        // .error(function (response) {
        //   console.log(response);
        //   // this.hidespin($ionicLoading);
        // });
      // this.UpdateModal.hide();
    }
    else {
      console.log("call type is not pv");
      this.savebool=true
      this.apiservice.updatecommoncalls(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
        .then(function (response) {
          // this.hidespin($ionicLoading);
          console.log(response);
          var responses = JSON.parse(response.data);
          var then = [];
          then = responses;

this.savebool=false
          if (then[0].response == 1) {


            // var alertPopup = $ionicPopup.alert({
            //   title: 'Warning',
            //   template: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + then[0].Column1
            // });

            // alertPopup.then(function (res) {
            //   this.UpdateModal.hide();
            //   // Custom functionality....
            // });

          }
          else {
            // var alertPopup = $ionicPopup.alert({
            //   title: 'then',
            //   template: 'Saved thenfully'
            // });
            this.searchCommonCalls(localStorage.getItem('CCpurposeselected'), '');
            // alertPopup.then(function (res) {
            //   this.UpdateModal.hide();

            //   // Custom functionality....
            // });
          }

          // this.getCommoncallsonload();

        })
        // .error(function (response) {
        //   console.log(response);
        //   // this.hidespin($ionicLoading);
        // });
    }

  }

}
