import { Component, OnInit } from '@angular/core';
import { NavParams } from '@ionic/angular';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { AlertController } from '@ionic/angular';
import * as moment from "moment"; 
import { ModalController } from '@ionic/angular';
import { DemandcollectionmodalPage } from '../demandcollectionmodal.page';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-endcallmodal',
  templateUrl: './endcallmodal.page.html',
  styleUrls: ['./endcallmodal.page.scss'],
})
export class EndcallmodalPage implements OnInit {
  endDate: string;
  currDate: string;
  repStatus: any;
  statusResp: any;
  clickcallID: any;
  interval: any;
  res: any;
  resout: any;
  ClickAccess: boolean;
  accessResp: any;
  data:any={};
  customeractiondata: any;
  enable: boolean;
  customerid: any;
  Npacustomerdata: any;
  firstWords: any[];
  firstname1: any;
  purposeID: any;
  purpose: any;
  voicerecording: string;
  location: string;
  provider: string;
  status: string;
  status2: string;
  constructor(private alert:AlertController,private modalController:ModalController,
    private apiservice:ApiServiceService,private navParams:NavParams,
    private Alertservice:AlertServiceService,public route:Router) { }
  ngOnInit() {
    let Cusdata = this.navParams.get('Data');
    console.log(Cusdata);
    this.callNumber(Cusdata);
    this.clickCallAccess();
  }

  clickCallAccess(){
    var userid = window.localStorage['userID'];
    this.apiservice.AccesstoClick(userid)
    .then((res)=> {
      console.log(res)
      var response =  JSON.parse(res.data)
      this.accessResp= JSON.parse(response)
      // this.hidespin($ionicLoading);
      if(this.accessResp == 'A'){
        console.log(this.accessResp);
        this.ClickAccess =true;
      }else{
        this.ClickAccess =false;
      }
     
    })
    
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin($ionicLoading);
    // });
  }



  clickcall:any={};
  item:any = '';
  callNumber(item){
    debugger
    console.log(item);
    this.item = item;
    this.clickcall.callerName=window.localStorage['userName'];
    this.clickcall.callerMobile=window.localStorage['mobile'];
    this.clickcall.customerName=item.CustomerName;
    this.clickcall.customerMobile=item.Mobile;
    this.clickcall.customerId=item.CBSCustomerId;
    this.clickcall.endDate='';
    var purpose = 'Demandcollection';
    var currentDate= new Date();
    // this.clickcall.currDate = $filter('date')(currentDate, 'yyyy-MM-dd hh-mm-ss');
    // console.log(this.currDate);
    this.clickcall.currDate = moment(currentDate).format('YYYY-MM-DD h.mm a');
    // this.followuptime = moment(this.data.followuptime).format('h.mm a');
    this.apiservice.clickToCallCustomer(this.clickcall.callerMobile,this.clickcall.customerMobile,purpose)
    .then((response)=> {
      debugger
      console.log(response)
      // this.hidespin($ionicLoading);
      // debugger
      this.res = JSON.parse(response.data);
      this.resout = JSON.parse(this.res);
      this.resout = JSON.parse(this.resout);
      // console.log(resout)
      // debugger
      if(this.resout.status == "200"){
        // debugger
        this.clickcallID = this.resout.data;
        this.callinterval();

        

        // this.CallConnectModal.show();
      }else{
        this.callNumberpopup(this.resout)
      // var alertPopup = $ionicPopup.alert({
      //   title: 'Alert',
      //   template: response.data
      // });
    
      // alertPopup.then(function(res) {
      // });
      // by sijin
      }


    })
    
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin($ionicLoading);
    // });

  }
 async callNumberpopup(res){
    const alert:any = await this.alert.create({
      header: "Alert",
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: res,
 
    });
  await alert.precent()
  }
  callinterval(){
    // alert()
  this.interval = setInterval(() => {
this.callResp();
    // clearInterval(this.interval)
  }, 10000);
  }
  stopCall(){
    clearInterval(this.interval)
  }

  EndCallobj:any={};
  callResp(){
    debugger
    console.log(this.clickcallID.id);
    var id = this.clickcallID.id;
    this.apiservice.callStatusCustomer(id)
    .then((response:any)=> {
    //  console.log(response)
  debugger
      this.statusResp= JSON.parse(response.data)
      this.repStatus = JSON.parse(this.statusResp);
      this.repStatus = JSON.parse(this.repStatus);
      // debugger
      // this.hidespin($ionicLoading);
      debugger
      console.log(this.repStatus.data.length);
      if(this.repStatus.data.length == 1){
        console.log(this.repStatus.data[0].status2);
      if(this.repStatus.data[0].status2 != null){
        console.log(this.repStatus.data[0]);
        if(this.repStatus.data[0].status2 == 'ANSWER'){
          debugger
          this.stopCall();
          // this.CallConnectModal.hide();
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile=window.localStorage['mobile'];
          this.EndCallobj.customerName=this.item.CustomerName;
          this.EndCallobj.customerMobile=this.item.Mobile;
          this.EndCallobj.customerId=this.item.CBSCustomerId;
          //this.EndCallobj.cust=this.item.custCat;
          this.EndCallobj.endStatus= 'A';
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          this.Endcall(this.EndCallobj);
          // this.customerActionModal(this.item); by sijin
        }else{


         this.callresppopup(this.repStatus.data[0].status2 )

          
        }
        
      }
    }
    })
    
   
  }
async callresppopup(ans){
  debugger
  const alert:any = await this.alert.create({
    header: "Alert",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: ans+'would you like to update?',
    buttons: [{ text     : 'Okay',
   
    
    handler: () => {
               this.clickcall={};
            // this.CallConnectModal.hide(); sijin
            this.stopCall();
            console.log(this.item);
            this.EndCallobj.callerName=window.localStorage['userName'];
            this.EndCallobj.callerMobile=window.localStorage['mobile'];
            this.EndCallobj.customerName=this.item.CustomerName;
            this.EndCallobj.customerMobile=this.item.Mobile;
            this.EndCallobj.customerId=this.item.CBSCustomerId;
            //this.EndCallobj.cust=this.item.custCat;
            this.EndCallobj.endStatus= 'I';
            this.EndCallobj.currDate = this.repStatus.data[0].start_time;
            this.EndCallobj.endDate = this.repStatus.data[0].end_time;
            // this.Endcall(this.EndCallobj);
            this.smaAccountactionModal(this.item)
            // this.customerActionModal(this.item);
    }
  },
  { text     : 'No',
   
    
  handler: () => {
    this.clickcall={};
    // this.CallConnectModal.hide(); cmd by sijin
    this.stopCall();
  }
},]
  });

 await alert.present();
}

  Endcall(obj){
    debugger
    var clickid=this.clickcallID.id
    console.log(obj);
    if(obj.endDate == undefined || obj.endDate == 'undefined' || obj.endDate == null || obj.endDate == ''){
      var enDate = new Date();
      //  this.endDate = $filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
       this.endDate = moment(enDate).format('YYYY-MM-DD h.mm a')
      // this.endDate = $filter('date')(enDate, 'hh-mm-ss');
      console.log(this.endDate);
      }else{
        var enDate= new Date(obj.endDate);
        this.endDate = moment(enDate).format('YYYY-MM-DD h.mm a')
        // this.endDate =$filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
        console.log(this.endDate);
      }
      var curDate= new Date(obj.currDate);
      this.currDate = moment(curDate).format('YYYY-MM-DD h.mm a')
      // this.currDate = $filter('date')(curDate, 'yyyy-MM-dd hh-mm-ss');
      console.log(this.currDate);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var purpose = 'demand collection';
    

    // this.apiservice.callStatusLead(clickid).then((res:any)=>{
    //   debugger
    //   if(res !='' ){
    //     var dce=JSON.parse(JSON.parse(res.data))
    //     if(dce==''){
    //       this.smaAccountactionModal(this.item)
    //     }else{
    //     if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length !='0'){
    //       var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
    //       console.log(xyz)
        
    //       if(xyz[0].recording==''){
    //         this.voicerecording='No Record'
    //       }else{
    //       this.voicerecording=xyz[0].recording.slice(28)
    //       }
    //       if(xyz[0].location==''){
    //         this.location="no record"
    //       }else{
    //         this.location=xyz[0].location
    //       }
    //       if(xyz[0].provider==''){
    //         this.provider="no provider"
    //       }else{
    //         this.provider=xyz[0].location
    //       }
  
    //     this.apiservice.EndCAllClick2(obj.customerId,obj.customerName,obj.customerMobile,userid,branchid,obj.callerMobile,xyz[0].start_time,xyz[0].end_time,purpose,xyz[0].duration, xyz[0].billsec,xyz[0].credits,xyz[0].status,xyz[0].status2,this.voicerecording,this.location,this.provider)
    //     .then((response:any)=> {
    //       debugger
    //       // console.log(response)
    //       // this.hidespin($ionicLoading);
    //       if(obj.endStatus == 'I'){
         
    //         this.endcallpopup()
    //     }else{
    //       this.clickcall={};
    //             // this.CallConnectModal.hide();
    //             this.stopCall();
    //             console.log(this.item);
    //             this.smaAccountactionModal(this.item);
    //     }
    //     } ,(err)=>{
    //       debugger
    //       console.log(err);
         
    //       this.Alertservice.presentAlert('Error', err.status);
    //     }     )
        
    //     // .catch((error)=>{
    //     //   this.AlertService.presentAlert('failed',console.error(error));
          
    //     // });
    //   }else{
    //     this.smaAccountactionModal(this.item);
    //     }
    //     }}else{
    //       this.smaAccountactionModal(this.item);
    //     }
    // },(err)=>{
    //   debugger
    //   console.log(err);
     
    //   this.Alertservice.presentAlert('Error', err.status);
    // }    )



    this.apiservice.callStatusLead(clickid).then((res:any)=>{

      debugger
     res= JSON.stringify(res)
     res=JSON.parse(res)
  
  
  
  
      if(res=='' ){
       
        this.stopCall();
        // console.log($scope.item);
        this.smaAccountactionModal(this.item)
      }else{
      
      if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
        // $scope.clickTocallConnect.hide();
        this.stopCall();
        // console.log($scope.item);
        this.smaAccountactionModal(this.item)
      }else{
      
      var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
      
      if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
        this.voicerecording='No Record'
      }else{
      this.voicerecording=xyz[0].recording.slice(28)
      }
      if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
      this.location="no record"
      }else{
        this.location=xyz[0].location
      }
      if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
        this.provider="no provider"
      }else{
        this.provider=xyz[0].provider
      }
      if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
        this.status="no status"
      }else{
       this.status=xyz[0].status
      }
      if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
        this.status2="no status"
      }else{
       this.status2=xyz[0].status2
      }
      
      this.apiservice.EndCAllClick2(obj.customerId,obj.customerName,obj.customerMobile,userid,branchid,obj.callerMobile,xyz[0].start_time,xyz[0].end_time,purpose,xyz[0].duration, xyz[0].billsec,xyz[0].credits,xyz[0].status,xyz[0].status2,this.voicerecording,this.location,this.provider)
        .then((response:any)=> {
                debugger
            
                // obj.endStatus == 'I'
                if(obj.endStatus == '0'){
             
               
    
                  this.endcallpopup()
    
              }else{
                debugger
               this.clickcall={};
                     
                    this.stopCall();
                      // console.log($scope.item);
                      this.smaAccountactionModal(this.item)
              }
              },err=>{
                this.Alertservice.presentAlert("Error",err.status)
              })
              
            
            }
              }
            })



    
    
  }

  async smaAccountactionshow(item){

    // this.apiservice.demandcollectionarray=[]
    // this.apiservice.demandcollectionarray.push(item,{close:"endcalldemand"})
    // this.route.navigateByUrl('/demandcollectionmodal')
    const modal = await this.modalController.create({
      component: DemandcollectionmodalPage,
      componentProps: { Data: item }
    });
    return await modal.present();
  }

  smaAccountactionModal(items){

    
    console.log(items);

    // this.data.addressname = "";
    // this.data.callout = "";
    // this.data.selectele = "";       
    // this.data.followupdate = "";
    // this.data.followuptime = "";
    // this.data.jointvisit = "";
    // this.data.jointcode = "";
    // this.data.jointusername = "";
    // this.customeractiondata = items;
    // window.localStorage['customerID'] = this.customeractiondata.CBSCustomerID;
    // window.localStorage['callID'] = this.customeractiondata.ROWID;
    // this.data.customerid=this.customeractiondata.CBSCustomerID;
    // this. customerid = items.CBSCustomerID;
    // this.data.collected_accno = this.customeractiondata.AccountNumber;

    this.smaAccountactionshow(items);

//     if (this.customerid == null) {

//         this.enable = false;
  
//       }
//       if (this.customerid != null) {
//         this.enable = true;
//         // this.showspin();

//         this.apiservice.getcustomerdetails(this.customerid)
//           .then( (response:any)=> {
//             debugger
//             // this.hidespin();
//             response = JSON.parse(response.data);
//             this.Npacustomerdata = JSON.parse(response);
//             console.log(this.Npacustomerdata)
//             if(this.Npacustomerdata != "" && this.Npacustomerdata != undefined)
//             {
//             this.data.customerid = this.customerid;
//             this.data.customername = this.Npacustomerdata[0].Nfirstname + ' ' + this.Npacustomerdata[0].Nlastname;
//             window.localStorage['customerName'] = this.data.customername;
//             this.data.firstname = this.Npacustomerdata[0].Nfirstname;
//             this.data.lastname = this.Npacustomerdata[0].Nlastname;
//             this.data.mobile = this.Npacustomerdata[0].Nmobile;
//             this.data.resphnno = this.Npacustomerdata[0].Nresidencephone;
//             this.data.email = this.Npacustomerdata[0].Nemail;
  
//             this.firstWords = [];
  
//             var firstname = [];
  
//             if (this.Npacustomerdata.length > 0) {
//               // this.showspin();
//             }
//             for (let i = 0; i < this.Npacustomerdata.length; i++) {
  
//               firstname = this.Npacustomerdata[i].Nfirstname.split(" ");
  
//               this.firstWords.push(firstname[0]);
//               this.Npacustomerdata[i].firstname = this.firstWords[i];
//               this.firstname1 = this.Npacustomerdata[i].firstname;
//               if (i == this.Npacustomerdata.length - 1) {
//                 // this.hidespin();
//               }
//             }
  
//             console.log(this.Npacustomerdata[0].Add1);
//             if(this.Npacustomerdata[0].Add1 != undefined || this.Npacustomerdata[0].Add2 != undefined || this.Npacustomerdata[0].Add3 != undefined || this.Npacustomerdata[0].Add4 != undefined || this.Npacustomerdata[0].PIN != undefined){

//               var respAdd1= this.Npacustomerdata[0].Add1;
//               var add1 = respAdd1;
//               console.log(add1);
//               var respAdd2= this.Npacustomerdata[0].Add2;
//               var add2 = respAdd2;
//               console.log(add2);
//             this.data.addressname = add1+' '+add2+' '+this.Npacustomerdata[0].Add3+' '+this.Npacustomerdata[0].Add4+' '+this.Npacustomerdata[0].PIN;
//             console.log(this.data.addressname);
//             }
//             if(this.data.addressname != "" && this.data.addressname != undefined)
//             { 
//               console.log(this.data.addressname);
//             //  this.myvalue = true;
//              //this.data.selectele='P';
//             //  this.setlatlong(this.data.addressname); hide ramesh
//             }
           
//            }
//           })
//     this.purposeID= items.PURPOSEID;
//     this.purpose = items.PURPOSE;
//     this.data.courtesypurp = this.purposeID; 
// }
  }

async endcallpopup(){
  debugger
  const alert:any = await this.alert.create({
    header: "Alert",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "You have ended the call explicitly. would you like to update?",
    buttons: [{ text     : 'Okay',
   
    
    handler: () => {
      this.clickcall={};
            // this.CallConnectModal.hide();
            this.stopCall();
            console.log(this.item);
            this.clickcall={};
            // this.CallConnectModal.hide();
            // this.stopCall();
            // console.log(this.item);
            this.smaAccountactionModal(this.item);
            // this.customerActionModal(this.item);
    }
  },
  { text     : 'No',
   
    
  handler: () => {
    this.clickcall={};
    // this.CallConnectModal.hide(); cmd by sijin
    this.stopCall();
  }
},]
  });

 await alert.present();
}
  

  modelDissmiss(){
    this.alert.dismiss()
    this.modalController.dismiss();
   }
}


