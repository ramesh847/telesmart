import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FollowupleadcallconnectPageRoutingModule } from './followupleadcallconnect-routing.module';

import { FollowupleadcallconnectPage } from './followupleadcallconnect.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FollowupleadcallconnectPageRoutingModule
  ],
  declarations: [FollowupleadcallconnectPage]
})
export class FollowupleadcallconnectPageModule {}
