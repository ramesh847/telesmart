import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MplannerrtgscallconnectPage } from './mplannerrtgscallconnect.page';

describe('MplannerrtgscallconnectPage', () => {
  let component: MplannerrtgscallconnectPage;
  let fixture: ComponentFixture<MplannerrtgscallconnectPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MplannerrtgscallconnectPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MplannerrtgscallconnectPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
