import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DairyuserdetailscheckPage } from './dairyuserdetailscheck.page';

describe('DairyuserdetailscheckPage', () => {
  let component: DairyuserdetailscheckPage;
  let fixture: ComponentFixture<DairyuserdetailscheckPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DairyuserdetailscheckPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DairyuserdetailscheckPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
