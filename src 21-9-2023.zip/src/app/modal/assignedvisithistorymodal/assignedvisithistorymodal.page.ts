import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';

@Component({
  selector: 'app-assignedvisithistorymodal',
  templateUrl: './assignedvisithistorymodal.page.html',
  styleUrls: ['./assignedvisithistorymodal.page.scss'],
  providers:[DatePipe,Idle]
})
export class AssignedvisithistorymodalPage implements OnInit {
  cbscustomerId: any;
  assignedvisitshistorydata: any;
  firstWords: any[];
  firstname1: any;
  idleState: string;

  constructor(private datepipe:DatePipe,private AlertService:AlertServiceService,private navParams:NavParams,
    private Apiservice:ApiServiceService,private idle:Idle,private router:Router) {  // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>{
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      );}

  ngOnInit() {
    let Cusdata = this.navParams.get('Data');


  
      // console.log(obj)
      // this.HistoryModal.show();
      var cbscustomerId = Cusdata.CBSCustomerID;
      this.cbscustomerId = Cusdata.CBSCustomerID;
      var BranchId = window.localStorage['branchID'];
  
     // this.showspin();
      this.Apiservice.gethistorydetails(cbscustomerId, BranchId)
        .then((response:any)=> {
         // this.hidespin();
         var result = response.data;
         result = JSON.parse(result);
         result = JSON.parse(result);
  
          this.assignedvisitshistorydata = result;
  
          var firstname = [];
          this.firstWords = [];
  
  
          for (let i = 0; i < this.assignedvisitshistorydata.length; i++) {
  
            firstname = this.assignedvisitshistorydata[i].CustomerName.split(" ");
            this.firstWords.push(firstname[0]);
  
            this.assignedvisitshistorydata[i].firstname = this.firstWords[i];
            this.firstname1 = this.assignedvisitshistorydata[i].firstname;
          }
          console.log(this.assignedvisitshistorydata)
        
  
          console.log(response);
  
        })
     
  // this.reset()
  
    };
reset(){
  this.idle.watch()
}

  

}
