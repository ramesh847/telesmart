import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController, NavParams } from '@ionic/angular';
import { AlertServiceService } from 'src/app/service/alert-service.service';

import { ApiServiceService } from '../../../service/api-service.service';
import { AssignedvisitupdatemodalPage } from '../assignedvisitupdatemodal.page';

@Component({
  selector: 'app-endcallmodal',
  templateUrl: './endcallmodal.page.html',
  styleUrls: ['./endcallmodal.page.scss'],
  providers:[DatePipe]
})
export class EndcallmodalPage implements OnInit {
  Cusdata: any;
  clickcall:any={};
  obj:any={};
  result: any;
  resout: any;
  clickcallID: any;
  interval: any;
  statusResp: any;
  repStatus: any;
  EndCallobj:any={}
  endDate: string;
  currDate: string;
  voicerecording: string;
  location: string;
  provider: string;
  status: string;
  status2: string;
  constructor(public route:Router,public modalController: ModalController,
    private alert:AlertController,private datepipe:DatePipe,
    private AlertService:AlertServiceService,private navParams:NavParams,
    private Apiservice:ApiServiceService) { }

  ngOnInit() {
    debugger
    this.Cusdata = this.navParams.get('Data');
    this.clickcall.callerName= window.localStorage['userName']
    // localStorage.setItem('userName','3442');
    // localStorage.setItem('userType','11');
    //this.clickcall.callerMobile=localStorage.setItem('mobile','9490739835');
    this.clickcall.customerName=this.Cusdata.CustomerName;
    this.clickcall.customerMobile=this.Cusdata.Mobile;
    this.clickcall.customerId=this.Cusdata.CBSCustomerID;
    this.clickcall.purpose=this.Cusdata.Purpose;
    this.obj.callerName=window.localStorage['userName']
    this.obj.callermobile= window.localStorage['mobile']
        this.obj.customerName=this.Cusdata.CustomerName     
        
       this.obj.customerMobile=this.Cusdata.Mobile;
      this.obj.customerId=this.Cusdata.	CBSCustomerID;
        this.obj.purpose=this.Cusdata.Purpose;
        var currentDate=new Date();
        this.obj.currDate=currentDate
       // this.callermobile=localStorage.getItem('mobile');
        //this.usertype=localStorage.getItem('userType')
    
        this.Apiservice.clickToCallFollowUP(this.obj.callermobile,this.obj.customerMobile,this.obj.purpose).then((response:any)=> {
          debugger
          console.log(response.data)
          // this.hidespin($ionicLoading);
if(response==''){
  this.AlertService.presentAlert("Alert","Id not Generate")
}else{
          this.result = JSON.parse(response.data);
          this.resout = JSON.parse( JSON.parse(this.result));
          if(this.resout.status == '200'){
            this.clickcallID = this.resout.data;
            this.callinterval();
            // this.CallConnectModal.show();
          }else{
            this.AlertService.presentAlert("Alert",this.resout.message)
            return false
           // alert(response)
          // var alertPopup = $ionicPopup.alert({
          //   title: 'Alert',
          //   template: response
          // });
        
          // alertPopup.then(function(res) {
          // });
          }
      
        }
        })
  }
  callResp(){
    debugger
    console.log(this.clickcallID.id);
    var id = this.clickcallID.id;
    this.Apiservice.callStatusFollowUp(id)
    .then((response:any)=> {
      debugger
    //  console.log(response)
      this.statusResp= JSON.parse(JSON.parse(JSON.parse(response.data)))
      this.repStatus = this.statusResp;
      //this.hidespin($ionicLoading);
      console.log(JSON.parse( JSON.parse(response.data)).length);
      if(JSON.parse(JSON.parse(JSON.parse(response.data))).data.length == 1){
        console.log(this.repStatus.data[0].status2);
      if(this.repStatus.data[0].status2 != null){
        console.log(this.repStatus.data[0]);
        if(this.repStatus.data[0].status2 == 'ANSWER'){
          this.stopCall();
         // this.CallConnectModal.hide();
          console.log(this.currDate);
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile= window.localStorage['mobile'];
          this.EndCallobj.customerName=this.Cusdata.CustomerName;
          this.EndCallobj.customerMobile=this.Cusdata.Mobile;
          this.EndCallobj.customerId=this.Cusdata.CBSCustomerID;
          //this.EndCallobj.purpose=this.item.purpose_id;
          this.EndCallobj.purposeText= this.Cusdata.Purpose.split('/').join('-');
          this.EndCallobj.endStatus= 'A';
          //var currentDate= new Date();
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          this.Endcall(this.EndCallobj);
          // this.End(this.Cusdata);
          // this.assignedvisitUpdateModal(this.Cusdata)
        }else{
         
         
           
            this.callResppopup(this.repStatus.data[0].status2)
           
        
  
  
        }
        
      }
    }
    })
    
  
  }
  async callResppopup(ans){
    debugger
    const alert = await this.alert.create({
      header: ans+'Would you like to update?',
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: '',
      buttons: [{ text     : 'Yes',
     
      
      handler:() => {
        // this.alert.dismiss
        this.clickcall={};
          //this.CallConnectModal.hide();
         
          this.stopCall();
          console.log(this.Cusdata);
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile= window.localStorage['mobile'];
          this.EndCallobj.customerName=this.Cusdata.CustomerName;
          this.EndCallobj.customerMobile=this.Cusdata.Mobile;
          this.EndCallobj.customerId=this.Cusdata.CBSCustomerID;
          //this.EndCallobj.purpose=this.item.purpose_id;
          this.EndCallobj.purposeText= this.Cusdata.Purpose;
          this.EndCallobj.endStatus= 'I';
          //var currentDate= new Date();
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          // this.Endcall(this.EndCallobj);
          // this.End(this.Cusdata);
          this.assignedvisitUpdateModal(this.Cusdata)
      }
    },
    {
      text     : 'No',
     
      
      handler:() => {
        // this.alert.dismiss()
        this.clickcall={};
        
         // this.CallConnectModal.hide();
          this.stopCall();
          this.modelDissmiss()
         //this.followupcallsUpdmodal(this.item);
      }
    }
  ]
    });
    await alert.present()
  }

  modelDissmiss() {
    this.alert.dismiss()
    this.modalController.dismiss();
  }
  Endcall(obj)
{
debugger
  console.log(obj);

  var clickid=this.clickcallID.id
  if(obj.endDate == undefined || obj.endDate == 'undefined' || obj.endDate == null || obj.endDate == ''){
    var enDate= new Date();
     this.endDate =this.datepipe.transform(enDate, 'yyyy-MM-dd hh-mm-ss')
    // this.endDate = $filter('date')(enDate, 'hh-mm-ss');
    console.log(this.endDate);
    }else{
      var enDate= new Date(obj.endDate);
      this.endDate =this.datepipe.transform(enDate, 'yyyy-MM-dd hh-mm-ss')
      console.log(this.endDate);
    }
    var curDate= new Date(obj.currDate);
    this.currDate = this.datepipe.transform(curDate, 'yyyy-MM-dd hh-mm-ss');
    console.log(this.currDate);
  var branchid = window.localStorage['branchID'];
  var usertype = window.localStorage['userType'];
  var userid = window.localStorage['userID'];
  var purpose = 'Assigned Visit';

 

  this.Apiservice.callStatusLead(clickid).then((res:any)=>{

    debugger
   res= JSON.stringify(res)
   res=JSON.parse(res)




    if(res=='' ){
     
      this.stopCall();
      // console.log($scope.item);
      this.assignedvisitUpdateModal(this.Cusdata);
    }else{
    
    if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
      // $scope.clickTocallConnect.hide();
      this.stopCall();
      // console.log($scope.item);
      this.assignedvisitUpdateModal(this.Cusdata);
    }else{
    
    var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
    
    if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
      this.voicerecording='No Record'
    }else{
    this.voicerecording=xyz[0].recording.slice(28)
    }
    if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
    this.location="no record"
    }else{
      this.location=xyz[0].location
    }
    if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
      this.provider="no provider"
    }else{
      this.provider=xyz[0].provider
    }
    if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
      this.status="no status"
    }else{
     this.status=xyz[0].status
    }
    if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
      this.status2="no status"
    }else{
     this.status2=xyz[0].status2
    }
    
    this.Apiservice.EndCAllClick2(obj.customerId,obj.customerName,obj.customerMobile,userid,branchid,obj.callerMobile,xyz[0].start_time,xyz[0].end_time,purpose,xyz[0].duration, xyz[0].billsec,xyz[0].credits,this.status,this.status2,this.voicerecording,this.location,this.provider)
      .then((response:any)=> {
              debugger
          
              // obj.endStatus == 'I'
              if(obj.endStatus == '0'){
           
             
  
                this.assignendcall()
  
            }else{
              debugger
             this.clickcall={};
                   
                  this.stopCall();
                    // console.log($scope.item);
                    this.assignedvisitUpdateModal(this.Cusdata);
            }
            },err=>{
              this.AlertService.presentAlert("Error",err.status)
            })
            
          
          }
            }
          })

}
stopCall(){
  clearInterval(this.interval)
}
async assignendcall(){
  debugger
  const alert = await this.alert.create({
    header: 'You have ended the call explicitly. would you like to update?',
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: '',
    buttons: [{ text     : 'Yes',
   
    
    handler:() => {
      // this.alert.dismiss
      this.clickcall={};
              // this.CallConnectModal.hide();
              this.stopCall();
              console.log(this.Cusdata);
              this.assignedvisitUpdateModal(this.Cusdata);
      //  this.followupvisitsUpdateModal(this.Cusdata)
    }
  },
  {
    text     : 'No',
   
    
    handler:() => {
      // this.alert.dismiss()
      this.clickcall={};
      // this.CallConnectModal.hide();
      this.stopCall();
      this.modelDissmiss()
    }
  }
]
  });
  await alert.present()
}
callinterval(){
  this.interval = setInterval(() => {
    this.callResp();
        // clearInterval(this.interval)
      }, 10000);
}
assignedvisitUpdateModal(obj) {
   
    
  this.assignmodelshow(this.Cusdata);
   

 };


 async assignmodelshow(items){

//   this.Apiservice.assignedvistendcallary=[]
// this.Apiservice.assignedvistendcallary.push(items,{close:"endcallassign"})
// this.route.navigateByUrl('/assignedvisitupdatemodal')


   const modal = await this.modalController.create({
     component: AssignedvisitupdatemodalPage,
     componentProps: { Data: items }
   });
   return await modal.present();
 }
}
