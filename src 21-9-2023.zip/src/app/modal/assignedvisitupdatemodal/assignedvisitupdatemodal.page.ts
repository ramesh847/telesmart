import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavParams,ModalController, AlertController } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';

@Component({
  selector: 'app-assignedvisitupdatemodal',
  templateUrl: './assignedvisitupdatemodal.page.html',
  styleUrls: ['./assignedvisitupdatemodal.page.scss'],
  providers:[DatePipe,Idle]
})
export class AssignedvisitupdatemodalPage implements OnInit {
  savebool:boolean
  save_custname: any;
  savemon: any;
  savefn: any;
  saveIn: any;
 
  Collectiondate1: any;
  collectionmode: any;
  collectiondate: any;
  nextcalldate1: any;
  followuptime: any;
  nextcalldate: any;
  jointvisit: any;
  lat1: any;
  lng1: any;
  branchid: any;
  usertype: any;
  userid: any;
  purpose: any;
  CallerId: any;
  username: any;
  usercode: any;
  getfollowdates: string;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  hidecalloutcome: boolean;
  fullname: any;
  cust_id: any;
  purposeid: any;
  saveln: any;
  enable: boolean;
  assignedvisitscustomerdata: any;
  assignedvisitdata: any;
  firstWords: any[];
  firstnamemodel: any;
  callOutCome: any;
  assignedvisit:any={}
  getusername: any;
  firstname1: any;
  cbsid: any;
  customername1: any;
  mobile1: any;
  calltype: any;
  callid: any;
  remarks1: any;
  lastname1: any;
  responseid: any;
  BusinessUnit: number;
  mobile: any;
  firstname: any;
  lastname: any;
  remarks: any;
  customername: any;
  accountno: any;
  amount: any;
  Endtime: any;
  Totime: any;
  date: string;
  jointcode: any;
  latvalue: any;
  langvalue: any;
  address: any;
  Cusdata1:any;
  idleState: string;
  constructor(private datepipe:DatePipe,private AlertService:AlertServiceService,
    private loader:ToastServiceService,private alert1:AlertController,
    //  private navParams:NavParams,
    private Apiservice:ApiServiceService,public route:Router,public modalController: ModalController,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.route.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>{
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    debugger
    // let Cusdata = this.navParams.get('Data');
    this.Cusdata1=this.Apiservice.assignedvistendcallary
    let Cusdata=this.Cusdata1[0]
    this.assignedvisitUpdateModal(Cusdata)
// this.save_custname=Cusdata.CustomerName
// this.savemon=Cusdata.Mobile
// this.savefn=Cusdata.firstname
// this.saveIn=Cusdata.grpname
// this. branchid = window.localStorage['branchID'];
// this. usertype = window.localStorage['userType'];
// this. userid = window.localStorage['userID'];
// this. purpose = Cusdata.purpose;
// this. CallerId = window.localStorage['userID'];
// this. username = window.localStorage['UserName'];
// this. usercode = window.localStorage['userCode'];
// this.reset()
  }
  reset(){
    this.idle.watch()
  }
getcalloutcome() {
    // this.showspin()
    this.Apiservice.getcalloutcome()
      .then((response:any)=> {
        debugger
        // this.hidespin();
        console.log(response.data);
        response = JSON.parse(JSON.parse( response.data));
        this.callOutCome = response;

        // this.hidespin()
      },err=>{
        if(err.status == '-4'){
          this.AlertService.presentAlert("Error", "Request Time Out")
        }else if(err.status == '-3'){
          this.AlertService.presentAlert("Error","Host could not be resolved")
        }else
        {
        
        this.AlertService.presentAlert("Error", err.status)
        }
      })
      
  }
  assignedvisitUpdateModal(obj) {
    debugger
    this.getcalloutcome()
    this.assignedvisit.Purpose = obj.Purpose;

   console.log( this.assignedvisit.Purpose);

//Condition to hide call closed option for NPA followup and VVIP Visits purposes
if(this.assignedvisit.Purpose != "NPA followup" && this.assignedvisit.Purpose != "VVIP Visits"){
  this.hidecalloutcome = false;
}else{
  this.hidecalloutcome = true;
}


    this.assignedvisit.current = "";
    this.assignedvisit.customername1 = obj.firstname;
    /*   this.assignedvisit.starttime = "";
       this.assignedvisit.endtime = "";   */
    this.assignedvisit.collecteddate = "";
    this.assignedvisit.collectedaccnumber = "";
    this.assignedvisit.collectedamount = "";
    this.assignedvisit.calloutcome = "";
    this.assignedvisit.followdate = "";
    this.assignedvisit.followtime = "";
     this.assignedvisit.calltype = 'P';
    this.assignedvisit.JointVisit = "";
    this.assignedvisit.jointusername = "";
    this.assignedvisit.jointcode = "";
    this.assignedvisit.remarks = "";

    //address
    this.assignedvisit.addressname="";
      // $("#showdivs_ssignvisits").css("display", "none");
    // this.UpdateModal.show();
    console.log(obj)

    this.fullname = obj.CustomerName;
    this.cust_id = obj.CBSCustomerID;
    console.log(this.cust_id)
    window.localStorage['customerID'] = obj.CBSCustomerID;
    console.log(window.localStorage['customerID']);
    window.localStorage['callID'] = obj.Callid;
    // var courtesydate= obj.CourtesyDate; this.datepipe.transform(new Date(), 'yyyy-MM-dd');
    var newdate =this.datepipe.transform(new Date(), 'yyyy-MM-dd');
    window.localStorage['Next_Call_Date'] = newdate;
    window.localStorage['PurposeID'] = obj.purposeVal;
    this.purposeid = obj.purposeVal;
    window.localStorage['DNP_AAmount'] = obj.DNPAAmount;
    window.localStorage['Account_No'] = obj.AccountNumber;
    // var date= obj.ToCallDate;
    var tocalldate = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
    window.localStorage['To_Call_Date'] = tocalldate;
    console.log(window.localStorage['To_Call_Date'])

    this.save_custname = obj.CustomerName;
    console.log(this.save_custname);

    this.savemon = obj.Mobile;
    this.savefn = obj.firstname;
    this.saveln = obj.grpname;



    if (this.cust_id == null) {

      this.enable = false;

    }
    if (this.cust_id != null) {
      this.enable = true;
      


}
this.Apiservice.getexistingcustomerdetails(this.cust_id)
.then((response:any)=> {
  debugger
  console.log(response);
  var response1 = JSON.parse(JSON.parse(JSON.parse(response.data)))
  console.log(response1);
 this.assignedvisitscustomerdata = response1;
  console.log(this.assignedvisitscustomerdata)
  //this.assignedvisit.customerid =this.assignedvisitscustomerdata[0].;
 this.assignedvisit.customerid = window.localStorage['customerID'];
 this.assignedvisit.customername = response1[0].Nfirstname + ' ' + response1[0].Nlastname;
  console.log(this.assignedvisit.customername);
 this.assignedvisit.firstname =this.assignedvisitscustomerdata[0].Nfirstname;
 this.assignedvisit.lastname =this.assignedvisitscustomerdata[0].Nlastname;
 this.assignedvisit.mobile =this.assignedvisitscustomerdata[0].Nmobile;
 this.assignedvisit.email =this.assignedvisitscustomerdata[0].Nemail;
  var respAdd1=this.assignedvisitscustomerdata[0].Add1;
  var add1 = respAdd1.replace("/", "-");
  console.log(add1); 
  var respAdd2=this.assignedvisitscustomerdata[0].Add2;
  var add2 = respAdd2.replace("/", "-");
  console.log(add2);
 this.assignedvisit.addressname = add1 +' '+add2 +' '+this.assignedvisitscustomerdata[0].Add3 +' '+this.assignedvisitscustomerdata[0].Add4;
  var firstname = [];
 this.firstWords = [];
  
  console.log(this.assignedvisitscustomerdata);

  for (let i = 0; i <this.assignedvisitscustomerdata.length; i++) {
console.log(this.assignedvisitscustomerdata[i].Nfirstname);
    firstname =this.assignedvisitscustomerdata[i].Nfirstname.split(" ");
    console.log(firstname);
   this.firstWords.push(firstname[0]);

   this.assignedvisitscustomerdata[i].firstname =this.firstWords[i];
    console.log(this.assignedvisitscustomerdata)
   this.firstname1 =this.assignedvisitscustomerdata[i].firstname;
  }
//  this.hidespin();
})


  };
 
  handleChange(event){
    debugger
  this.assignedvisit.calloutcome=  event.target.value
  }
verifytime() {
  debugger
  var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
  this.getfollowdates = this.datepipe.transform( this.assignedvisit.followdate,'YYYY-MM-dd')
  if (this.getfollowdates <= date) {
    this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
 return false
  }
 
}


checkusercode (val) {
  var usercode = val;
  var branchid = window.localStorage['branchID'];

  // this.showspin();
  this.Apiservice.getusername(usercode, branchid)
    .then((response:any) =>{
  // this.hidespin();

      console.log(response);
      response = JSON.parse(JSON.parse(response.data));
      if (response == "This User Not in this Branch") {

        this.AlertService.presentAlert("","Please Enter The Valid Emp Code")
        this.assignedvisit.jointusername = "";
        this.assignedvisit.jointcode = "";

      } else {
        this.getusername = response;
        this.assignedvisit.jointusername = this.getusername;
        console.log(this.getusername)
      }

    })
    .catch((error)=>{
      this.AlertService.presentAlert('Error',console.error(error));
      
    });
}
async asvisstatus(msg){
  const alert:any = await this.alert1.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Please Visit Follow Up Screen As It Is In FOLLOW UP Status "+msg,
    buttons: [{ text     : 'Ok',
   
    
    handler: () => {
     this.modelDissmiss()
    }
  },
 ]
  });
  await alert.present()
}

async asignvismethod(){
  const alert:any = await this.alert1.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Saved Successfully",
    buttons: [{ text     : 'Ok',
   
    
    handler: () => {
     this.modelDissmiss()
    }
  },
 ]
  });
  await alert.present()
}

modelDissmiss(){
  debugger
  if(this.Cusdata1[1].close=="assignedvisit" || this.Cusdata1[1].close=="endcallassign"){
    this.closemethod()
  }
}
checkboxClick(Event){
  debugger
  console.log(Event);
  
  if(Event == true){
    this.assignedvisit.JointVisit = 'N';
  }else{
    this.assignedvisit.JointVisit = "Y";
  }
  // console.log(this.followupvisits.JointVisit)
}

  saveassignedvisits(obj){
debugger


  console.log(obj)

 // this.showspin($ionicLoading);
 
this. branchid = window.localStorage['branchID'];
this. usertype = window.localStorage['userType'];
this. userid = window.localStorage['userID'];
// this. purpose = Cusdata.purpose;
this. CallerId = window.localStorage['userID'];
this. username = window.localStorage['UserName'];
this. usercode = window.localStorage['userCode'];

  this. cbsid = window.localStorage['customerID'];

  this. customername1 = this.save_custname;
  console.log(this.save_custname);
 
  this. mobile1 = this.savemon;
 
  this. calltype = this.assignedvisit.calltype;
  this. callid = window.localStorage['callID']
  this. remarks1 = this.assignedvisit.remarks;


  this. firstname1 = this.savefn;
  this. lastname1 = this.saveIn;
  /* var firstname1 = this.assignedvisit.firstname;
   var lastname1 = this.assignedvisit.lastname;*/
  this. responseid = this.assignedvisit.calloutcome;
  this. purpose = window.localStorage['PurposeID'];
  console.log(this.assignedvisit.calloutcome)
  this. BusinessUnit = 0;

  if (this.customername1 == "" || this.customername1 == undefined || this.customername1 == "undefined") {
    if(this.firstname1 == "" || this.firstname1 == undefined ||this. firstname1 == "undefined"){
      if(this.lastname1 == "" || this.lastname1 == undefined || this.lastname1 == "undefined"){
        this. customername = null;
      }else{
        this. customername = this.lastname1;
      }
    }else{
      this. customername =this. firstname1;
    }
    
  } else {
    this. customername =this. customername1;
  }


  if (this.mobile1 == "") {

    this. mobile = null;
  } else {
    this. mobile = this.mobile1;
  }

  if (this.firstname1 == "") {

    this. firstname = null;
  } else {
    this. firstname = this.firstname1;
  }

  if (this.lastname1 == "") {

    this. lastname = null;
  } else {
    this. lastname = this.lastname1;
  }

  /* var cbsid = this.assignedvisit.customerid;*/

  if (this.remarks1 == "") {

    this. remarks = null;
  } else {
    this. remarks = this.remarks1;
  }

  if (this.purpose == "5" && this.assignedvisit.current == "Y") {
    if ((this.assignedvisit.collecteddate == null || this.assignedvisit.collecteddate == "" || this.assignedvisit.collecteddate == undefined) || (this.assignedvisit.collectedaccnumber == undefined || this.assignedvisit.collectedaccnumber == null || this.assignedvisit.collectedaccnumber == "") || (this.assignedvisit.collectedamount == null || this.assignedvisit.collectedamount == undefined || this.assignedvisit.collectedamount == "")) {

      this.AlertService.presentAlert("","Fill All Details Of Amount Collected")

     
      return false;

    } else {
      this. collectionmode = "Y";
      this.Collectiondate1 = this.assignedvisit.collecteddate;
      this. collectiondate =this.datepipe.transform( this.Collectiondate1,'yyyy-MM-dd')
      //  $filter('date')(this.Collectiondate1, 'yyyy-MM-dd');
      this. accountno = this.assignedvisit.collectedaccnumber;
      this. amount = this.assignedvisit.collectedamount;
    }

  }


  if (this.purpose != "5") {
    this. collectionmode = null;

  }

  if (this.collectionmode == null) {
    this. accountno = null;
    this. amount = null;
    this. collectiondate = null;

  }


  if (this.purpose == "5") {
    if (this.assignedvisit.current == "" || this.assignedvisit.current == undefined || this.assignedvisit.current == null || this.assignedvisit.current == 'N') {

      this. collectionmode = null;
    }
  }

  this. Endtime = null;
  this. Totime = null;


  if (this.assignedvisit.calloutcome == "" || this.assignedvisit.calloutcome == null || this.assignedvisit.calloutcome == undefined) {
    this.AlertService.presentAlert("","Select Call OutCome")
  
    return false;
  }


  // console.log(responseid)
  if (this.responseid == "2") {
    if ((this.assignedvisit.followdate == null || this.assignedvisit.followdate == undefined || this.assignedvisit.followdate == "") || (this.assignedvisit.followtime == null || this.assignedvisit.followtime == undefined || this.assignedvisit.followtime == "")) {
      
      this.AlertService.presentAlert("","Provide Followup Details")
    
      return false;


    }
    else
    {
      this. date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
      this.getfollowdates = this.datepipe.transform( this.assignedvisit.followdate,'YYYY-MM-dd')
      if (this.getfollowdates <= this.date) {
        // this.followupvisits.followdate=''
        // this.followupvisits.followtime=''
        this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
        return false
      
      }else{

     this.nextcalldate1 = this.datepipe.transform(this.assignedvisit.followdate,'yyyy-MM-dd')
     //$filter('date')(this.assignedvisit.followdate, 'yyyy-MM-dd');
     // this.followuptime = this.datepipe.transform( this.assignedvisit.followtime, 'h.mm a')
     //$filter('date')(this.assignedvisit.followtime, 'h.mm a');


     
     //  $filter('date')(this.followupvisits.followdate, 'yyyy-MM-dd');
     var time = this.assignedvisit.followtime.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.assignedvisit.followtime];
 
   if (time.length > 1) { // If time format correct
     time = time.slice (1);  // Remove full string match value
     this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
     time[0] = +time[0] % 12 || 12; 
     time[1]="."// Adjust hours
   }
   this.modifytime1= time.join ('');
   if(this.getampm=="AM"){
     this.modifytime2= this.modifytime1+' '+"AM"
   }else{
     this.modifytime2= this.modifytime1+' '+"PM"
   }
 
       this. nextcalldate = this.nextcalldate1 + ' ' +  this.modifytime2;
     
 
  }
     // var nextcalldate = this.nextcalldate1 + ' ' + this.followuptime;
   }

  }

  if (this.responseid != "2") {
    /* var nextcalldate = " ";*/
    this. nextcalldate = null;
    //          var Endtime = null;
    // var Totime = null;

  }

  if (this.assignedvisit.calltype == "" || this.assignedvisit.calltype == undefined || this.assignedvisit.calltype == null) {
    this.AlertService.presentAlert("","Select Call Type")
    
    return false;

  }

  if (this.assignedvisit.calltype == "P" && this.assignedvisit.JointVisit == "Y") {
    if (this.assignedvisit.jointcode == null || this.assignedvisit.jointcode == "" || this.assignedvisit.jointcode == undefined) {
      this.AlertService.presentAlert("","Enter Joint Usercode")
     
      return false;
    } else {
      this. jointvisit = "Y";
      this. jointcode = this.assignedvisit.jointcode;

    }


  }

  if (this.assignedvisit.calltype == "P") {
    if (this.assignedvisit.JointVisit == "" || this.assignedvisit.JointVisit == undefined || this.assignedvisit.JointVisit == null || this.assignedvisit.JointVisit == 'N') {

      this. jointvisit = null;
    }
  }

  if (this.assignedvisit.calltype != "P") {

    this. jointvisit = null;

  }

  if (this.jointvisit == null) {
    this. jointcode = null;
  }

  /*  if (jointvisit == null) {
       var jointcode = null;
   }*/
  this.customername = this.customername.replace(/&/g, "");
  this.customername = this.customername.trim();


  if (this.assignedvisit.calltype == "P") {

    if ((this.assignedvisit.addressname == "") || ((this.assignedvisit.addressname == 'undefined') || (this.assignedvisit.addressname == undefined))) {
      console.log(this.assignedvisit.addressname)
      this.AlertService.presentAlert("","Enter Your Location")
   
      return false;

    } else {

      this. latvalue = this.lat1;

      this. langvalue = this.lng1;

      this. address = this.assignedvisit.addressname;
    }

  } else {
    //alert(latvalue)
    this. latvalue = null;
    this. langvalue = null;
    this. address = null;
  }

 // console.log(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit)

  if (this.assignedvisit.calltype == "P") {
    //this.showsp
    this.loader.presentLoading('')
    this.savebool=true
    this.Apiservice.updateassignedvisits(this.branchid, this.cbsid, this.customername, this.mobile, this.CallerId, this.username, this.calltype, this.remarks, this.purpose, this.responseid,this. nextcalldate, this.firstname, this.lastname, this.usercode, this.callid, this.accountno,this. amount, this.collectiondate, this.collectionmode, this.jointvisit, this.jointcode,this. Endtime,this. Totime, this.BusinessUnit)


      .then((res:any)=> {
debugger
        //this.hidespin();
        console.log(res);
        var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
        // response = JSON.parse(response);
        var success = [];
        this.loader.dismissLoading()
        success = response;
        window.localStorage['date'] = "";

        if (response !== "") {
        // console.log(success, latvalue, langvalue, address, cbsid)

        //string CRMID, string LatValue, string Langvalue, string Address, string purpose, string CBSCustomerid
       // this.showspin();
        this.Apiservice.saveaddress(success, this.latvalue, this.langvalue, this.address, this.purpose,this.cbsid)
          .then((response:any)=> {
            debugger
            // this.hidespin();
            var xyz=JSON.parse(JSON.parse(response.data))

            if(xyz=="Yes")
            {
              // this.AlertService.presentAlert("","Saved Successfully")  
              // this.modelDissmiss()
              // return false 

              this.asignvismethod()
              
//  var alertPopup = $ionicPopup.alert({
//           title: 'Success',
//           template: 'Saved Successfully'
//         });

        // alertPopup.then(function(res) {
        //   this.UpdateModal.hide();
        //   // Custom functionality....
        // });
            }
            else
            {
              this.AlertService.presentAlert("","Error While Saving")   
              return false

            }
          }).catch((error)=>{
            this.savebool=false
            this.AlertService.presentAlert('Error',console.error(error));
            
          });
      }
        
        window.localStorage['date'] = "";
        console.log(window.localStorage['date'])
        this.assignedvisit = {};
        this.lat1 = "";
        this.lng1 = ""
        this.getassignedvisitdata();
      }).catch((error)=>{
        this.savebool=false
        this.loader.dismissLoading()
        this.AlertService.presentAlert('Error',console.error(error));
        
      });
     


  } else {
    //this.showspin();
    this.savebool=true
    this.Apiservice.updateassignedvisits(this.branchid,this. cbsid, this.customername, this.mobile, this.CallerId, this.username, this.calltype, this.remarks,this. purpose, this.responseid, this.nextcalldate, this.firstname, this.lastname, this.usercode, this.callid,this. accountno, this.amount, this.collectiondate, this.collectionmode, this.jointvisit, this.jointcode,this. Endtime, this.Totime, this.BusinessUnit)


      .then((res:any)=> {
debugger
        //this.hidespin();
        // console.log(response);
        var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
        // response = JSON.parse(response);
        var success = [];
        success = response;
        window.localStorage['date'] = "";
        if (success[0].response == 1) {


          this.asvisstatus( success[0].Column1)
          // this.AlertService.presentAlert("",'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + success[0].Column1)
          // var alertPopup = $ionicPopup.alert({
          //   title: 'Warning',
          //   template: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + success[0].Column1
          // });

          // alertPopup.then(function(res) {
          //   this.UpdateModal.hide();
          //   // Custom functionality....
          // });

        } else {
this.asignvismethod()
          // this.AlertService.presentAlert("","Saved Successfully")
          // this.modelDissmiss()
          // var alertPopup = $ionicPopup.alert({
          //   title: 'Success',
          //   template: 'Saved Successfully',
          //   onTap: function(e) {
          //     this.lat1 = "";
          //     this.lng1 = "";
          //   }


          // });

          // alertPopup.then(function(res) {
          //   this.UpdateModal.hide();

          //   // Custom functionality....
          // });

        }
        window.localStorage['date'] = "";
        console.log(window.localStorage['date'])
        this.assignedvisit = {};
        this.lat1 = "";
        this.lng1 = ""
        this.getassignedvisitdata();
      }).catch((error)=>{
        this.savebool=false
        this.AlertService.presentAlert('Error',console.error(error));
        
      });
     
  

}


  }
  closemethod(){
    this.route.navigateByUrl('/myassignedvisits')
  }
  getassignedvisitdata(){
    debugger
    

      // this.showspin();
      var branchid = window.localStorage['branchID'];
      var usertype = window.localStorage['userType'];
      var userid = window.localStorage['userID'];
      // this.showspin();
      this.Apiservice.myassignedvisitsdata(branchid, userid, usertype)
        .then((response:any)=> {
          debugger
          // this.hidespin();
          debugger
          // response = JSON.parse(response);
          var result = response.data;
          result = JSON.parse(result);
          result = JSON.parse(result);
          this.assignedvisitdata = result;
          console.log(this.assignedvisitdata)
          this.firstWords = [];
  
          var firstname = [];
  
          for (let i = 0; i < this.assignedvisitdata.length; i++) {
  
            firstname = this.assignedvisitdata[i].CustomerName.split(" ");
  
            this.firstWords.push(firstname[0]);
            this.assignedvisitdata[i].firstname = this.firstWords[i];
            console.log(this.assignedvisitdata[i].firstname);
            this.firstnamemodel = this.assignedvisitdata[i].firstname;
  
  
          }
  
        //  $ionicLoading.hide();
  
        }).catch((error)=>{
          this.AlertService.presentAlert('Error',console.error(error));
          
        });
    
    
  }
  closeUpdateModal(){

  }

}
