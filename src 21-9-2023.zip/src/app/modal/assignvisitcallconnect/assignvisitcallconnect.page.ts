import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController } from '@ionic/angular';
import { modalController } from '@ionic/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';

@Component({
  selector: 'app-assignvisitcallconnect',
  templateUrl: './assignvisitcallconnect.page.html',
  styleUrls: ['./assignvisitcallconnect.page.scss'],
  providers:[DatePipe]
})
export class AssignvisitcallconnectPage implements OnInit {
  Cusdata: any;
  clickcall:any={};
  obj:any={};
  result: any;
  resout: any;
  clickcallID: any;
  interval: any;
  statusResp: any;
  repStatus: any;
  EndCallobj:any={}
  endDate: string;
  currDate: string;
  voicerecording: string;
  location: string;
  provider: string;
  status: string;
  status2: string;
  rowid: any;
  clickid: any;
  getcaller:any;
  getcustomer:any;
  constructor(public route:Router,public modalController: ModalController,
    private alert:AlertController,private datepipe:DatePipe,
    private AlertService:AlertServiceService,
    private Apiservice:ApiServiceService) { }

    ngOnInit() {
      debugger
     this.Cusdata= this.Apiservice.assignvissitcallconnect[0]
      // this.Cusdata = this.navParams.get('Data');
      this.clickcall.callerName= window.localStorage['userName']
      this.clickcall.callermobile= window.localStorage['mobile']
      // localStorage.setItem('userName','3442');
      // localStorage.setItem('userType','11');
      //this.clickcall.callerMobile=localStorage.setItem('mobile','9490739835');
      this.clickcall.customerName=this.Cusdata.CustomerName;
      this.clickcall.customerMobile=this.Cusdata.Mobile;
      this.clickcall.customerId=this.Cusdata.CBSCustomerID;
      this.clickcall.purpose=this.Cusdata.Purpose;
      this.obj.callerName=window.localStorage['userName']
      this.obj.callermobile= window.localStorage['mobile']
          this.obj.customerName=this.Cusdata.CustomerName     
          
         this.obj.customerMobile=this.Cusdata.Mobile;
        this.obj.customerId=this.Cusdata.	CBSCustomerID;
          this.obj.purpose=this.Cusdata.Purpose;
          var currentDate=new Date();
          this.obj.currDate=currentDate
         // this.callermobile=localStorage.getItem('mobile');
          //this.usertype=localStorage.getItem('userType')
          var branchid = window.localStorage['branchID'];
          var userid = window.localStorage['userID'];

          if(this.obj.callermobile =='' || this.obj.callermobile ==undefined || this.obj.callermobile ==null ){
            this.AlertService.presentAlert("","CallerNumber Not Available")
          }else if(this.obj.customerMobile =='' || this.obj.customerMobile ==undefined || this.obj.customerMobile ==null ){
           this.AlertService.presentAlert("","CustomerNumber Not Available") 
          }else{
      
      this.Apiservice.endcallnrewfunction(branchid,userid,this.obj.callermobile,this.obj.customerMobile).then((res:any)=>{
       this.rowid=JSON.parse(JSON.parse(res.data))
       
        this.Apiservice.clickToCallFollowUP(this.obj.callermobile,this.obj.customerMobile,this.rowid).then((response:any)=> {
          debugger
          console.log(response.data)
          // this.hidespin($ionicLoading);

          this.result = JSON.parse(response.data);
          this.resout = JSON.parse( JSON.parse(this.result));
          if(this.resout.status == '200'){
            this.clickcallID = this.resout.data;
            this.Apiservice. autoclicktocallupdate(  this.clickcall.customerId,  this.clickcall.customerName,  this.clickcallID.id,  this.rowid,  "AssignedVisit").then((res:any)=>{
              debugger
                           })
            this.callinterval();
            // this.CallConnectModal.show();
          }else{
            this.AlertService.presentAlert("",this.resout.message)
            return false
           // alert(response)
          // var alertPopup = $ionicPopup.alert({
          //   title: 'Alert',
          //   template: response
          // });
        
          // alertPopup.then(function(res) {
          // });
          }
      
        
        })
       

        
        })
      }
    }
    clicknumberstar(num:any,status)
    {
      debugger
      if(status == 'ca'){
        this.getcaller= this.Apiservice.firstfivexxxx(num)
      }else
      {
        this.getcustomer= this.Apiservice.firstfivexxxx(num)
    
    }
  }
    callResp(){
      debugger
      console.log(this.clickcallID.id);
      var id = this.clickcallID.id;
      this.Apiservice.callStatusFollowUp(id)
      .then((response:any)=> {
        debugger
      //  console.log(response)
        this.statusResp= JSON.parse(JSON.parse(JSON.parse(response.data)))
        this.repStatus = this.statusResp;
        //this.hidespin($ionicLoading);
        console.log(JSON.parse( JSON.parse(response.data)).length);
        if(JSON.parse(JSON.parse(JSON.parse(response.data))).data.length == 1){
          if((this.repStatus.data[0].status=="NOANSWER" || this.repStatus.data[0].status=="FAILED" || this.repStatus.data[0].status=="CONGESTION") && this.repStatus.data[0].status2==null) {
            this.stopCall();
          this.callResppopup(this.repStatus.data[0].status,id,"1")
          
          }else{
          console.log(this.repStatus.data[0].status2);
        if(this.repStatus.data[0].status2 != null){
          console.log(this.repStatus.data[0]);
          if(this.repStatus.data[0].status2 == 'ANSWER'){
            this.stopCall();
           // this.CallConnectModal.hide();
            console.log(this.currDate);
            this.EndCallobj.callerName=window.localStorage['userName'];
            this.EndCallobj.callerMobile= window.localStorage['mobile'];
            this.EndCallobj.customerName=this.Cusdata.CustomerName;
            this.EndCallobj.customerMobile=this.Cusdata.Mobile;
            this.EndCallobj.customerId=this.Cusdata.CBSCustomerID;
            //this.EndCallobj.purpose=this.item.purpose_id;
            this.EndCallobj.purposeText= this.Cusdata.Purpose.split('/').join('-');
            this.EndCallobj.endStatus= 'A';
            //var currentDate= new Date();
            this.EndCallobj.currDate = this.repStatus.data[0].start_time;
            this.EndCallobj.endDate = this.repStatus.data[0].end_time;
            this.Endcall(this.EndCallobj);
            // this.End(this.Cusdata);
            // this.assignedvisitUpdateModal(this.Cusdata)
          }else{
           
           
             this.stopCall()
              this.callResppopup(this.repStatus.data[0].status2,id,"2")
             
          
    
    
          }
          
        }
      }
    }
      })
      
    
    }

    callResppopup(ans,id,leg2){
      debugger
  this.stopCall()
                        // <<<---using ()=> syntax
        this.Apiservice.callStatusLead(id).then((res:any)=>{
    
          debugger
         res= JSON.stringify(res)
         res=JSON.parse(res)
    
         if(res !='' && res.data == '"\\"\\""'){
      this.Apiservice.callStatusLead(id).then((res:any)=>{
    
        debugger
       res= JSON.stringify(res)
       res=JSON.parse(res)
  
  
  
  
      
        var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
        if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
          this.voicerecording='No Record'
        }else{
        this.voicerecording=xyz[0].recording.slice(28)
        }
        if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
        this.location="no record"
        }else{
          this.location=xyz[0].location
        }
        if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
          this.provider="no provider"
        }else{
          this.provider=xyz[0].provider
        }
        if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
          this.status="no status"
        }else{
         this.status=xyz[0].status
        }
        if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
          this.status2="no status"
        }else{
         this.status2=xyz[0].status2
        }
        
     debugger
     var branchid = window.localStorage['branchID'];
     var usertype = window.localStorage['userType'];
     var userid = window.localStorage['userID'];
     var purpose = 'Assigned Visit';
  var objendcall={
    CustId :this.clickcall.customerId,
              CustName :this.clickcall.customerName,
              CustNumber :this.clickcall.customerMobile,
              strUserId :userid,
              strBranch :branchid,
              UserNumber :this.clickcall.callermobile,
              StartTime :xyz[0].start_time,
              Endtime :xyz[0].end_time,
              Purpose :purpose,
              duration :xyz[0].duration,
              bill :xyz[0].billsec,
              credit :xyz[0].credits,
              status :this.status,
              status1 :this.status2,
              rec :this.voicerecording,
              location :this.location,
              provider :this.provider,
              callid :id,
              rowid :this.rowid
  }
  
  
        this.Apiservice.endcallconnectnewmethod(objendcall)
          .then((response:any)=> {
                  debugger
              this.callresppopoutput(ans,leg2)
              
                },err=>{
                   if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                })
                
              
              
                }
              )
    }else{

    
    
        
          var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
          
          if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
            this.voicerecording='No Record'
          }else{
          this.voicerecording=xyz[0].recording.slice(28)
          }
          if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
          this.location="no record"
          }else{
            this.location=xyz[0].location
          }
          if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
            this.provider="no provider"
          }else{
            this.provider=xyz[0].provider
          }
          if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
            this.status="no status"
          }else{
           this.status=xyz[0].status
          }
          if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
            this.status2="no status"
          }else{
           this.status2=xyz[0].status2
          }
          
       debugger
       var branchid = window.localStorage['branchID'];
       var usertype = window.localStorage['userType'];
       var userid = window.localStorage['userID'];
       var purpose = 'Assigned Visit';
    var objendcall={
      CustId :this.clickcall.customerId,
                CustName :this.clickcall.customerName,
                CustNumber :this.clickcall.customerMobile,
                strUserId :userid,
                strBranch :branchid,
                UserNumber :this.clickcall.callermobile,
                StartTime :xyz[0].start_time,
                Endtime :xyz[0].end_time,
                Purpose :purpose,
                duration :xyz[0].duration,
                bill :xyz[0].billsec,
                credit :xyz[0].credits,
                status :this.status,
                status1 :this.status2,
                rec :this.voicerecording,
                location :this.location,
                provider :this.provider,
                callid :id,
                rowid :this.rowid
    }
    
    
          this.Apiservice.endcallconnectnewmethod(objendcall)
            .then((response:any)=> {
                    debugger
                this.callresppopoutput(ans,leg2)
                
                  },err=>{
                     if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                  })
                  
                
                
                  }
                }
                )
   
  
  
  
    
    }





    async callresppopoutput(ans,leg2){
      debugger
if(ans == "FAILED" && leg2 == "2"){
  const alert = await this.alert.create({
    header: "Successfully Saved",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: '',
    buttons: [{ text     : 'Ok',
   
    
    handler:() => {
      this.clickcall={};
      
       // this.CallConnectModal.hide();
        this.stopCall();
        this.modelDissmiss()
    }
  },
 
]
  });
  await alert.present()
}else{
  const alert = await this.alert.create({
  header: ans+'Would you like to update?',
  cssClass:'alertHeader',
  // subHeader: 'Subtitle',
  message: '',
  buttons: [{ text     : 'Yes',
 
  
  handler:() => {
    // this.alert.dismiss
    this.clickcall={};
      //this.CallConnectModal.hide();
     
      this.stopCall();
      console.log(this.Cusdata);
      this.EndCallobj.callerName=window.localStorage['userName'];
      this.EndCallobj.callerMobile= window.localStorage['mobile'];
      this.EndCallobj.customerName=this.Cusdata.CustomerName;
      this.EndCallobj.customerMobile=this.Cusdata.Mobile;
      this.EndCallobj.customerId=this.Cusdata.CBSCustomerID;
      //this.EndCallobj.purpose=this.item.purpose_id;
      this.EndCallobj.purposeText= this.Cusdata.Purpose;
      this.EndCallobj.endStatus= 'I';
      //var currentDate= new Date();
      this.EndCallobj.currDate = this.repStatus.data[0].start_time;
      this.EndCallobj.endDate = this.repStatus.data[0].end_time;
      // this.Endcall(this.EndCallobj);
      // this.End(this.Cusdata);
      this.assignedvisitUpdateModal(this.Cusdata)
  }
},
{
  text     : 'No',
 
  
  handler:() => {
    // this.alert.dismiss()
    this.clickcall={};
    
     // this.CallConnectModal.hide();
      this.stopCall();
      this.modelDissmiss()
     //this.followupcallsUpdmodal(this.item);
  }
}
]
});
await alert.present()
}
   
    }
  
    modelDissmiss() {
     this.route.navigateByUrl('/myassignedvisits')
    }
    Endcall1(obj){
      this.assignedvisitUpdateModal(this.Cusdata);
    }

    Endcall(obj)
  {
  debugger
    console.log(obj);
    if(this.resout=='' || this.repStatus.data.length==0){
      this.assignedvisitUpdateModal(this.Cusdata);
    }else{

    if(this.repStatus.data[0].status2=='ANSWER'){
    this. clickid=this.clickcallID.id
    if(obj.endDate == undefined || obj.endDate == 'undefined' || obj.endDate == null || obj.endDate == ''){
      var enDate= new Date();
       this.endDate =this.datepipe.transform(enDate, 'yyyy-MM-dd hh-mm-ss')
      // this.endDate = $filter('date')(enDate, 'hh-mm-ss');
      console.log(this.endDate);
      }else{
        var enDate= new Date(obj.endDate);
        this.endDate =this.datepipe.transform(enDate, 'yyyy-MM-dd hh-mm-ss')
        console.log(this.endDate);
      }
      var curDate= new Date(obj.currDate);
      this.currDate = this.datepipe.transform(curDate, 'yyyy-MM-dd hh-mm-ss');
      console.log(this.currDate);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var purpose = 'Assigned Visit';
                               // <<<---using ()=> syntax
    
      this.Apiservice.callStatusLead(this.clickid).then((res:any)=>{
  
        debugger
       res= JSON.stringify(res)
       res=JSON.parse(res)
    
       if(res !='' && res.data == '"\\"\\""'){
        this.Apiservice.callStatusLead(this.clickid).then((res:any)=>{
  
          debugger
         res= JSON.stringify(res)
         res=JSON.parse(res)
      
        
      
      
         if(res=='' || JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
           
            this.stopCall();
            // console.log($scope.item);
            this.assignedvisitUpdateModal(this.Cusdata);
          }else{
          
          if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
            // $scope.clickTocallConnect.hide();
            this.stopCall();
            // console.log($scope.item);
            this.assignedvisitUpdateModal(this.Cusdata);
          }else{
          
          var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
          
          if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
            this.voicerecording='No Record'
          }else{
          this.voicerecording=xyz[0].recording.slice(28)
          }
          if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
          this.location="no record"
          }else{
            this.location=xyz[0].location
          }
          if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
            this.provider="no provider"
          }else{
            this.provider=xyz[0].provider
          }
          if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
            this.status="no status"
          }else{
           this.status=xyz[0].status
          }
          if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
            this.status2="no status"
          }else{
           this.status2=xyz[0].status2
          }
          
          var objendcall={
            CustId :obj.customerId,
                      CustName :obj.customerName,
                      CustNumber :obj.customerMobile,
                      strUserId :userid,
                      strBranch :branchid,
                      UserNumber :obj.callerMobile,
                      StartTime :xyz[0].start_time,
                      Endtime :xyz[0].end_time,
                      Purpose :purpose,
                      duration :xyz[0].duration,
                      bill :xyz[0].billsec,
                      credit :xyz[0].credits,
                      status :this.status,
                      status1 :this.status2,
                      rec :this.voicerecording,
                      location :this.location,
                      provider :this.provider,
                      callid :this.clickid,
                      rowid :this.rowid
          }
          
    
    
    
          this.Apiservice.endcallconnectnewmethod(objendcall)
            .then((response:any)=> {
                    debugger
                
                    // obj.endStatus == 'I'
                    if(obj.endStatus == '0'){
                 
                   
        
                      this.assignendcall()
        
                  }else{
                    debugger
                   this.clickcall={};
                         
                        this.stopCall();
                          // console.log($scope.item);
                          this.assignedvisitUpdateModal(this.Cusdata);
                  }
                  },err=>{
                     if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                  })
                  
                
                }
                  }
                })
       }
    else{
    
       if(res=='' || JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
         
          this.stopCall();
          // console.log($scope.item);
          this.assignedvisitUpdateModal(this.Cusdata);
        }else{
        
        if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
          // $scope.clickTocallConnect.hide();
          this.stopCall();
          // console.log($scope.item);
          this.assignedvisitUpdateModal(this.Cusdata);
        }else{
        
        var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
        if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
          this.voicerecording='No Record'
        }else{
        this.voicerecording=xyz[0].recording.slice(28)
        }
        if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
        this.location="no record"
        }else{
          this.location=xyz[0].location
        }
        if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
          this.provider="no provider"
        }else{
          this.provider=xyz[0].provider
        }
        if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
          this.status="no status"
        }else{
         this.status=xyz[0].status
        }
        if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
          this.status2="no status"
        }else{
         this.status2=xyz[0].status2
        }
        
        var objendcall={
          CustId :obj.customerId,
                    CustName :obj.customerName,
                    CustNumber :obj.customerMobile,
                    strUserId :userid,
                    strBranch :branchid,
                    UserNumber :obj.callerMobile,
                    StartTime :xyz[0].start_time,
                    Endtime :xyz[0].end_time,
                    Purpose :purpose,
                    duration :xyz[0].duration,
                    bill :xyz[0].billsec,
                    credit :xyz[0].credits,
                    status :this.status,
                    status1 :this.status2,
                    rec :this.voicerecording,
                    location :this.location,
                    provider :this.provider,
                    callid :this.clickid,
                    rowid :this.rowid
        }
        
  
  
  
        this.Apiservice.endcallconnectnewmethod(objendcall)
          .then((response:any)=> {
                  debugger
              
                  // obj.endStatus == 'I'
                  if(obj.endStatus == '0'){
               
                 
      
                    this.assignendcall()
      
                }else{
                  debugger
                 this.clickcall={};
                       
                      this.stopCall();
                        // console.log($scope.item);
                        this.assignedvisitUpdateModal(this.Cusdata);
                }
                },err=>{
                   if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                })
                
              
              }
                }}
              })
  
   
  
          }else{
            this.assignedvisitUpdateModal(this.Cusdata);
          }
        }
  }
  stopCall(){
    clearInterval(this.interval)
  }
  async assignendcall(){
    debugger
    const alert = await this.alert.create({
      header: 'You have ended the call explicitly. would you like to update?',
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: '',
      buttons: [{ text     : 'Yes',
     
      
      handler:() => {
        // this.alert.dismiss
        this.clickcall={};
                // this.CallConnectModal.hide();
                this.stopCall();
                console.log(this.Cusdata);
                this.assignedvisitUpdateModal(this.Cusdata);
        //  this.followupvisitsUpdateModal(this.Cusdata)
      }
    },
    {
      text     : 'No',
     
      
      handler:() => {
        // this.alert.dismiss()
        this.clickcall={};
        // this.CallConnectModal.hide();
        this.stopCall();
        this.modelDissmiss()
      }
    }
  ]
    });
    await alert.present()
  }
  callinterval(){
    this.interval = setInterval(() => {
      this.callResp();
          // clearInterval(this.interval)
        }, 10000);
  }
  assignedvisitUpdateModal(obj) {
     
      
    this.assignmodelshow(this.Cusdata);
     
  
   };
  
  
   async assignmodelshow(items){
  
    this.Apiservice.assignedvistendcallary=[]
  this.Apiservice.assignedvistendcallary.push(items,{close:"endcallassign"})
  this.route.navigateByUrl('/assignedvisitupdatemodal')
  
  
    //  const modal = await this.modalController.create({
    //    component: AssignedvisitupdatemodalPage,
    //    componentProps: { Data: items }
    //  });
    //  return await modal.present();
   }

}
