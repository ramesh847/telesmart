import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DemandcallconnectPage } from './demandcallconnect.page';

const routes: Routes = [
  {
    path: '',
    component: DemandcallconnectPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DemandcallconnectPageRoutingModule {}
