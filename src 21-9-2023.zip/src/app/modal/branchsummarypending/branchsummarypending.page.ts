import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';

@Component({
  selector: 'app-branchsummarypending',
  templateUrl: './branchsummarypending.page.html',
  styleUrls: ['./branchsummarypending.page.scss'],
  providers:[Idle]
})
export class BranchsummarypendingPage implements OnInit {
  userid: any;
  branchid: any;
  userType: any;
  Cusdata: any;
  PendingUserid: any;
  Pendingbranchid: any;
  PendinguserType: any;
  data:any={}
  custID: number;
  Pendingdataresp: any;
  idleState: string;

  constructor(private apiService:ApiServiceService,
    private navParams: NavParams,
    private alertService: AlertServiceService,
    public modalController: ModalController,private loader:ToastServiceService,
    public router:Router,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>{
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    debugger
    this. userid = window.localStorage['userID'];;
    this. branchid = window.localStorage['branchID'];
    this. userType = window.localStorage['userType'];
    this.Cusdata = this.navParams.get('Data');
    this.pendingList(this.Cusdata)
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  pendingList(item){
    debugger
    // console.log(item);
    // this.showspin();
    this.PendingUserid = item.CallerId;
    this.Pendingbranchid = item.BranchId;
    this.PendinguserType = item.UserType;
    if(this.data.customerid == undefined ||this.data.customerid == ''){
    this. custID = 0 ;
    }else{
    this. custID = this.data.customerid ;
    }
    this.apiService.getpendingList(this.PendingUserid, this.Pendingbranchid, this.PendinguserType, this.custID)
    .then((response:any) =>{
      debugger
        //console.log(response);
        // this.hidespin();
        response = JSON.parse(JSON.parse(response.data));
        this.Pendingdataresp = response.Table;
        // console.log(this.Pendingdataresp);
        // this.pendingaction.show();
    },err=>{
      this.alertService.presentAlert("Error",err.status)
    })
    
     
  }
  getPending () {
    // this.showspin();
    //console.log("TEST")
   
    debugger
    // var userid = this.PendingUserid;
    // var branchid = this.Pendingbranchid;
    // var userType = this.PendinguserType;
  
   
      console.log(this.data.customerid);
    if(this.data.customerid == undefined || this.data.customerid == '' ){
      var custID = 0 ;
      this.data.customerid = 0;
    }else{
      this. custID = this.data.customerid ;
    }
  
    console.log(this.data.customerid,custID);
    this.apiService.getpendingList(this.userid, this.branchid, this.userType,this.data.customerid)
      .then((response:any)=> {
        debugger
      //  console.log(response);
        response =JSON.parse(JSON.parse(response.data));
        // this.hidespin();
        this.Pendingdataresp = response.Table;
       console.log(this.Pendingdataresp);
      },err=>{
        this.alertService.presentAlert("Error",err.status)
      })
     
  }
  goToMyplannerPage(){
    this.modalController.dismiss()
  }
}
