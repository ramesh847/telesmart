import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BranchsummarypendingPageRoutingModule } from './branchsummarypending-routing.module';

import { BranchsummarypendingPage } from './branchsummarypending.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BranchsummarypendingPageRoutingModule
  ],
  declarations: [BranchsummarypendingPage]
})
export class BranchsummarypendingPageModule {}
