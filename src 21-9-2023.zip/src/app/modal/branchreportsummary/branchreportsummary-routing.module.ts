import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BranchreportsummaryPage } from './branchreportsummary.page';

const routes: Routes = [
  {
    path: '',
    component: BranchreportsummaryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BranchreportsummaryPageRoutingModule {}
