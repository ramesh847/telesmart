import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BranchreportsummaryPageRoutingModule } from './branchreportsummary-routing.module';

import { BranchreportsummaryPage } from './branchreportsummary.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BranchreportsummaryPageRoutingModule
  ],
  declarations: [BranchreportsummaryPage]
})
export class BranchreportsummaryPageModule {}
