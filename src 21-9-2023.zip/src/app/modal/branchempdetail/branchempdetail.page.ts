import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';

@Component({
  selector: 'app-branchempdetail',
  templateUrl: './branchempdetail.page.html',
  styleUrls: ['./branchempdetail.page.scss'],
  providers:[Idle]
})
export class BranchempdetailPage implements OnInit {
  userid: any;
  branchid: any;
  UserType: any;
  fromdate: any;
  todate: any;
  totaldetails: any;
  branchmngr: string;
  emplist: any[];
  branchdata: any;
  BranchName: any;
  BranchCode: any;
  UserName: any;
  UserCode: any;
  emplistlength: number;
  getitems: any;
  idleState: string;

  constructor(public router: Router, public apiservice: ApiServiceService,
    public alert: AlertServiceService, private modalController: ModalController,
    private loader: ToastServiceService, private navParams: NavParams,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          // (this.idleState = countdown.toString() )
          {
            let idleState = countdown
           let minutes = Math.floor((idleState)/ 60);
           let extraSeconds = (idleState) % 60;
          let minutes1 = minutes < 10 ? "0" + minutes : minutes;
          let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
          this.idleState=minutes1 +':'+ extraSeconds1
          console.log(this.idleState)
          }
      ); }

  ngOnInit() {
    debugger
    this.userid = window.localStorage['userID']
    this.branchid = window.localStorage['branchID']
    this.UserType = window.localStorage['userType']
    let data = this.navParams.get('Data');
    this.fromdate = this.navParams.get('fdate')
    // data[1].fdate
    this.todate = this.navParams.get('tdate')
    this.getitems = this.navParams.get('items')
    this.BranchName = data.BranchName
    this.BranchCode = data.BranchCode
    this.UserName = data.UserName
    this.UserCode = data.UserCode



    this.openrdmbranchemp1(data)
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  modeldismaiss() {
    this.modalController.dismiss()
  }
  openrdmbranchemp1(item) {
    debugger
    console.log(item);
    this.totaldetails = item;
    this.branchmngr = '';
    this.emplist = [];
    // var branchfromdate = $filter("date")(document.getElementById('fromdate').value, 'dd-MM-yyyy');
    // var branchtodate = $filter("date")(document.getElementById('todate').value, 'dd-MM-yyyy');
    // this.fromdate = $filter("date")(document.getElementById('fromdate').value, 'dd/MM/yyyy') ;
    // this.todate = $filter("date")(document.getElementById('todate').value, 'dd/MM/yyyy') ;
    this.branchdata = item;

    var info = {
      branchdata: this.branchdata,
      fromdate: this.fromdate,
      todate: this.todate
    }

    //   console.log(this.branchdata.BranchName);

    // $state.go("app.RDMbranchcalls", {data:info});
    this.loader.presentLoading('')
    this.apiservice.getBranchMgrUserId(item.BranchId)
      .then((response: any) => {
        debugger
        response = JSON.parse(JSON.parse(response.data));
        console.log(response);
        this.branchmngr = response.Table[0];
        // this.mangermap =response;
        // var fromdate = $filter("date")(document.getElementById('fromdate').value, 'dd-MM-yyyy') ;
        // var todate = $filter("date")(document.getElementById('todate').value, 'dd-MM-yyyy') ;
        this.apiservice.BranchDairyDetails(item.BranchId, this.userid, this.fromdate, this.todate)
          .then((response: any) => {
            debugger
        this.loader.dismissLoading()
            
            response = JSON.parse(JSON.parse(response.data));
            console.log(response);
            this.emplist = response;
            this.emplistlength = this.emplist.length
            // $ionicLoading.hide();
            // this.emplist  = $filter('orderBy')(this.emplist , Number('Usercode'), true);
            // this.mangermap =response;
          })

      })


  }
  modeldissmiss() {
    this.modalController.dismiss()
  }

}
