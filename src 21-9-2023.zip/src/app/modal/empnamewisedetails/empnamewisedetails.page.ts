/* eslint-disable no-var */
/* eslint-disable @typescript-eslint/no-inferrable-types */
/* eslint-disable @typescript-eslint/naming-convention */
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';

@Component({
  selector: 'app-empnamewisedetails',
  templateUrl: './empnamewisedetails.page.html',
  styleUrls: ['./empnamewisedetails.page.scss'],
  providers:[Idle]
})
export class EmpnamewisedetailsPage implements OnInit {
  showitemcard: boolean = false
  showitemlist: boolean = true
  userid: any;
  branchid: any;
  UserType: any;
  BranchCode: any;
  BranchDescription: any;
  BranchID: any;
  rdmname: any;
  staffmapdata: any;
  USERID: any;
  UserName: any;
  Designation: any;
  UserCode: any;
  DesignationId: any;
  assignstartdate: any;
  assignstartend: any;
  idleState: string;

  constructor(private modalController: ModalController, private navParams: NavParams,
    public apiservice: ApiServiceService,
    public alert: AlertServiceService,private idle:Idle,private router:Router) {// sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = "No longer idle."));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {

    this.userid = window.localStorage['userID']
    this.branchid = window.localStorage['branchID']
    this.UserType = window.localStorage['userType']
    let data = this.navParams.get('Data');
    console.log(data)
    this.USERID = data.USERID
    this.UserName = data.UserName
    this.Designation = data.Designation
    this.UserCode = data.UserCode
    this.DesignationId = data.DesignationId
    this.openmangerlist();
    // this.reset()
  }
reset(){
  this.idle.watch()
}


  openmangerlist() {
    var branchid = 0;
    this.apiservice.getstaffheatmap(this.USERID, branchid).then((response: any) => {
      response = JSON.parse(JSON.parse(response.data))
      console.log(response);
      this.staffmapdata = response;
    });


    this.apiservice.AssigneDdate().then(response => {
      var resp = JSON.stringify(response.data);
      resp = JSON.parse(resp);
      resp = JSON.parse(resp);
      resp = JSON.parse(resp);
      console.log(resp)
      this.assignstartdate = resp[0]['EndDate'];
      console.log(this.assignstartdate)
      this.assignstartend = resp[0]['StartDate'];
      console.log(this.assignstartend)
    })






  }

  modeldissmiss() {
    this.modalController.dismiss()
  }
  cardshowbranch() {
    this.showitemcard = true
    this.showitemlist = false
  }
  tableshowbranch() {
    this.showitemcard = false
    this.showitemlist = true
  }

}
