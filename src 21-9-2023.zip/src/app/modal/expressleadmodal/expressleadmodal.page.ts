import { Component, OnInit } from '@angular/core';
import { AlertController, ModalController } from '@ionic/angular';
import { NavParams } from '@ionic/angular';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import * as moment from "moment"; 
import { Pipe, PipeTransform } from "@angular/core";
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ToastServiceService } from 'src/app/service/toast-service.service';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
@Pipe({
  name: 'actStatusPipe'
})
@Component({
  selector: 'app-expressleadmodal',
  templateUrl: './expressleadmodal.page.html',
  styleUrls: ['./expressleadmodal.page.scss'],
  providers:[DatePipe,Idle]
})
export class ExpressleadmodalPage implements OnInit {
  data:any={}
  express:any={}
  callOutCome: any;
  getusername: any;
  callPurpose: any;
  businessunit: any;
  customeractiondata: any;
  enable: boolean;
  expressLeadcustomerdata: any;
  firstWords: any[];
  firstname1: any;
  myvalue: boolean;
  assignedvisit:any= {};
  Collectiondate1: any;
  nextcalldate1: string;
  followuptime: string;
  getfollowdates: string;
  getampm: string;
  modifytime1: string;
  modifytime2: string;
  Cusdata1: any;
  idleState: string;
  constructor(private loader:ToastServiceService,private AlertService:AlertServiceService,
    private datepipe:DatePipe,public route:Router,private modalController:ModalController,
    private Alertservice:AlertServiceService,private Apiservice:ApiServiceService,
    private alert1:AlertController,private idle:Idle
 
    ) {// sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = "No longer idle."));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.route.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    // let Cusdata = this.navParams.get('Data');
    this.Cusdata1=this.Apiservice.expressleadarray
    let Cusdata=this.Cusdata1[0]
    console.log(Cusdata);
    // this.express.customerid = Cusdata.CBSCUSTOMERID
    this.getcalloutcome();
    this.getpurpose();
    this.getbusinessunit();
    this.expressLeadactionModal(Cusdata);
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  modelDissmiss(){
    // if(this.Cusdata1[1].close=="expresslead" || this.Cusdata1[1].close=="endexpresslead"){
    //   this.route.navigateByUrl('/express-leads')
    // }else{
      
   this.route.navigateByUrl('/express-leads')
    // }
   }
  getcalloutcome(){
    this.Apiservice.getcalloutcome1().then((res:any)=>{
  // console.log(JSON.parse(res));
  var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
  this.callOutCome = response;
  
    }) 
  }
  getbusinessunit(){
    //  this.showspin();
      this.Apiservice.getbusinessunit()
        .then( (res:any)=> {
          console.log(response);
          var response = res.data;
          response = JSON.parse(response);
          response = JSON.parse(response);
         this.businessunit = response;
  
        //  this.hidespin();
        })
        // .error(function (response) {
        //  this.hidespin();
        //   console.log(response);
  
  
        // });
  
  
    }
  checkusercode(val) {
    var usercode = val;
    var branchid = window.localStorage['branchID'];
    var struserCode = window.localStorage['userCode'];
    // this.showspin();
    // callAPI.getusername(struserCode,usercode, branchid)
    //   .success(function(response) {
    //     this.hidespin();
    //     console.log(response);
    //     response = JSON.parse(response);
    //     if (response == "This User Not in this Branch") {

    //       var myPopup = $ionicPopup.show({
    //         template: '<center>Please Enter The Valid Emp Code</center>',
    //         title: "",
    //         scope: this,
    //         buttons: [{
    //           text: 'OK',
    //           type: 'button button-clear button-assertive'
    //         }]
    //       });
    //       this.data.jointusername = "";
    //       this.data.jointusercode = "";

    //     } else {
    //       this.getusername = response;
    //       this.data.jointusername = this.getusername;
    //       console.log(this.getusername)
    //     }

    //   })

    this.Apiservice.checkJointCode(struserCode,usercode, branchid)
    .then((res:any)=> {
      // this.hidespin();
      var response = res.data;
      response = JSON.parse(response);
      response = JSON.parse(response);
      if (response == "This User Not in this Branch") {

        // var myPopup = $ionicPopup.show({
        //   template: '<center>Please Enter The Valid Emp Code</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        this.Alertservice.presentAlert("","Please Enter The Valid Emp Code");
        this.express.jointusername = "";
        this.express.jointusercode = "";

      }else if (response == "Please Enter the Valid User Code") {

        // var myPopup = $ionicPopup.show({
        //   template: '<center>Please Enter the Valid User Code</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        this.Alertservice.presentAlert("","Please Enter the Valid User Code");
        this.express.jointusername = "";
        this.express.jointusercode = "";

      }else if (response == "Please do not enter same user code") {
        this.Alertservice.presentAlert("","Please do not enter same user code");
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Please do not enter same user code</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        this.express.jointusername = "";
        this.express.jointusercode = "";

      }  else {
        this.getusername = response;
        this.express.jointusername = this.getusername;
        console.log(this.getusername)
      }

    })
      // .error(function(response) {
      //   this.hidespin();
      //   console.log(response);
      // });
  }
  checkbox(Event){
    console.log(Event);
    
    if(Event){
      this.express.jointvisit = 'YES';
    }else{
      this.express.jointvisit = "NO"
    }
    console.log(this.express.jointvisit)
  }

  getpurpose(){
    this.Apiservice.getpurpose().then((res:any)=>{
      // console.log(JSON.parse(res))
      var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
      this.callPurpose = response;
    })
  }

 expressLeadactionModal(items) {
    console.log(items);
   this.express.addressname = "";
   this.express.callout = "";
   this.express.selectele = "";
   this.express.courtesypurp = "3";
   this.express.followupdate = "";
   this.express.followuptime = "";
   this.express.jointvisit = "";
   this.express.jointusercode = "";
   this.express.jointusername = "";
   this.customeractiondata = items;
    window.localStorage['customerID'] =this.customeractiondata.CBSCUSTOMERID;
    window.localStorage['callID'] =this.customeractiondata.CALLID;
    console.log(this.customeractiondata.CBSCUSTOMERID)
    debugger
    if(this.customeractiondata.CBSCUSTOMERID != '' &&this.customeractiondata.CBSCUSTOMERID != "" &&this.customeractiondata.CBSCUSTOMERID != undefined &&this.customeractiondata.CBSCUSTOMERID != null ){
      console.log('test')
   this.express.customerid=this.customeractiondata.CBSCUSTOMERID;
    var customerid = items.CBSCUSTOMERID;
    debugger
    }else{
     this.express.customerid=0;
      var customerid:any = 0
    }
    console.log(customerid)
  //  this.expressLeadaction.show(); cmd by sijin

    if (customerid == null) {

     this.enable = false;

    }
    if (customerid != null) {
     this.enable = true;
    //  this.showspin();
      this.Apiservice.getcustomerdetails(customerid)
        .then((res:any)=> {
        //  this.hidespin();
        var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
        response = JSON.parse(response);
         this.expressLeadcustomerdata = response;
          console.log(this.expressLeadcustomerdata)
          debugger
          if(this.expressLeadcustomerdata != "" &&this.expressLeadcustomerdata != undefined)
          {
         this.express.customerid = customerid;
         this.express.customername =this.expressLeadcustomerdata[0].Nfirstname + ' ' +this.expressLeadcustomerdata[0].Nlastname;
          window.localStorage['customerName'] =this.express.customername;
         this.express.firstname =this.expressLeadcustomerdata[0].Nfirstname;
         this.express.lastname =this.expressLeadcustomerdata[0].Nlastname;
         this.express.mobile =this.expressLeadcustomerdata[0].Nmobile;
         this.express.resphnno =this.expressLeadcustomerdata[0].Nresidencephone;
         this.express.email =this.expressLeadcustomerdata[0].Nemail;

         this.firstWords = [];

          var firstname = [];

          if (this.expressLeadcustomerdata.length > 0) {
          //  this.showspin();
          }
          for (let i = 0; i <this.expressLeadcustomerdata.length; i++) {

            firstname =this.expressLeadcustomerdata[i].Nfirstname.split(" ");

           this.firstWords.push(firstname[0]);
           this.expressLeadcustomerdata[i].firstname =this.firstWords[i];
           this.firstname1 =this.expressLeadcustomerdata[i].firstname;
            if (i ==this.expressLeadcustomerdata.length - 1) {
            //  this.hidespin();
            }
          }

          console.log(this.expressLeadcustomerdata[0].Add1);
          if(this.expressLeadcustomerdata[0].Add1 != undefined ||this.expressLeadcustomerdata[0].Add2 != undefined ||this.expressLeadcustomerdata[0].Add3 != undefined ||this.expressLeadcustomerdata[0].Add4 != undefined ||this.expressLeadcustomerdata[0].PIN != undefined){
            var respAdd1=this.expressLeadcustomerdata[0].Add1;
            var add1 = respAdd1.replace("/", "-");
            console.log(add1); 
            var respAdd2=this.expressLeadcustomerdata[0].Add2;
            var add2 = respAdd2.replace("/", "-");
            console.log(add2);
         this.express.addressname = add1+' '+add2+' '+this.expressLeadcustomerdata[0].Add3+' '+this.expressLeadcustomerdata[0].Add4+' '+this.expressLeadcustomerdata[0].PIN;
          console.log(this.express.addressname);
          }
          if(this.express.addressname != "" &&this.express.addressname != undefined)
          { 
            console.log(this.express.addressname);
          this.myvalue = true;
           //this.data.selectele='P';
          // this.setlatlong(this.express.addressname); cmd by sijin
          }
         
         }else{
          //this.express.firstname =this.expressLeadcustomerdata[0].Nfirstname;
         this.express.lastname =this.customeractiondata.CUSTOMERNAME;
         this.express.mobile =this.customeractiondata.MOBILE;

         }
        })
        // .error(function (response) {
        //   console.log(response);
        //  this.hidespin();
        // });
    }
   // console.log(obj);
    console.log(this.express.addressname);
        if(this.express.addressname != '' &&this.express.addressname != 'undefined' &&this.express.addressname != undefined){
        //  this.typeshowmap1(this.lat1,this.lng1,this.express.addressname) cmd by sijin
        }
}




  // this.express = {};this.ex
  customerActionModal(item){
    debugger
this.express={}
  }

  saveExpress() {
    debugger

    var usercode = window.localStorage['userCode'];
  var username = window.localStorage['userName'];
  var branchid = window.localStorage['branchID'];
  var cbsid = window.localStorage['customerID'];
  var CallerId = window.localStorage['userID'];
    // console.log(obj)
    // this.showspin($ionicLoading);
    var customername1 = this.express.CUSTOMERNAME;
    console.log(customername1)
    var mobile1 = this.express.mobile;
    var calltype = this.express.selectele;
    var callid = window.localStorage['callID'];
    console.log(callid)
    var remarks1 = this.express.Remarks;
    var firstname1 = this.express.firstname;
    var lastname1 = this.express.lastname;
    var responseid = this.express.callout;
    console.log(this.express.callout)
    // var purpose = window.localStorage['PurposeID'];
    var purpose = this.express.courtesypurp;
    console.log(purpose);
    //var BusinessUnit = 0;

    var cbsid = this.express.customerid;

    if (customername1 == "" || customername1 == undefined || customername1 == "undefined") {
      if(firstname1 == "" || firstname1 == undefined || firstname1 == "undefined"){
        if(lastname1 == "" || lastname1 == undefined || lastname1 == "undefined"){
          var customername = null;
        }else{
          var customername = lastname1;
        }
      }else{
        var customername = firstname1;
      }
      
    } else {
      var customername = customername1;
    }


    if (remarks1 == "") {

      var remarks = null;
    } else {
      var remarks = remarks1;
    }

    if (firstname1 == "" || firstname1 == undefined || firstname1 == "undefined") {

      var firstname = null;
    } else {
      var firstname = firstname1;
    }

    if (lastname1 == "" || lastname1 == undefined || lastname1 == "undefined") {

      var lastname = null;
    } else {
      var lastname = lastname1;
    }
    if (mobile1 == "") {

      var mobile = null;
    } else {
      var mobile = mobile1;
    }

    if (purpose == "5" && this.express.current == "Y") {
      if ((this.express.collecteddate == null || this.express.collecteddate == "" || this.express.collecteddate == undefined) || (this.express.collectedaccnumber == null || this.express.collectedaccnumber == undefined || this.express.collectedaccnumber == "") || (this.express.collectedamount == null || this.express.collectedamount == undefined || this.express.collectedamount == "")) {

        // var myPopup = $ionicPopup.show({
        //   template: '<center>Fill All Details Of Amount Collected</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        this.Alertservice.presentAlert("","Fill All Details Of Amount Collected");
        return false;

      } else {
        var collectionmode = "Y";
        this.Collectiondate1 = this.express.collected_date;
        var collectiondate = moment(this.Collectiondate1).format('YYYY-MM-DD');
        var accountno = this.express.collectedaccnumber;
        var amount = this.express.collectedamount;
      }

    }


    if (purpose != "5") {
      var collectionmode:string = null;

    }

    if (collectionmode == null) {
      var accountno = null;
      var amount = null;
      var collectiondate:string = null;

    }


    var Endtime = null;
    var Totime = null;
    // if (this.assignedvisit.starttime == "" || this.assignedvisit.starttime == undefined || this.assignedvisit.starttime == null) {

    //     var Endtime = null;
    // }

    // if (this.assignedvisit.endtime == "" || this.assignedvisit.endtime == null || this.assignedvisit.endtime == undefined) {

    //     var Totime = null;
    // }
    if (purpose == "5") {
      if (this.express.current == "" || this.express.current == undefined || this.express.current == null || this.express.current == 'N') {

        var collectionmode:string = null;
      }
    }

       if(purpose== "3" && this.express.businessunit == null){

            // var myPopup = $ionicPopup.show({
            //       template: '<center>Select BusinessUnit</center>',
            //       title: "",
            //       scope: this,
            //       buttons: [{
            //           text: 'OK',
            //           type: 'button button-clear button-assertive'
            //       }]
            //   });
            this.Alertservice.presentAlert("","Select BusinessUnit");
                   return false;
    }

           else{
          var BusinessUnit = this.express.businessunit;
       }



    if(purpose != "3"){

       var BusinessUnit = null;
    }

    console.log(this.express.followupdate)
    console.log(this.express.followuptime)
    if (this.express.callout == "" || this.express.callout == undefined || this.express.callout == null) {

      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Call OutCome</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert("","Select Call OutCome");
      return false;

    }

    if (responseid == "2") {
      if ((this.express.followupdate == "" || this.express.followupdate == undefined || this.express.followupdate == null) || (this.express.followuptime == "" || this.express.followuptime == undefined || this.express.followuptime == null)) {
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Provide Followup Details</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        this.Alertservice.presentAlert("","Provide Followup Details");
        return false;



      } 
      else {
        var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
        this.getfollowdates = this.datepipe.transform( this.express.followupdate,'YYYY-MM-dd')
        if (this.getfollowdates <= date) {
          // this.followupvisits.followdate=''
          // this.followupvisits.followtime=''
          this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
          return false
        
        }else{
        // this.nextcalldate1 = $filter('date')(this.express.followupdate, 'yyyy-MM-dd');
        // // var durationFilter = $filter('duration');
        // this.followuptime = $filter('date')(this.express.followuptime, 'h.mm a');
        // var nextcalldate = this.nextcalldate1 + ' ' + this.followuptime;
        this.nextcalldate1 = moment(this.express.followupdate).format('YYYY-MM-DD');
        var time = this.express.followuptime.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.express.followuptime];

    if (time.length > 1) { // If time format correct
      time = time.slice (1);  // Remove full string match value
      this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; 
      time[1]="."// Adjust hours
    }
    this.modifytime1= time.join ('');
    if(this.getampm=="AM"){
      this.modifytime2= this.modifytime1+' '+"AM"
    }else{
      this.modifytime2= this.modifytime1+' '+"PM"
    }
  
       //  this.followuptime = $filter('date')(this.data.followuptime, 'h.mm a');
         var nextcalldate = this.nextcalldate1 + ' ' +this.modifytime2;
        // var Endtime = "05.07 AM";
        // var Totime = "05.07 AM";
      }
    }

    }

    if (responseid != "2") {
      var nextcalldate:string = null;
      //          var Endtime = null;
      // var Totime = null;

    }

    if (this.express.selectele == "" || this.express.selectele == undefined || this.express.selectele == null) {
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Call Type</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert("","Select Call Type");
      return false;


    }

    if (this.express.selectele == "P" && this.express.JointVisit == "YES") {
      if (this.express.jointcode == null || this.express.jointcode == "" || this.express.jointcode == undefined) {
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter Joint Usercode</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        this.Alertservice.presentAlert("","Enter Joint Usercode");
        return false;

      } else {
        var jointvisit = "Y";
        var jointcode = this.express.jointcode;
      }


    }

    if (this.express.selectele == "P") {
      if (this.express.JointVisit == "" || this.express.JointVisit == undefined || this.express.JointVisit == null || this.express.JointVisit == 'N') {

        var jointvisit:string = null;
      }
    }

    if (this.express.selectele != "P") {

      var jointvisit:string = null;

    }

    if (jointvisit == null) {
      var jointcode = null;
    }
    if (purpose == "3") {
      //this.assigned = {};
      if ((this.express.casa != "" && this.express.casa != undefined) || (this.express.deposits != "" && this.express.deposits != undefined) || (this.express.advance != "" && this.express.advance != undefined) || (this.express.insurance != "" && this.express.insurance != undefined) || (this.express.caption != "" && this.express.caption != undefined) || (this.express.amount != "" && this.express.amount != undefined)) {
        console.log(this.express.casa);
        var casaVal = this.express.casa;
        console.log(casaVal)
        var depositVal = this.express.deposits;
        console.log(depositVal)
        var AdvanceVal = this.express.advance;
        console.log(AdvanceVal)
        var InsuranceVal = this.express.insurance;
        console.log(InsuranceVal)

      } else {
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Fill Details Of Expected Business</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        this.Alertservice.presentAlert("","Fill Details Of Expected Business");
        return false;
      }
      console.log(this.express.casa)
      if (this.express.casa == undefined || this.express.casa == "") {

        var casaVal:any = 0;
      } else {
        var casaVal = this.express.casa;
      }
      console.log(this.express.deposits)
      if (this.express.deposits == undefined || this.express.deposits == "") {
        var depositVal:any = 0;
      } else {
        var depositVal = this.express.deposits;
      }
      // console.log(this.express.advance)
      // if (this.express.advance == undefined || this.express.advance == "") {
      //   var AdvanceVal = 0;
      // } else {
      //   var AdvanceVal = this.express.advance;
      // }
      // console.log(this.express.insurance)
      // if (this.express.insurance == undefined || this.express.insurance == "") {
      //   console.log('test')
      //   var InsuranceVal = 0;
      // } else {
      //   var InsuranceVal = this.express.insurance;
      // }
      // console.log(this.express.amount)
      // if (this.express.amount == undefined || this.express.amount == "") {
      //   console.log('test1')
      //   var InsuranceVal = 0;
      // } else {
      //   var InsuranceVal = this.express.amount;
      // }
      // console.log(this.express.caption)
      // if (this.express.caption == undefined || this.express.caption == "") {
      //   var AdvanceVal = 0;
      // } else {
      //   var AdvanceVal = this.express.caption;
      // }

      if(this.express.businessunit == 13){

      
        if (this.express.caption == null || this.express.caption == undefined || this.express.caption == "") {
  
          var  AdvanceVal:any = 0;
    
        } else{
    
          var AdvanceVal = this.express.caption;
    
        }
      }
      else{
  
        if (this.express.advance == null || this.express.advance == undefined || this.express.advance == "") {
  
          var AdvanceVal:any = 0;
  
        } else{
  
          var AdvanceVal = this.express.advance;
  
        }
      }
  
      if(this.express.businessunit == 13){
  
        
        if (this.express.amount == null || this.express.amount == undefined || this.express.amount == "") {
  
          var InsuranceVal:any = 0;
    
        } else{
    
          var InsuranceVal = this.express.amount;
    
        }
      }
      else{
  
        if (this.express.insurance == null || this.express.insurance == undefined || this.express.insurance == "") {
  
          var InsuranceVal:any = 0;
  
        } else {
  
          var InsuranceVal = this.express.insurance;
  
        }
    }
    } 
    else {
      var casaVal:any = 0;
      var depositVal:any = 0;
      var AdvanceVal:any = 0;
      var InsuranceVal:any = 0;
    }

    if((remarks == "") || ((remarks == 'undefined') || (remarks == undefined))){
      remarks=null
    }else{
      remarks = remarks;
    }

    if (this.express.selectele == "P") {

      if ((this.express.addressname == "") || ((this.express.addressname == 'undefined') || (this.express.addressname == undefined))) {

        console.log(this.express.addressname)
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter Your Location</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        this.Alertservice.presentAlert("","Enter Your Location");
        return false;

      } else {
        //alert("location");
        // var latvalue = this.lat1; cmd by sijin
        // console.log(latvalue)
        // var langvalue = this.lng1; cmd by sijin
        console.log(langvalue)
        var address = this.express.addressname;
        console.log(address)
      }

    } else {
      var latvalue = null;
      var langvalue = null;
      var address = null;
    }
    //purpose= BusinessUnit;
    console.log(InsuranceVal)
    console.log(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
 if (this.express.selectele == "P") {
    console.log("call type is  personal visit");
    // this.showspin();
    this.loader.presentLoading('');
    this.Apiservice.updateExpressLead(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
      .then((res:any)=> {
        // this.hidespin();
        debugger
        this.loader.dismissLoading()
        console.log(res);
        var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
        var success:any = [];
        success = response;
        window.localStorage['date'] = "";
        console.log(success)
        if(success!=="")
        {
          if(success == '2'){
           
            this.Alertservice.presentAlert("","This customer is not mapped with you");
            return false
          }else{
          if(success[0].response != 1){
            //cmd by sijin all
            console.log(success, latvalue, langvalue, address,purpose, cbsid)
            // this.showspin();
              this.Apiservice.saveaddress(success, latvalue, langvalue, address,purpose,cbsid)
      .then((res)=> {
        debugger
        // this.hidespin();
        console.log(res)
        var response = res.data;
        response = JSON.parse(response);
        // response = JSON.parse(response);
         if(response == "Yes")
          { 
             
  //  var alertPopup = $ionicPopup.alert({
  //           title: 'Success',
  //           template: 'Saved Successfully'
  //         });
  this.loader.dismissLoading()

this.exsavemethod()

        //   this.Alertservice.presentAlert('Success',"Saved Successfully");
        //  this.modelDissmiss()
          // alertPopup.then(function(res) {
          //   this.expressLeadaction.hide(); cmd by sijin
          //   // Custom functionality....
          // });
          // this.doRefresh();
          }

              else{
          //        var alertPopup = $ionicPopup.alert({
          //   title: 'Error',
          //   template: 'Error While Saving'
          // });
          this.Alertservice.presentAlert('Error',"Error While Saving");
          // alertPopup.then(function(res) {
          //   this.expressLeadaction.hide();  cmd by sijin
          //   // Custom functionality....
          // });
              }

      }).catch((err)=>{
        // this.hidespin();
      })
    
   }
    else {


      // var alertPopup = $ionicPopup.alert({
      //   title: "",
      //   template: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + success[0].Column1
      // });
      // this.Alertservice.presentAlert("","Please Visit Follow Up Screen As It Is In FOLLOW UP Status " + success[0].Column1);
      this.exstatusmethod(success[0].Column1)
      // alertPopup.then(function(res) {
      //   this.expressLeadaction.hide();
      //   // Custom functionality....
      // });

    } 
          }
        }

       

      })
     

    }

    // this.UpdateModal.hide();

    else
    {
        console.log("call type is not a personal visit");
        // this.showspin();
      this.Apiservice.updateExpressLead(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
      .then((res:any)=> {
        // this.hidespin();
        debugger
        console.log(response);
        var response = res.data;
        response = JSON.parse(response);
        // response = JSON.parse(response);
        var success = [];
        success = response;
        window.localStorage['date'] = "";

        // if (success[0].response == 1) {

          if (response == 1) {
            // this.Alertservice.presentAlert("",'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + success[0].Column1);
            this.exstatusmethod(success[0].Column1)
          // var alertPopup = $ionicPopup.alert({
          //   title: "",
          //   template: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + success[0].Column1
          // });

          // alertPopup.then(function(res) {
          //   this.expressLeadaction.hide();
          //   // Custom functionality....
          // });

        } else {
          debugger
          this.loader.dismissLoading()
          // this.Alertservice.presentAlert('Success','Saved Successfully');
          // this.modelDissmiss()
          this.exsavemethod()
          // var alertPopup = $ionicPopup.alert({
          //   title: 'Success',
          //   template: 'Saved Successfully'
          // });

          // alertPopup.then(function(res) {
          //   this.expressLeadaction.hide();
          //   // Custom functionality....
          // });

          // this.doRefresh();

        }

        this.assignedvisit = {};
        // this.display();
        // response = JSON.parse(response);

      })
      // .error(function(response) {
      //   console.log(response);
      //   this.hidespin();
      // });  
    }

  }
  verifytime() {
    debugger
    var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
    this.getfollowdates = this.datepipe.transform( this.express.followupdate,'YYYY-MM-dd')
    if (this.getfollowdates <= date) {
      this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
   return false
    }
    // followupvisits.followdate
    // followupvisits.followtime
    // console.log(this.followupvisits.followdate)
    // console.log(this.followupvisits.followtime)
    // var hourvalid = this.followupvisits.followtime.getHours();
    // var minutevalid = this.followupvisits.followtime.getMinutes();
    // var followdates = this.followupvisits.followdate
    // followdates.setHours(hourvalid);
    // followdates.setMinutes(minutevalid);
    // followdates.getTime();
  
    // var current_time = $filter('date')(new Date(), 'h.mm a');;
    // var current_time = new Date().getTime();
    // if (this.followupvisits.followtime < current_time) {
    //   this.AlertService.presentAlert("","The Call Back Date should not be less than current date")
      // var myPopup = $ionicPopup.show({
      //   template: '<center>The Call Back Date should not be less than current date </center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //     /*onTap: function(e) {
      //             this.followupvisits.followtime =''
      //            }*/
      //   }]
      // });
    // }
  }
  async exsavemethod(){
    debugger
    const alert:any = await this.alert1.create({
      header: "",
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: "Saved Successfully",
      buttons: [{ text     : 'Ok',
     
      
      handler: () => {
        this.modelDissmiss()
      }
    },
   ]
    });
    await alert.present()
   }

   async exstatusmethod(msg){
    debugger
    const alert:any = await this.alert1.create({
      header: "",
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: "Please Visit Follow Up Screen As It Is In FOLLOW UP Status "+msg,
      buttons: [{ text     : 'Ok',
     
      
      handler: () => {
        this.modelDissmiss()
      }
    },
   ]
    });
    await alert.present()
   }
  
}
