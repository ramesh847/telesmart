/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/quotes */
/* eslint-disable no-var */
/* eslint-disable @typescript-eslint/type-annotation-spacing */
/* eslint-disable prefer-arrow/prefer-arrow-functions */
/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/dot-notation */
/* eslint-disable @typescript-eslint/no-inferrable-types */
/* eslint-disable @typescript-eslint/semi */
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { EmpnamewisedetailsPage } from '../empnamewisedetails/empnamewisedetails.page';

@Component({
  selector: 'app-branchwisedetails',
  templateUrl: './branchwisedetails.page.html',
  styleUrls: ['./branchwisedetails.page.scss'],
  providers:[Idle]
})
export class BranchwisedetailsPage implements OnInit {
  userid: any;
  branchid: any;
  UserType: any;

  showitemcard: boolean = false
  showitemlist: boolean = true
  segment: string = 'indivuduals';
  arr = new Array(25);
  BranchCode: any;
  BranchDescription: any;
  BranchID: any;
  rdmname: any;
  managerindividuals: any;
  mangerbranchs: any;
  individuals: any;
  branchlist: any;
  assignstartdate: any;
  assignstartend: any;
  index: 1;
  idleState: string;
  constructor(private modalController: ModalController, private navParams: NavParams,
    public apiservice: ApiServiceService,
    public alert: AlertServiceService,private idle:Idle,private router:Router) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>{
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    this.userid = window.localStorage['userID']
    this.branchid = window.localStorage['branchID']
    this.UserType = window.localStorage['userType']
    let data = this.navParams.get('Data');
    console.log(data)

    this.BranchCode = data.BranchCode
    this.BranchDescription = data.BranchDescription
    this.BranchID = data.BranchID
    this.rdmname = data.rdmname
    this.Openrdmheatmap();
    // this.reset()
    // this.rdmindiviuals();
  }

reset(){
  this.idle.watch()
}


  rdmindiviuals() {
    debugger
    let body = {
      "userid": this.userid,
      "branchid": this.BranchID,
      "UserType": this.UserType
    }
    console.log(body);
    this.apiservice.getRdmHeatMapIndividual1(body)
      .then((response: any) => {
        // response = JSON.parse(response);
        // var resp = JSON.stringify(response.data);
        // resp = JSON.parse(resp);
        response = JSON.parse(JSON.parse(response.data))
        console.log(response);
        // console.log(JSON.stringify(response));
        // console.log(response.data);
        this.individuals = response
      }, err => {
        // this.loader.dismissLoading()
        this.alert.presentAlert("", err.status)
      })

    this.apiservice.getRdmHeatMapBranch1(body)
      .then((response: any) => {

        response = JSON.parse(JSON.parse(response.data))
        console.log(response);

        // var resp = JSON.stringify(response.data);
        // resp = JSON.parse(resp);
        // response = JSON.parse(response);
        // console.log(JSON.stringify(response));
        console.log(response);
        this.branchlist = response
      }, err => {
        // this.loader.dismissLoading()
        this.alert.presentAlert("", err.status)
      })

    // this.apiservice.AssigneDdate()
    //   .then((response: any) => {
    //     response = JSON.parse(response);
    //     console.log(response);
    //     this.assignstartdate = response[0].EndDate;
    //     this.assignstartend = response[0].StartDate;
    //   }, err => {
    //     // this.loader.dismissLoading()
    //     this.alert.presentAlert("", err.status)
    //   })

    this.apiservice.AssigneDdate().then(response => {
      var resp = JSON.stringify(response.data);
      resp = JSON.parse(resp);
      resp = JSON.parse(resp);
      resp = JSON.parse(resp);
      console.log(resp)
      this.assignstartdate = resp[0]['EndDate'];
      console.log(this.assignstartdate)
      this.assignstartend = resp[0]['StartDate'];
      console.log(this.assignstartend)
    })








  }


  Openrdmheatmap() {
    // console.log(obj);
    console.log(this.BranchDescription);
    console.log(this.BranchID);



    // $scope.tabvalues1 = function (type, move) {
    //   console.log(type);
    //   console.log(move);
    //   $('.tabbutton').removeClass('active');
    //   $('.add' + type).addClass('active');
    //   $scope.var = type;


    //   if (move == 'move3') {
    //     $(".coolDiv").animate({ "left": "0%" }, "500");
    //   } else if (move == 'move4') {
    //     console.log("come move4")
    //     $(".coolDiv").animate({ "left": "50%" }, "500");
    //   }

    // }

    // $scope.tabvalues1(1, 'move1');

    console.log(this.userid, this.branchid)
    //callAPI.getheapmapbranchname(userid, branchid)


    this.apiservice.getheapmapbranchname(this.userid, this.BranchID).then((response: any) => {
      response = JSON.parse(JSON.parse(response.data))
      console.log(response);
      this.managerindividuals = response;
    })
    // this.apiservice.getheapmapbranchname(this.userid, this.branchid).
    //   then((response: any) => {
    //     response = JSON.parse(JSON.parse(response.data))
    //     console.log(response);
    //     this.managerindividuals = response;
    //     // console.log($scope.managerindividuals);
    //   })

    this.apiservice.getheapmap(this.userid, this.BranchID).
      then((response: any) => {
        response = JSON.parse(JSON.parse(response.data))
        console.log(response);
        //console.log(response);
        this.mangerbranchs = response;
        console.log(this.mangerbranchs);
      })


    //$state.go('app.HeatMap');
  }







  segmentChanged(ev: any) {
    this.segment = ev.detail.value;
  }

  cardshowbranch() {
    this.showitemcard = true
    this.showitemlist = false
  }
  tableshowbranch() {
    this.showitemcard = false
    this.showitemlist = true
  }



  modeldissmiss() {
    this.modalController.dismiss()
  }

  async getindivudualsdetails(items) {
    const modal = await this.modalController.create({
      component: EmpnamewisedetailsPage,
      componentProps: { Data: items, }
    });
    return await modal.present();
  }







}
