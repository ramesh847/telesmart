import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MyfollowupcallmodalPage } from './myfollowupcallmodal.page';

const routes: Routes = [
  {
    path: '',
    component: MyfollowupcallmodalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MyfollowupcallmodalPageRoutingModule {}
