import { Component, IterableDiffers, OnInit } from '@angular/core';
import { ApiServiceService} from './../../service/api-service.service';
import { AlertController, IonItem, NavParams } from '@ionic/angular';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { DatePipe } from '@angular/common';
// import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ModalController } from '@ionic/angular';
import { ToastServiceService } from 'src/app/service/toast-service.service';
import { Route, Router } from '@angular/router';
import { trueFn } from 'node_modules1/mini-css-extract-plugin/types/utils';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
@Component({
  selector: 'app-myfollowupcallmodal',
  templateUrl: './myfollowupcallmodal.page.html',
  styleUrls: ['./myfollowupcallmodal.page.scss'],
  providers: [
    DatePipe,Idle],
})
export class MyfollowupcallmodalPage implements OnInit {
  savebool:boolean
  Npacustomerdata: any;
  date: any;
  date1: any;
  time: any;
  Cusdata: any;
  lat1: any;
  lng1: any;
  showCardDetails: boolean = false;
  purposename: any;
  purposelist: any;
  followup: any={};
  addbaselocno: any;
  callOutCome:any;
  policyvalidResp: any;
  hidecalloutcome: boolean = true;
  purposeid: any;
  enable: boolean;
  search ={};
  person :any = {};
  Collectiondate1: any;
  myvalue: any;
  callname:any;
  nextcalldate1: any;
  followuptime: any;
  BaseArea: any;
  Lat: any;
  Long: any;
  policynum: any;
  policyNumber: any;
  permType: any;
  premiumPayTerm: any;
  premiumPayMode: any;
  ins_type: any;
  ins_source: any;
  ins_ref: any;
  businessunit: any;
  productGroup: any;
  product: any;
  folloup1213: boolean = false;
  callPurpose:any;
  branch: any;
  vaildResp: any;
  firstWords: any;
  followupcallsdata: any;
  username: any;
  firstname1: any;
  FeevalidResp: any;
  getusername: any;
  amountcollected: boolean = false;
  getfollowdates: string;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  cusdata1: any;
  term: any[];
  plans: any;
  companies: any;
  idleState: string;
  constructor(private apiService:ApiServiceService,
    // private navParams: NavParams,
    private alertService: AlertServiceService,private datepipe: DatePipe,
    public modalController: ModalController,private loader:ToastServiceService,public router:Router,
    private alert1:AlertController,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = "No longer idle."));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          (this.idleState = countdown.toString() )
      );}
    minDate: any = new Date().toISOString();
    maxData : any = (new Date()).getFullYear() + 3;
    today = new Date()
    dateToday1 = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
  ngOnInit() {
    debugger
    console.log("ttttttt")
    this.cusdata1=this.apiService.followupcallarray
    // this.Cusdata = this.navParams.get('Data');
    this.Cusdata=this.cusdata1[0]

    // this.followup = {};
    // this.UpdateModal.show();
    // this.dateToday1 = $filter('date')(new Date(), 'yyyy-MM-dd');
    console.log(this.Cusdata);
    // this.person.firstName = "";
    // this.person.lastName = "";
    // this.person.lastName = "";
  
    this.lat1 = "";
    this.lng1 = "";
    this.addbaselocno = "";
    //mapvalues
    // this.followup.type=this.Cusdata.purpose_id;
    console.log(this.followup.type);
    //  $("#showdivscalls").css("display", "none");
    window.localStorage['PurposeID'] = this.Cusdata.purpose_id;
    this.followup.purpose = this.Cusdata.purpose_id;
    this.purposename = this.Cusdata.PURPOSE;
    console.log(this.purposename);
  
    //Condition to hide call closed option for NPA followup and VVIP Visits purposes
    if(this.purposename != "NPA followup" && this.purposename != "VVIP Visits"){
      this.hidecalloutcome = false;
    }else{
      this.hidecalloutcome = true;
    }

  console.log( this.followup.calloutcome );
    this.purposelist = this.Cusdata.PURPOSETEST;
    console.log(this.purposelist);
    this.followup.firstName = this.Cusdata.firstname;
    this.followup.lastName = this.Cusdata.firstname;
    this.followup.email = "";
    this.followup.mobile = this.Cusdata.CONTACT_NO;
    this.followup.fullname = this.Cusdata.CUSTOMER_NAME;
  
    this.followup.Purpose = this.Cusdata.PURPOSE;
    
    //this.followup.calloutcome = 'Calls-FollowUp';
    this.followup.calloutcome = "";
    // if (this.followup.current == "") {
    this.followup.collected_date = "";
    this.followup.collected_accno = "";
    this.followup.collectamount = "";
    this.followup.calltype = 'T';
    this.followup.type ="";
    // this.followup.premPaymode ="";
    this.followup.InsuranceType = "";
    // }
    this.followup.Insurance_Source="";
    // if (this.followup.calloutcome == "") {
    this.followup.followdate = "";
    this.followup.followtime = "";
    // }
    // this.followup.calltype =' ' +"Telecall";
    // if (this.followup.calltype == "") {
    this.followup.JointVisit = "";
    this.followup.jointusername = "";
    this.followup.jointcode = "";
    // this.followup.type = this.Cusdata.purpose_id;
  
    if( this.Cusdata.Deposit_Amount == null ||  this.Cusdata.Deposit_Amount == "null"){
      this.followup.deposits = "";
    }else{
      this.followup.deposits = this.Cusdata.Deposit_Amount;
    }
  
    if( this.Cusdata.Casa_Amount == null ||  this.Cusdata.Casa_Amount == "null"){
      this.followup.casa = " ";
    }else{
      this.followup.casa = this.Cusdata.Casa_Amount;
    }
  
    if( this.Cusdata.Advance_Amount == null ||  this.Cusdata.Advance_Amount == "null"){
      this.followup.advance = " ";
    }else{
      this.followup.advance = this.Cusdata.Advance_Amount;
    }
    if( this.Cusdata.Insurance_Amount == null ||  this.Cusdata.Insurance_Amount == "null"){
      this.followup.insurance = " ";
    }else{
      this.followup.insurance = this.Cusdata.Insurance_Amount;
    }
  
    if( this.Cusdata.InsuranceSource == null ||  this.Cusdata.InsuranceSource == "null"){
      this.followup.Insurance_Source = " ";
    }else{
      this.followup.Insurance_Source = this.Cusdata.InsuranceSource;
    }
    //RelationShip ID is used Below
    if( this.Cusdata.ReffRelation == null ||  this.Cusdata.ReffRelation == "null"){
      this.followup.ReffRelation = " ";
    }else{
      this.followup.ReffRelation = this.Cusdata.ReffRelation;
    }
  
    if( this.Cusdata.InsuranceType == null ||  this.Cusdata.InsuranceType == "null"){
      this.followup.InsuranceType = " ";
    }else{
      this.followup.InsuranceType = this.Cusdata.InsuranceType;
    }
  
    // this.followup.casa = this.Cusdata.Casa_Amount;
    // this.followup.advance = this.Cusdata.Advance_Amount;
    // this.followup.insurance = this.Cusdata.Insurance_Amount;
    // }
  
    this.followup.remarks = "";
    if( this.Cusdata.CUSTOMER_ID != 0){
      this.followup.customerid = this.Cusdata.CUSTOMER_ID;
    }
    
    this.followup.customername = this.Cusdata.CUSTOMER_NAME;
    this.followup.Purpose = this.Cusdata.PURPOSE;
    window.localStorage['CustomerId'] = this.Cusdata.CUSTOMER_ID;
    window.localStorage['PurposeID'] = this.Cusdata.purpose_id;
    this.purposeid = this.Cusdata.purpose_id;
    console.log(this.purposeid);
    window.localStorage['CallId'] = this.Cusdata.CRMCallID;
    if ( this.Cusdata.CUSTOMER_ID == null) {
    
      this.enable = false;
  
    }
    if ( this.Cusdata.CUSTOMER_ID != null) {
      this.enable = true;
      this.getbusinessunit( this.Cusdata.CUSTOMER_ID);
      if( this.Cusdata.CUSTOMER_ID == 0){
        this.followup.lastname =   this.Cusdata.CUSTOMER_NAME;
        this.followup.mobile = this.Cusdata.CONTACT_NO;
      }else{
      // this.showspin();
      this.apiService.getcustomerdetails( this.Cusdata.CUSTOMER_ID)
        .then(response => {
          // this.hidespin();
          debugger
        var responses = JSON.stringify(response.data);
        debugger
        responses =JSON.parse(responses);
        responses =JSON.parse(responses);
        responses =JSON.parse(responses);
        this.Npacustomerdata = responses;
        debugger
        this.Npacustomerdata = JSON.parse(this.Npacustomerdata);
        debugger
        this.Npacustomerdata = this.Npacustomerdata;
        console.log("this", this.Npacustomerdata)
        // responses =JSON.parse(responses);
          // this.Npacustomerdata = responses;
          // this.Npacustomerdata = responses;
          debugger
          console.log("this.Npacustomerdata", this.Npacustomerdata)
          if(this.Npacustomerdata != "" && this.Npacustomerdata != undefined)
          {
            debugger
            console.log("this", responses)
          this.followup.customerid = this.Cusdata.CUSTOMER_ID;
          this.followup.customername = this.Npacustomerdata[0].Nfirstname + ' ' + this.Npacustomerdata[0].Nlastname;
          window.localStorage['customerName'] = this.followup.customername;
          this.followup.firstname = this.Npacustomerdata[0].Nfirstname;
          this.followup.lastname = this.Npacustomerdata[0].Nlastname;
          this.followup.mobile = this.Npacustomerdata[0].Nmobile;
          this.followup.resphnno = this.Npacustomerdata[0].Nresidencephone;
          this.followup.email = this.Npacustomerdata[0].Nemail;
  
          this.firstWords = [];
  
          var firstname = [];
  
          if (this.Npacustomerdata.length > 0) {
            // this.showspin();
          }
          for (var i = 0; i < this.Npacustomerdata.length; i++) {
  
            firstname = this.Npacustomerdata[i].Nfirstname.split(" ");
  
            this.firstWords.push(firstname[0]);
            this.Npacustomerdata[i].firstname = this.firstWords[i];
            this.firstname1 = this.Npacustomerdata[i].firstname;
            if (i == this.Npacustomerdata.length - 1) {
              // this.hidespin();
            }
          }
  
          console.log(this.Npacustomerdata[0].Add1);
          if(this.Npacustomerdata[0].Add1 != undefined || this.Npacustomerdata[0].Add2 != undefined || this.Npacustomerdata[0].Add3 != undefined || this.Npacustomerdata[0].Add4 != undefined || this.Npacustomerdata[0].PIN != undefined){
            var respAdd1= this.Npacustomerdata[0].Add1;
            var add1 = respAdd1.replace("/", "-");
            console.log(add1);
            var respAdd2= this.Npacustomerdata[0].Add2;
            var add2 = respAdd2.replace("/", "-");
            console.log(add2);
          this.followup.addressname = add1+' '+add2+' '+this.Npacustomerdata[0].Add3+' '+this.Npacustomerdata[0].Add4+' '+this.Npacustomerdata[0].PIN;
          console.log(this.followup.addressname);
          }
          if(this.followup.addressname != "" && this.followup.addressname != undefined)
          { 
            console.log(this.followup.addressname);
           this.myvalue = true;
           //this.data.selectele='P';
          //  this.setlatlong(this.followup.addressname);
          }
         
         }
        })
        // .error(function (response) {
        //   console.log(response);
        //   this.hidespin();
        // });
      }
    }

   // console.log(obj);
    console.log(this.followup.addressname);
        if(this.followup.addressname != '' &&this.followup.addressname != 'undefined' &&this.followup.addressname != undefined){
          // this.typeshowmap(this.lat1, this.lng1,this.followup.addressname)
        }
        // this.UpdateModal.show();
        this.getcalloutcome();
        
        // this.getpurpose();
        // this.getprodGroup();
      // this.getbusinessunit();
      console.log("this.Cusdata.PURPOSE",this.followup.Purpose);
      // this.reset()
      }
reset(){
  this.idle.watch()
}
      Selectproduct(value) {
        this.followup.prod = value
      }
      amountCollected(event) {
        console.log(event);
        if(event == false) {
        this.followup.current = 'Y';
        this.amountcollected = true;
        }
        else if(event == true) {
          this.followup.current = '';
          this.amountcollected = false;
        }
        console.log(event);
      }
  getamount(customer_id, date, acc_num) {
    // fromdate = 
    var formatted_date =  this.datepipe.transform(date, 'dd.MM.yyyy');
    this.apiService.getamount(formatted_date, acc_num, customer_id).then(resp => {
      if (resp.data == '"No collection entry is available.Please check"') {
        this.alertService.presentAlert("",'No Collection Entry Is Available.Please Check');

        // var myPopup = $ionicPopup.show({
        //   template: '<center>No Collection Entry Is Available.Please Check</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
  
  
      } else {
        var amount = resp.data;
        amount = amount.replace(/\"/g, "")
        this.followup.collectamount = amount;
        console.log(this.followup.collectamount);
      }
    })
  }
  modelDissmiss() {
    debugger
    if(this.cusdata1[1].close=="followcall" || this.cusdata1[1].close=="endfollowupcall"){
this.router.navigateByUrl('/myfollowupcall')
    }
  }
  checkusercode(val) {
    var usercode = val;
    var branchid = window.localStorage['branchID'];
  
    this.apiService.getusername(usercode, branchid)
      .then(response => {
        console.log(response);
       var responses = JSON.stringify(response.data);
        if (responses == "This User Not in this Branch") {
          this.alertService.presentAlert("",'Please Enter The Valid Emp Code');
          // var myPopup = $ionicPopup.show({
          //   template: '<center>Please Enter The Valid Emp Code</center>',
          //   title: "",
          //   scope: this,
          //   buttons: [{
          //     text: 'OK',
          //     type: 'button button-clear button-assertive'
          //   }]
          // });
          this.followup.jointusername = "";
          this.followup.jointcode = "";
  
        } else {
          this.getusername = response;
          this.followup.jointusername = this.getusername;
          console.log(this.getusername)
        }
  
      })
      // .error(function(response) {
      //   console.log(response);
      // });
  }
  
  // 
getcalloutcome() {
  // this.showspin();
  var count=0;
  this.apiService.getcalloutcomenew()
    .then(response => {
      console.log(response);
     var responses = JSON.stringify(response.data);
     responses = JSON.parse(responses);
     responses = JSON.parse(responses);
     responses = JSON.parse(responses);
     debugger
      this.callOutCome = responses;
      debugger
      // this.hidespin();

    })
    // .error(function(response) {
    //   console.log(response);
    //    count++; 
    //     if(count<=2){
    //       this.getcalloutcome();
    //      }else{
    //       this.hidespin();
    //       this.showToast('Server Error, Call Outcome is not loaded.' )
    //    }

    // });
}

onCompanySelected(){
  debugger
  // this.companies=[]
  this.plans=[]
  this.term=[]
  this.followup.selectedProduct=''
  // var strParamType = "Insurance";
  if(this.followup.prodGroup == '6'){
    var strParamType="Life Insurance"
  }else if(this.followup.prodGroup == '7'){
    var strParamType= "General Insurance"
  }else{
  var strParamType="Health Insurance"

  }

  var strCompany = this.followup.selectedCompany;
  var strProducts = 'test';
  if(strParamType == '' || strParamType == undefined){
    strParamType ='test'
  }
  if(strCompany == '' || strCompany == undefined){
    strCompany='test'
  }
  console.log("selected",strParamType,strCompany);
  this.apiService.getInsurancecompany(strCompany,strParamType).then((response:any)=>{
    debugger
    var result = response.data;
    if(result == '"No record"'){
     
      this.term=[]
      // this.products=[]
    }
      else{
        result = JSON.parse(result);
        result = JSON.parse(result);
      // this.products = result;
      console.log(result)
      this.plans = result;
    
      }
     
  })
}



onCompanyplanSelected(){
  debugger
 
  this.term=[]
  this.followup.selectedProduct=''
  var strParamType = this.followup.selectedCompany;
  if(this.followup.prodGroup == '6'){
    var strCompany="Life Insurance"
  }else if(this.followup.prodGroup == '7'){
    var strCompany= "General Insurance"
  }else{
  var strCompany="Health Insurance"

  }

  var strPlan = this.followup.plan;
  if(strParamType == '' || strParamType == undefined){
    strParamType ='test'
  }
  if(strCompany == '' || strCompany == undefined){
    strCompany='test'
  }
  if(strPlan == '' || strPlan == undefined){
    strPlan='test'
  }
  console.log("selected",strParamType,strCompany,strPlan);
  // /Life Insurance/LIC/SARAL JEEVAN BIMA
  this.apiService.getInsuranceplans(strCompany,strParamType,strPlan).then((response:any)=>{
    debugger
    console.log("products",response);
    var result = response.data;
    if(result == '"No record"'){
     
      
      // this.products=[]
    }else{
      result = JSON.parse(result);
      result = JSON.parse(result);
    // response = JSON.parse(response);
    this.term = result;
    // this.assigned.selectedProduct=""
    
    // this.assigned.selectedterm=""
    console.log("plans",this.plans);
    }
     
  })
}
oncompanytermsselected(){
  debugger
  // this.term=[]
  this.followup.selectedProduct=''


  var strParamType = "Insurance";
  if(this.followup.prodGroup == '6'){
    var strCompany="Life Insurance"
  }else if(this.followup.prodGroup == '7'){
    var strCompany= "General Insurance"
  }else{
  var strCompany="Health Insurance"

  }

  // var strParamType = this.mylead.type;
  // var strCompany = this.mylead.prodGroup;
  var strPlan = this.followup.plan;
  var strterm = this.followup.selectedterm;



  if(strParamType == '' || strParamType == undefined){
    strParamType ='test'
  }
  if(strCompany == '' || strCompany == undefined){
    strCompany='test'
  }
  if(strPlan == '' || strPlan == undefined){
    strPlan='test'
  }
  if(strterm == '' || strterm == undefined){
    strterm='test'
  }


  // console.log("selected",strParamType,strCompany,strPlan,strterm);
  // Life Insurance/SARAL JEEVAN BIMA/BELOW 10 YRS

  this.apiService.getInsuranceterm(strCompany,this.followup.selectedCompany,strPlan,strterm).then((response:any)=>{
    debugger
    console.log("products",response);
    var result = response.data;
      result = JSON.parse(result);
      // result = JSON.parse(result);
    // response = JSON.parse(response);
    this.followup.selectedProduct = result[0].text;
    // this.assigned.selectedPlan=""
    // console.log("plans",this.plans);
  })

}




getpurpose() {
  // this.showspin();
  var count=0;
  this.apiService.getpurposeold()
    .then(response => {
      console.log(response);
      var result = JSON.stringify(response.data);
      debugger
      result = JSON.parse(result);
      result = JSON.parse(result);
      result = JSON.parse(result);
      this.callPurpose = result;

      // this.hidespin();
    })
    // .error(function(response) {
    //   console.log(response);
    //  count++; 
    //   if(count<=2){
    //     this.getpurpose();
    //    }else{
    //       this.hidespin();
    //       this.showToast('Server Error, Purpose is not loaded.' )
    //    }
    // });
}

getbusinessunit(cust) {
  // this.showspin();
  this.apiService.getbusinesstype(cust)
    .then(response => {
      console.log(response);
      var result = JSON.stringify(response.data);
      debugger
      result = JSON.parse(result);
      result = JSON.parse(result);
      result = JSON.parse(result);
      this.businessunit = result;
      // this.businessunit = responses;
      // this.hidespin();

    })
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin();
    // });


}

getcallut(eve:any){
  debugger
  if(eve=="3"){
    this.followup.type=""
  }
}

getprodGroup(Type) {
  debugger
  this.followup.prodGroup=""
 this.followup.prod=""
  this.followup.type = Type;
  console.log("type",Type);
  // this.showspin();
  this.followup.premPaymode ="";
  this.followup.InsuranceType = "";
  // }
  this.followup.Insurance_Source="";
  this.followup.premPayTerm ="";
  this.productGroup=[]
  this.companies=[]
  this.product=[]
  this.plans=[]
  this.term=[]
  this.followup.selectedProduct=''

  this.apiService.getproductGroup(Type)
    .then(response => {
      console.log(response);
      var result = JSON.stringify(response.data);
      debugger
      result = JSON.parse(result);
      result = JSON.parse(result);
      result = JSON.parse(result);
     this.productGroup = result;
      // this.productGroup = responses;
      // this.hidespin();
    });

    this.getPremiumTerm();
    this.getPremiumMode() ;
    this.getInsuranceType();
    // this.getInsurancedata();
    this.getInsuranceSource();
  
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin();
    // });
}

// getproduct(Type,prodGroup) {
//   // this.showspin();
//   debugger
//   this.followup.prod=""
//   this.followup.type = Type;
//   this.followup.prodGroup = prodGroup;
//   console.log(Type,prodGroup)
//   if(Type == '13'&& prodGroup == '12') {
//     this.showCardDetails =  true;
//   }else {
//     this.showCardDetails = false
//   }
//   this.apiService.getProduct(Type,prodGroup)
//     .then(response => {
//       debugger
//       var result = JSON.stringify(response.data);
//       debugger
//       result = JSON.parse(result);
//       result = JSON.parse(result);
//       result = JSON.parse(result);
//       this.product = result;
//       // this.hidespin();
//     })
   
//     // .error(function(response) {
//     //   console.log(response);
//     //   this.hidespin();
//     // });
// }

getproduct(Type,prodGroup) {
  // this.showspin();
  debugger


  this.companies=[]
  this.plans=[]
  this.term=[]
  this.followup.selectedProduct=''
  if(prodGroup == '6'){
    // prodGroup="Life Insurance"

    var strParamType = "Life Insurance";
    console.log(strParamType)
    if(strParamType == '' || strParamType==undefined){
      strParamType='test'
    }
    var strCompany = 'test';
    var strProducts = 'test';
    console.log("selected",strParamType)
    this.apiService.getInsurance(strParamType,strCompany,strProducts).then((response:any)=>{
      debugger
      console.log("comapniesType",response);
      var result = response.data;
      if(result == '"No record"'){

      }else{
        result = JSON.parse(result);
        result = JSON.parse(result);
      // response = JSON.parse(response);
      this.companies = result;
      this.apiService.getProduct(Type,prodGroup)
    .then((res:any)=> {
      debugger
      var response = res.data;
    response = JSON.parse(response);
    response = JSON.parse(response);
      this.product = response;
      // this.hidespin();
    })

      // this.assigned.selectedCompany=""
      // this.assigned.selectedPlan=""
      // this.assigned.selectedProduct=""
      // this.assigned.selectedterm=""
      // console.log("comapnies",this.companies);
      }
       
    })


  } else if(prodGroup == '7'){
    // prodGroup="General Insurance"
   

    var strParamType = "General Insurance";
    console.log(strParamType)
    if(strParamType == '' || strParamType==undefined){
      strParamType='test'
    }
    var strCompany = 'test';
    var strProducts = 'test';
    console.log("selected",strParamType)
    this.apiService.getInsurance(strParamType,strCompany,strProducts).then((response:any)=>{
      debugger
      console.log("comapniesType",response);
      var result = response.data;
      if(result == '"No record"'){

      }else{
        result = JSON.parse(result);
        result = JSON.parse(result);
      // response = JSON.parse(response);
      this.companies = result;
      this.apiService.getProduct(Type,prodGroup)
    .then((res:any)=> {
      debugger
      var response = res.data;
    response = JSON.parse(response);
    response = JSON.parse(response);
      this.product = response;
      // this.hidespin();
    })

      // this.assigned.selectedCompany=""
      // this.assigned.selectedPlan=""
      // this.assigned.selectedProduct=""
      // this.assigned.selectedterm=""
      // console.log("comapnies",this.companies);
      }
       
    })
  }else if(prodGroup == '8'){
    // prodGroup="Health Insurance"
   

    var strParamType = "Health Insurance";
    console.log(strParamType)
    if(strParamType == '' || strParamType==undefined){
      strParamType='test'
    }
    var strCompany = 'test';
    var strProducts = 'test';
    console.log("selected",strParamType)
    this.apiService.getInsurance(strParamType,strCompany,strProducts).then((response:any)=>{
      debugger
      console.log("comapniesType",response);
      var result = response.data;
      if(result == '"No record"'){

      }else{
        result = JSON.parse(result);
        result = JSON.parse(result);
      // response = JSON.parse(response);
      this.companies = result;
      this.apiService.getProduct(Type,prodGroup)
    .then((res:any)=> {
      debugger
      var response = res.data;
    response = JSON.parse(response);
    response = JSON.parse(response);
      this.product = response;
      // this.hidespin();
    })

      // this.assigned.selectedCompany=""
      // this.assigned.selectedPlan=""
      // this.assigned.selectedProduct=""
      // this.assigned.selectedterm=""
      // console.log("comapnies",this.companies);
      }
       
    })
  }else{
    this.apiService.getProduct(Type,prodGroup)
    .then((res:any)=> {
      debugger
      var response = res.data;
    response = JSON.parse(response);
    response = JSON.parse(response);
      this.product = response;
      // this.hidespin();
    })
  }



 
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin();
    // });
}

getPremiumTerm() {
debugger
  this.apiService.getPremiumPayTerm()
    .then(response => {
      console.log(response);
     var responses = JSON.stringify(response.data);
     responses = JSON.parse(responses);
     debugger
     responses = JSON.parse(responses);
     responses = JSON.parse(responses);
     this.premiumPayTerm = responses;
      // this.premiumPayTerm = responses;
    })
    // .error(function(response) {
    //   console.log(response);
    // });
}

getPremiumMode() {
  debugger
  this.apiService.getPremiumPayMode()
    .then(response => {
      console.log(response);
      debugger
      var responses = JSON.stringify(response.data);
      responses = JSON.parse(responses);
      responses = JSON.parse(responses);
      responses = JSON.parse(responses);
      this.premiumPayMode = responses;
      // this.premiumPayMode = responses;
    })
    // .error(function(response) {
    //   console.log(response);
    // });
}

searchAllFollowUpCalls(Purpose,Customerid){
  var branchid = window.localStorage['branchID'];
var usertype = window.localStorage['userType'];
var userid = window.localStorage['userID'];
Customerid = "null";
var CustomerName = "null";
Purpose = "null";
var mode = "T";
  console.log("inside searchAllFollowUpCalls");
  console.log(Purpose);
  console.log(Customerid);

  if(Purpose == 717){
    this.getcalloutcome1();
  }else{
    this.getcalloutcome();
  }
  if(Customerid ==""){
    Customerid = "null";
  }
  if(Purpose ==""){
    Purpose = "null";
  }
  // this.showspin();
  this.apiService.myfollowupcallsdata(branchid, userid, usertype, Customerid, CustomerName, Purpose, mode)
    .then(response => {
      var responses = JSON.stringify(response.data);
      // this.$broadcast('scroll.refreshComplete');
      responses = JSON.parse(responses);
      responses = JSON.parse(responses);
      this.followupcallsdata = JSON.parse(responses);
      debugger
      this.followupcallsdata = this.followupcallsdata;

      // this.followupcallsdata = responses;
      this.firstWords = [];

      var firstname = [];

      for (var i = 0; i < this.followupcallsdata.length; i++) {

        firstname = this.followupcallsdata[i].CUSTOMER_NAME.split(" ");

        this.firstWords.push(firstname[0]);
        this.followupcallsdata[i].firstname = this.firstWords[i];
        this.purposename = this.followupcallsdata[i].PURPOSE;
        console.log(this.purposename);
        if (this.followupcallsdata[i].purpose_id == 11 || this.followupcallsdata[i].purpose_id == 12 || this.followupcallsdata[i].purpose_id == 13) {
          var sample_test = this.followupcallsdata[i].PURPOSE;
          this.followupcallsdata[i].PURPOSETEST = sample_test;
          this.followupcallsdata[i].PURPOSE = "Lead Generation";
        }
       
      }

      this.username = window.localStorage['userName'];
      // $ionicLoading.hide();

    })
    // .error(function(response) {
    //   // $ionicLoading.hide();
    //   console.log(response);
    // });
}
getcalloutcome1() {
  this.apiService.getcalloutcome1()
  .then(response => {
    console.log(response);
    var responses = JSON.stringify(response.data);
       responses = JSON.parse(responses);
     responses = JSON.parse(responses);
     responses = JSON.parse(responses);
     debugger
    this.callOutCome = responses;
    // this.hidespin();

  })
}

 

myfollowupcallsdata() {
  var branchid = window.localStorage['branchID'];
  var usertype = window.localStorage['userType'];
  var userid = window.localStorage['userID'];
  var Customerid = "null";
  var CustomerName = "null";
  var Purpose = "null";
  var mode = "T";
//   var usercode = window.localStorage['userCode'];
// var username = window.localStorage['userName'];
// var BRANCH = window.localStorage['branchID'];
// var STRUSERID = window.localStorage['userID'];
// var purpose = window.localStorage['PurposeID'];
//   this.search.CUSTOMER_ID = "";
// this.search.PURPOSE = "";
  // this.showspin();
  this.loader.presentLoading('')
  this.apiService.myfollowupcallsdata(branchid, userid, usertype, Customerid, CustomerName, Purpose, mode)
    .then(response =>{
      this.loader.dismissLoading()
      // this.$broadcast('scroll.refreshComplete');

      var responses = JSON.stringify(response.data);
      console.log(response);

      responses = JSON.parse(responses);
      responses = JSON.parse(responses);
      this.followupcallsdata = JSON.parse(responses);
      debugger
      this.followupcallsdata = this.followupcallsdata;
      debugger
      this.firstWords = [];

      var firstname = [];

      for (var i = 0; i < this.followupcallsdata.length; i++) {

        firstname = this.followupcallsdata[i].CUSTOMER_NAME.split(" ");

        this.firstWords.push(firstname[0]);
        this.followupcallsdata[i].firstname = this.firstWords[i];
        this.purposename = this.followupcallsdata[i].PURPOSE;
        console.log(this.purposename);
        if (this.followupcallsdata[i].purpose_id == 11 || this.followupcallsdata[i].purpose_id == 12 || this.followupcallsdata[i].purpose_id == 13) {
          var sample_test = this.followupcallsdata[i].PURPOSE;
          this.followupcallsdata[i].PURPOSETEST = sample_test;
          this.followupcallsdata[i].PURPOSE = "Lead Generation";
        }
        /*if( this.purposename == 'Banking' || this.purposename == 'Insurance' || this.purposename == 'Others')
                            {
                              
                               
                                this.show=true;
                            }
                            else
                            {
                                this.show=false;
                            }*/


      }




      //                         for(i=0;i<= this.followupcallsdata.length; i++){
      //                              // var firstname = this.followupcallsdata[i].CUSTOMER_NAME.split(' ').slice(0, -1).join(' ');
      //      var firstname = this.followupcallsdata[i].CUSTOMER_NAME.split(" ");
      // this.firstWords.push(firstname[0]);

      //                              console.log(this.firstWords)
      //                                 console.log(this.firstWords[0])

      //                         }
      this.username = window.localStorage['userName'];
      // $ionicLoading.hide();

    })
    // .error(function(response) {
    //   // $ionicLoading.hide();
    //   console.log(response);
    // }); 
}
savefollowupcalls(obj) {
  debugger
  var qqq=this.followup.callname
  console.log(obj)
  // this.showspin($ionicLoading);
  var usercode = window.localStorage['userCode'];
  var username = window.localStorage['userName'];
  var BRANCH = window.localStorage['branchID'];
  var STRUSERID = window.localStorage['userID'];
  // var purpose = window.localStorage['PurposeID'];
  var purpose = this.followup.purpose;
  var customername1 = this.followup.customername;
  var mobile1 = this.followup.mobile;
  var CALLTYPE = this.followup.calltype;
  var REMARKS1 = this.followup.remarks;
  var RESPONSE = obj.calloutcome;
  var CALLID1 = window.localStorage['CallId'];
  var CUSTID = this.followup.customerid;
  this.followup.addressname=  window.localStorage['addressName'];
  console.log(RESPONSE)

if(CUSTID == undefined || CUSTID == ''){
  CUSTID='0'
}


  if(RESPONSE != 3){
  if (CALLID1 == "") {

    var CALLID = null;
  } else {
    var CALLID = CALLID1;
  }


  if (REMARKS1 == "") {

    var REMARKS = null;
  } else {
    var REMARKS = REMARKS1;
  }

  if (customername1 == "") {

    var customername = null;
  } else {
    var customername = customername1;
  }

  if (mobile1 == "") {

    var mobile = null;
  } else {
    var mobile = mobile1;
  }

  debugger

  if (purpose == "5" && this.followup.current == "Y") {
    if ((this.followup.collected_date == null || this.followup.collected_date == undefined || this.followup.collected_date == "") || (this.followup.collected_accno == undefined || this.followup.collected_accno == "" || this.followup.collected_accno == null) || (this.followup.collectamount == null || this.followup.collectamount == "" || this.followup.collectamount == undefined)) {
      this.alertService.presentAlert("",'Fill All Details Of Amount Collected');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Fill All Details Of Amount Collected</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;

    } else {
      var colectionmode = "Y";
      this.Collectiondate1 = this.followup.collected_date;
      var Collectiondate = this.datepipe.transform(this.Collectiondate1, 'yyyy-MM-dd');
      var AccountNo = this.followup.collected_accno;
      var Amount = this.followup.collectamount;
    }

  }

  // if (purpose == "3") {
  //   if (this.followup.deposits == 0 && this.followup.casa == 0 && this.followup.advance == 0 && this.followup.insurance == 0) {
  //     this.alertService.presentAlert("",'Fill Details Of Expected Business');
  //     // var myPopup = $ionicPopup.show({
  //     //   template: '<center>Fill Details Of Expected Business</center>',
  //     //   title: "",
  //     //   scope: this,
  //     //   buttons: [{
  //     //     text: 'OK',
  //     //     type: 'button button-clear button-assertive'
  //     //   }]
  //     // });
  //     // this.hidespin($ionicLoading);
  //     return false;
  //   } else {
  //     var casaVal = this.followup.casa;
  //     var depositVal = this.followup.deposits;
  //     var AdvanceVal = this.followup.advance;
  //     var InsuranceVal = this.followup.insurance;
  //   }

  // }
  if (purpose == "3" || this.followup.Purpose == 'Lead Generation') {
    if ((this.followup.deposits == undefined || this.followup.deposits== '') && (this.followup.casa == undefined || this.followup.casa == '') &&
    (this.followup.advance == undefined || this.followup.advance == '') && (this.followup.insurance == undefined || this.followup.insurance == '')) {
     this.alertService.presentAlert("",'Fill Details Of Expected Business');
     return false
     // var casaVal = this.followup.casa;
     // var depositVal = this.followup.deposits;
     // var AdvanceVal = this.followup.advance;
     // var InsuranceVal = this.followup.insurance;
     // var insuranceType = this.followup.InsuranceType;
     // var insurancesource = this.followup.Insurance_Source;
     // var insuranceRefer = this.followup.referredby;
     // var insuranceRelation = this.followup.ReffRelation;
    
    } else {
    if(this.followup.casa == undefined ||this.followup.casa == ''){
    var casaVal = null
    }else{
    var casaVal = this.followup.casa
    }
    if(this.followup.deposits == undefined ||this.followup.deposits == ''){
    var depositVal = null
    }else{
    var depositVal = this.followup.deposits
    }
    if(this.followup.advance == undefined ||this.followup.advance == ''){
    var AdvanceVal = null
    }else{
    var AdvanceVal = this.followup.advance
    }
    if(this.followup.insurance == undefined ||this.followup.insurance == ''){
    var InsuranceVal = null
    }else{
    var InsuranceVal = this.followup.insurance
    }
    if(this.followup.InsuranceType == undefined ||this.followup.InsuranceType == ''){
    var insuranceType = null
    }else{
    var insuranceType = this.followup.InsuranceType
    }
    if(this.followup.Insurance_Source == undefined ||this.followup.Insurance_Source == ''){
    var insurancesource = null
    }else{
    var insurancesource = this.followup.Insurance_Source
    }
    if(this.followup.referredby == undefined ||this.followup.referredby == ''){
    var insuranceRefer = null
    }else{
    var insuranceRefer = this.followup.referredby
    }
    if(this.followup.ReffRelation == undefined ||this.followup.ReffRelation == ''){
    var insuranceRelation = null
    }else{
    var insuranceRelation = this.followup.ReffRelation
    }
    
    
     
     
    
     // var casaVal = null;
     // var depositVal = null;
     // var AdvanceVal = null;
     // var InsuranceVal = null;
     // var insuranceType = null;
     // var insurancesource = null;
     // var insuranceRefer = null;
     // var insuranceRelation = null;
    }

  }

  // if (this.followup.deposits != undefined || this.followup.casa != undefined || this.followup.advance != undefined || this.followup.insurance != undefined) {

  //   var casaVal = this.followup.casa;
  //   var depositVal = this.followup.deposits;
  //   var AdvanceVal = this.followup.advance;
  //   var InsuranceVal = this.followup.insurance;

  // } else {
  //   var casaVal = null;
  //   var depositVal = null;
  //   var AdvanceVal = null;
  //   var InsuranceVal = null;
  // }

// /new code 
// if ((this.followup.deposits == undefined || this.followup.deposits== '') && (this.followup.casa == undefined || this.followup.casa == '') &&
// (this.followup.advance == undefined || this.followup.advance == '') && (this.followup.insurance == undefined || this.followup.insurance == '')) {
//  this.alertService.presentAlert("",'Fill Details Of Expected Business');
//  return false


// } else {
if(this.followup.casa == undefined ||this.followup.casa == ''){
var casaVal = null
}else{
var casaVal = this.followup.casa
}
if(this.followup.deposits == undefined ||this.followup.deposits == ''){
var depositVal = null
}else{
var depositVal = this.followup.deposits
}
if(this.followup.advance == undefined ||this.followup.advance == ''){
var AdvanceVal = null
}else{
var AdvanceVal = this.followup.advance
}
if(this.followup.insurance == undefined ||this.followup.insurance == ''){
var InsuranceVal = null
}else{
var InsuranceVal = this.followup.insurance
}
if(this.followup.InsuranceType == undefined ||this.followup.InsuranceType == ''){
var insuranceType = null
}else{
var insuranceType = this.followup.InsuranceType
}
if(this.followup.Insurance_Source == undefined ||this.followup.Insurance_Source == ''){
var insurancesource = null
}else{
var insurancesource = this.followup.Insurance_Source
}
if(this.followup.referredby == undefined ||this.followup.referredby == ''){
var insuranceRefer = null
}else{
var insuranceRefer = this.followup.referredby
}
if(this.followup.ReffRelation == undefined ||this.followup.ReffRelation == ''){
var insuranceRelation = null
}else{
var insuranceRelation = this.followup.ReffRelation
}


 
 

 // var casaVal = null;
 // var depositVal = null;
 // var AdvanceVal = null;
 // var InsuranceVal = null;
 // var insuranceType = null;
 // var insurancesource = null;
 // var insuranceRefer = null;
 // var insuranceRelation = null;



  /* if (purpose != "3") {
           var casaVal =0;
       var depositVal = 0;
       var AdvanceVal = 0;
       var InsuranceVal = 0;

   }*/

  if (purpose != "5") {
    colectionmode = null;

  }

  console.log(this.followup.current)
  console.log(this.followup.JointVisit)

  if (purpose == "5") {
    if (this.followup.current == undefined || this.followup.current == "" || this.followup.current == null || this.followup.current == 'N') {
     colectionmode = null;
    }
  }

  if (colectionmode == null) {
    var AccountNo = null;
    var Amount = null;
    Collectiondate = null;
    colectionmode = null;
  }


  if (this.followup.calloutcome == "" || this.followup.calloutcome == null || this.followup.calloutcome == undefined) {
    this.alertService.presentAlert("",'Select Call OutCome');
    // var myPopup = $ionicPopup.show({
    //   template: '<center>Select Call OutCome</center>',
    //   title: "",
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // this.hidespin($ionicLoading);
    return false;
  }
  console.log(this.followup.followdate)
  console.log(this.followup.followtime)
  console.log(this.followup.calloutcome.Value)

  // ng-if="((doctype=='Manual'||doctype=='Driver')&&(mydata.documenttype=='Manual'||mydata.documenttype=='Driver'))"


  if (RESPONSE == "2") {

    if ((this.followup.followdate == "" || this.followup.followdate == undefined || this.followup.followdate == null) || (this.followup.followtime == "" || this.followup.followtime == undefined || this.followup.followtime == null)) {
      this.alertService.presentAlert("",'Provide Followup Details');
    
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Followup Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;


    }
    else {
      debugger

      var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
      this.getfollowdates = this.datepipe.transform( this.followup.followdate,'YYYY-MM-dd')
      if (this.getfollowdates <= date) {
        // this.followupvisits.followdate=''
        // this.followupvisits.followtime=''
        this.alertService.presentAlert("","The Call Back Date should not be same and less than current date")
      return false
      }else{


      this.nextcalldate1 = this.datepipe.transform(this.followup.followdate, 'yyyy-MM-dd'); 
      // var durationFilter = $filter('duration');
      // this.followuptime =this.datepipe.transform(this.followup.followtime, 'h.mm a');
      var time = this.followup.followtime.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.followup.followtime];

    if (time.length > 1) { // If time format correct
      time = time.slice (1);  // Remove full string match value
      this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; 
      time[1]="."// Adjust hours
    }
    this.modifytime1= time.join ('');
    if(this.getampm=="AM"){
      this.modifytime2= this.modifytime1+' '+"AM"
    }else{
      this.modifytime2= this.modifytime1+' '+"PM"
    }
  
      debugger
      var NEXTCALLDATE = this.nextcalldate1 + ' ' + this.modifytime2;
      debugger
      }
    }

  }

  if (RESPONSE != "2") {
    NEXTCALLDATE = '%20';


  }
debugger
  if (this.followup.calltype == "" || this.followup.calltype == null || this.followup.calltype == undefined) {
    this.alertService.presentAlert("",'Select Call Type');
    
    //   template: '<center>Select Call Type</center>',
    //   title: "",
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // this.hidespin($ionicLoading);
    return false;

  }

  if (this.followup.calltype == "P" && this.followup.JointVisit == "Y") {
    if (this.followup.jointcode == null || this.followup.jointcode == "" || this.followup.jointcode == undefined) {
      this.alertService.presentAlert("",'Enter Joint Usercode');
   
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter Joint Usercode</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;
    } else {
      var jointvisit = "Y";
      var jointcode = this.followup.jointcode;

    }


  }

  if (this.followup.calltype != "P") {

    jointvisit = null;

  }

  console.log(this.followup.JointVisit)
  if (this.followup.calltype == "P") {
    if (this.followup.JointVisit == "" || this.followup.JointVisit == undefined || this.followup.JointVisit == null || this.followup.JointVisit == 'N') {

      jointvisit = null;
    }

  }

debugger
  if (this.followup.calltype == "T") {
    if (this.followup.JointVisit == "" || this.followup.JointVisit == undefined || this.followup.JointVisit == null || this.followup.JointVisit == 'N') {

      jointvisit = null;
    }

  }

  if (jointvisit == null) {
    var jointcode = null;
  }
  var Endtime = null;
  var Totime = null;

  var latvalue, langvalue, address;

  if (this.followup.calltype == "P") {

    if ((this.followup.addressname == "") || ((this.followup.addressname == 'undefined') || (this.followup.addressname == undefined))) {
      console.log(this.followup.addressname)
      this.alertService.presentAlert("",'Enter Your Location');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter Your Location</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;

    } else {

      var latvalue = this.lat1;

      var langvalue = this.lng1;

      var address = this.followup.addressname;
    }

  } else {
    //alert("chooseplace12")
    latvalue = null;
    //console.log(latvalue)
    langvalue = null;
    //console.log(langvalue)
    address = null;
    //console.log(address);
  }
  /* var casaVal = null;
       var depositVal = null;
       var AdvanceVal = null;
       var InsuranceVal = null;*/
  //console.log(casaVal,depositVal,AdvanceVal,InsuranceVal);
  console.log(STRUSERID, CUSTID, RESPONSE, REMARKS, BRANCH, NEXTCALLDATE, CALLID, CALLTYPE, usercode, AccountNo, Amount, Collectiondate, colectionmode, jointvisit, jointcode, Endtime, Totime);

  if (this.followup.calltype == "P") {
    //debugger;
    // depositVal?, casaVal?, AdvanceVal?, InsuranceVal?
    this.savebool=true
    this.loader.presentLoadinglogin('')
    this.apiService.updatefollowcalls(STRUSERID, CUSTID, RESPONSE, REMARKS, BRANCH, NEXTCALLDATE, CALLID, CALLTYPE, usercode, AccountNo, Amount, Collectiondate, colectionmode, jointvisit, jointcode, Endtime, Totime)
      .then(response => {
        debugger
        this.loader.dismissLoading()
        this.savebool=false
        console.log("ramesh")
        // this.hidespin($ionicLoading);
        console.log(response);
        var responses = JSON.stringify(response.data)
        if (responses !== '') {
          //alert("address")
          console.log(CUSTID, latvalue, langvalue, address, purpose, CUSTID)
          this.apiService.saveaddress(CUSTID, latvalue, langvalue, address, purpose, CUSTID)
            .then(response =>

              {
                var responses = JSON.stringify(response.data)
                console.log(response);
                if (responses == '"Yes"') {
                  console.log(response);
                  this.fupsavemethod()
                  // this.alertService.presentAlert('Success','Saved Successfully');
                  // this.modelDissmiss()
                  // this.modalController.dismiss();
                  // var alertPopup = $ionicPopup.alert({
                  //   title: 'Success',
                  //   template: 'Saved Successfully'
                  // });

                  // alertPopup.then(function(res) {
                  //   this.UpdateModal.hide();

                  // });
                }
              })

        } else {
          // var alertPopup = $ionicPopup.alert({
          //   title: 'Error',
          //   template: 'Error While Saving'
          // });
          this.loader.dismissLoading()
         this.alertService.presentAlert('',"Error")
          // alertPopup.then(function(res) { this.alertService.presentAlert('Error','Error While Saving');
          //   this.UpdateModal.hide();

          // });
        }



        /* var alertPopup = $ionicPopup.alert({
           title: 'Success',
           template: 'Saved Successfully'
         });

         alertPopup.then(function(res) {
           this.UpdateModal.hide();

         });*/


        // this.myfollowupcallsdata();
      },err=>{
        this.loader.dismissLoading()
        this.savebool=false
         if(err.status == '-4'){
            this.alertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.alertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.alertService.presentAlert("Error", err.status)
          }
      })

      // .error(function(response) {
      //   console.log(response);
      //   // this.hidespin($ionicLoading);
      // });
  } else {
    this.loader.presentLoading('')
    this.savebool=true
    this.apiService.updatefollowcalls(STRUSERID, CUSTID, RESPONSE, REMARKS, BRANCH, NEXTCALLDATE, CALLID, CALLTYPE, usercode, AccountNo, Amount, Collectiondate, colectionmode, jointvisit, jointcode, Endtime, Totime)
      .then(response=> {
        // this.hidespin($ionicLoading);
        this.savebool=false
        console.log(response);
this.loader.dismissLoading()
this.fupsavemethod()
        // this.alertService.presentAlert('Success','Saved Successfully');
        // this.modelDissmiss()
        // var alertPopup = $ionicPopup.alert({
        //   title: 'Success',
        //   template: 'Saved Successfully'
        // });

        // alertPopup.then(function(res) {
        //   this.UpdateModal.hide();

        //   // Custom functionality....
        // });


        // this.myfollowupcallsdata();
      },err=>{
        this.savebool=false
         if(err.status == '-4'){
            this.alertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.alertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.alertService.presentAlert("Error", err.status)
          }
      })

      // .error(function(response) {
      //   console.log(response);
      //   // this.hidespin($ionicLoading);
      // });
    
  }

  // this.UpdateModal.hide();
}else{
  debugger
//  this.saveLeadConversion();
var CUSTID = window.localStorage['CustomerId'];
if(this.followup.type == 11 && CUSTID == 0){
  console.log(this.followup.customerid)
  this.validateCustID (this.followup.customerid)
}else{
  this.saveLeadConversion();
}
}
}

verifytime() {


  console.log(this.followup.followdate)
  console.log(this.followup.followtime)
  var hourvalid = this.followup.followtime.getHours();
  var minutevalid = this.followup.followtime.getMinutes();
  var followdates = this.followup.followdate
  followdates.setHours(hourvalid);
  followdates.setMinutes(minutevalid);
  followdates.getTime();

  // var current_time = $filter('date')(new Date(), 'h.mm a');;
  var current_time = new Date().getTime();
  // alert(this.data.followuptime)
  // alert(current_time);
  //console.log(this.data.followuptime);
  /* var followup_time= $filter('date')(this.data.followuptime, 'h.mm a');
   
   var current_time = $filter('date')(new Date(), 'h.mm a');;*/

  if (followdates < current_time) {
    this.alertService.presentAlert("",'The Call Back Date should not be less than current date');
    // var myPopup = $ionicPopup.show({
    //   template: '<center>The Call Back Date should not be less than current date </center>',
    //   title: "",
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive',
    //     onTap: function(e) {
    //       this.followup.followtime = ''
    //     }
    //   }]
    // });


  }
}


// setlatlong(addressname) {
//   console.log(addressname);
//   // $http.get('https://maps.googleapis.com/maps/api/geocode/json?address=' + addressname + '&key=AIzaSyBmB20neq4usVvgGguBN-zm4tubXXM3QDg').then(function(resp) {

//     var geocoder = new google.maps.Geocoder();
//     geocoder.geocode( { 'address': addressname}, function(resp, status) {
//     if (status == 'OK') {


//     console.log(resp)
//     this.BranchLatLong = resp[0].geometry.location.lat() + ',' + resp[0].geometry.location.lng();
//     //console.log(this.BranchLatLong)

//     this.lat1 = resp[0].geometry.location.lat();
//     console.log(this.lat1);
//     this.lng1 = resp[0].geometry.location.lng();
//     console.log(this.lng1);
//     this.addbaselocno = (this.lat1) + "," + (this.lng1);
//      this.typeshowmap(this.lat1, this.lng1, resp[0])
//     }
//   })

// }


getinfoadd(data) {
  console.log(data);
  console.log(data.formatted_address);
  this.lat1 = data.geometry.location.lat();
  this.lng1 = data.geometry.location.lng();
  this.addbaselocno = (this.lat1) + "," + (this.lng1);
  // this.typeshowmap(this.lat1, this.lng1, data);
};

callfuncforareaname(placename) {
  console.log(placename);
  var addresssplit = placename.split(",");
  var baseareaname = "";
  if (addresssplit[addresssplit.length - 1] == " India") {
    if (addresssplit.length == 3) {
      baseareaname = addresssplit[0];
    } else if (addresssplit.length == 4) {
      baseareaname = addresssplit[addresssplit.length - 4] + "," + addresssplit[addresssplit.length - 3];
    } else if (addresssplit.length == 5) {
      baseareaname = addresssplit[addresssplit.length - 4] + "," + addresssplit[addresssplit.length - 3];
    } else {
      if (addresssplit.length >= 6) {
        baseareaname = addresssplit[addresssplit.length - 5] + "," + addresssplit[addresssplit.length - 4];
      }
    }
  } else if (addresssplit[addresssplit.length - 1] == " USA") {
    if (addresssplit.length == 3) {
      baseareaname = addresssplit[0] + "," + addresssplit[1];
    } else {
      if (addresssplit.length >= 4) {
        baseareaname = addresssplit[addresssplit.length - 3] + "," + addresssplit[addresssplit.length - 2];
      }
    }
  } else if (addresssplit[addresssplit.length - 1] == " UK") {
    if (addresssplit.length == 3) {
      baseareaname = addresssplit[0] + "," + addresssplit[1];
    } else {
      if (addresssplit.length >= 4) {
        baseareaname = addresssplit[addresssplit.length - 3] + "," + addresssplit[addresssplit.length - 2];
      }
    }
  } else {
    addresssplit = addresssplit[0].split(" - ");
    if (addresssplit[addresssplit.length - 1] == "United Arab Emirates") {
      if (addresssplit.length >= 3) {
        baseareaname = addresssplit[addresssplit.length - 3] + "," + addresssplit[addresssplit.length - 2];
      }
    }
  }
  return baseareaname;
};

// typeshowmap(lat, lng, objectvals) {
//   this.myvalue = true;
//   console.log(lat, lng, objectvals)
//   this.BaseArea = this.callfuncforareaname(objectvals.formatted_address);
//   console.log("BaseArea");
//   console.log(this.BaseArea);
//   $("#showdivscalls").css("display", "block");
//   $("#showdivs1").css("display", "block");
//   this.addbaselocno = lat + "," + lng;
//   console.log(lat);
//   this.Lat = lat;
//   this.Long = lng;
//   var myLatlng = new google.maps.LatLng(lat, lng);
//   var mapProp = {
//     center: myLatlng,
//     zoom: 18,
//     mapTypeId: google.maps.MapTypeId.ROADMAP,
//     scrollwheel: true,
//     fullscreenControl: true
//   };
//   var map = new google.maps.Map(document.getElementById("mapShowFollowupCalls"), mapProp);
//   var geocoder = new google.maps.Geocoder();
//   var marker = new google.maps.Marker({
//     map: map,
//     draggable: true,
//     animation: google.maps.Animation.DROP,
//     position: myLatlng
//   });
  
//   marker.addListener('click', toggleBounce);
//   marker.setMap(map);
//   var infowindow = new google.maps.InfoWindow();

//   function toggleBounce() {
//     infowindow.setContent(objectvals.formatted_address);
//     infowindow.open(map, marker);
//   }
//   google.maps.event.addListener(marker, 'dragend', function() {
//     geocoder.geocode({ 'latLng': marker.getPosition() }, function(results, status) {
//       if (status == google.maps.GeocoderStatus.OK) {
//         if (results[0]) {
//           this.addbaselocno = results[0].geometry.location.lat() + "," + results[0].geometry.location.lng();
//           $('#chooseplace12').val(results[0].formatted_address);
//           this.addressname = results[0].formatted_address;
//           this.BaseArea = this.callfuncforareaname(this.addressname);
//           console.log("BaseArea");
//   console.log(this.BaseArea);
//           this.$apply();
//           infowindow.setContent(results[0].formatted_address);
//           infowindow.open(map, marker);
//         }
//       }
//     });
//   });
// };followdate

dateCheck() {
  // this.time='';
}
timeCheck() {
  debugger
  var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
  var date1 = this.datepipe.transform( this.followup.followdate,'YYYY-MM-dd')
  if (date1 <= date) {
    this.alertService.presentAlert("","The Call Back Date should not be same and less than current date")
    // return false
  //  this.date=''
  //  this.time=''

}
}

mapexpand() {
  this.myvalue = this.myvalue ? false : true;

}
mapShow(type){
  console.log(type);
  if(type=='P'){
    if(this.followup.addressname != 'undefined' && this.followup.addressname != ' '&& this.followup.addressname != ''&& this.followup.addressname != undefined){
      window.localStorage['addressName']  = this.followup.addressname;
      // this.setlatlong(this.followup.addressname);
    }
    
  }
}




saveLeadConversion() {
  debugger
  console.log(this.followup.customerid);
  // if(this.followup.customerid == undefined){
  //   var CUSTID = window.localStorage['CustomerId'];
  // }else{
  //   CUSTID = this.followup.customerid;
  // }
  // console.log(CUSTID);
  // if(this.followup.type == 11 && CUSTID == 0){
  //   console.log(this.followup.customerid)
  //   this.validateCustID (this.followup.customerid)
  // }else{
  var usercode = window.localStorage['userCode'];
  var username = window.localStorage['userName'];
  var BRANCH = window.localStorage['branchID'];
  var STRUSERID = window.localStorage['userID'];
  var purpose = window.localStorage['PurposeID'];
  console.log(purpose);
//  console.log(obj)
  // this.showspin($ionicLoading);
  if(this.followup.calloutcome == undefined || this.followup.calloutcome == null || this.followup.calloutcome == 'null' || this.followup.calloutcome == 'undefined'){
    this.alertService.presentAlert("",'Provide Call OutCome Details');
 
    // var myPopup = $ionicPopup.show({
    //   template: '<center>Provide Call OutCome Details</center>',
    //   title: "",
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // this.hidespin($ionicLoading);
      return false;
  }
  var prodctType='';
  var purpose = window.localStorage['PurposeID'];
  var firstName1 = this.followup.firstname;
  var LastName1 = this.followup.lastname;
  var mobile1 = this.followup.mobile;
  var email1 = this.followup.email;
  var CALLTYPE = this.followup.calltype;
  var REMARKS1 = this.followup.remarks;
  var RESPONSE = this.followup.calloutcome.Value;
  var CALLID1 = window.localStorage['CallId'];
  // var CUSTID = window.localStorage['CustomerId'];
  this.followup.addressname=  window.localStorage['addressName'];
 console.log(RESPONSE)
  if(this.followup.customerid == undefined){
    var CUSTID = window.localStorage['CustomerId'];
  }else{
    CUSTID = this.followup.customerid;
  }

  if (CALLID1 == "") {

    var CALLID = null;
  } else {
    var CALLID = CALLID1;
  }


  if (REMARKS1 == "") {

    var REMARKS = null;
  } else {
    var REMARKS = REMARKS1;
  }

  // if (customername1 == "") {

  //   var customername = null;
  // } else {
  //   var customername = customername1;
  // }

  if (mobile1 == "" || mobile1 == undefined ) {

    var mobile = null;
  } else {
    var mobile = mobile1;
  }
  debugger
  if(this.followup.type == undefined || this.followup.type == null || this.followup.type == ''){
    this.alertService.presentAlert("",'Select Product Type');
    // var myPopup = $ionicPopup.show({
    //   template: '<center>Select Product Type</center>',
    //   title: "",
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // this.hidespin($ionicLoading);
      return false;
  }else{
    prodctType = this.followup.type;
  }
  debugger
  if(prodctType == '12' && this.followup.prodGroup == 6){
    if(this.followup.plannum == undefined || this.followup.plannum == null){
      this.alertService.presentAlert("",'Provide Plan Number Details');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Plan Number Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;
    }else{
      var planNumber = this.followup.plannum;
    }
    
  }else{
     planNumber = 0;
  }
  if(prodctType == '13' && (this.followup.prodGroup=='11' || this.followup.prodGroup=='10')){
    if(this.followup.sumAssured == undefined || this.followup.sumAssured == null){
      this.alertService.presentAlert("",'Provide Sum Assured Details');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Sum Assured Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;
    }else{
      var PolicyAmount = this.followup.sumAssured;
    }
    
  }else{
    PolicyAmount = 0;
  }


  if(prodctType == '12'){
    if(this.followup.feeIncome == undefined || this.followup.feeIncome == null){
      var feeIncome =0;
    }else{
       feeIncome = 0
    }
    
  }else{
    var feeIncome = 0;
  }

  if (purpose == "3") {
    
    if ((this.followup.deposits == undefined || this.followup.deposits== '') && (this.followup.casa == undefined || this.followup.casa == '') &&
    (this.followup.advance == undefined || this.followup.advance == '') && (this.followup.insurance == undefined || this.followup.insurance == '')) {
     this.alertService.presentAlert("",'Fill Details Of Expected Business');
     return false
     // var casaVal = this.followup.casa;
     // var depositVal = this.followup.deposits;
     // var AdvanceVal = this.followup.advance;
     // var InsuranceVal = this.followup.insurance;
     // var insuranceType = this.followup.InsuranceType;
     // var insurancesource = this.followup.Insurance_Source;
     // var insuranceRefer = this.followup.referredby;
     // var insuranceRelation = this.followup.ReffRelation;
 
   } else {
 if(this.followup.casa == undefined ||this.followup.casa == ''){
   var casaVal = null
 }else{
   var casaVal = this.followup.casa
 }
 if(this.followup.deposits == undefined ||this.followup.deposits == ''){
   var depositVal = null
 }else{
   var depositVal = this.followup.deposits
 }
 if(this.followup.advance == undefined ||this.followup.advance == ''){
   var AdvanceVal = null
 }else{
   var AdvanceVal = this.followup.advance
 }
 if(this.followup.insurance == undefined ||this.followup.insurance == ''){
   var InsuranceVal = null
 }else{
   var InsuranceVal = this.followup.insurance
 }
 if(this.followup.InsuranceType == undefined ||this.followup.InsuranceType == ''){
   var insuranceType = null
 }else{
   var insuranceType = this.followup.InsuranceType
 }
 if(this.followup.Insurance_Source == undefined ||this.followup.Insurance_Source == ''){
   var insurancesource = null
 }else{
   var insurancesource = this.followup.Insurance_Source
 }
 if(this.followup.referredby == undefined ||this.followup.referredby == ''){
   var insuranceRefer = null
 }else{
   var insuranceRefer = this.followup.referredby
 }
 if(this.followup.ReffRelation == undefined ||this.followup.ReffRelation == ''){
   var insuranceRelation = null
 }else{
   var insuranceRelation = this.followup.ReffRelation
 }
    
   
     
     
    
     // var casaVal = null;
     // var depositVal = null;
     // var AdvanceVal = null;
     // var InsuranceVal = null;
     // var insuranceType = null;
     // var insurancesource = null;
     // var insuranceRefer = null;
     // var insuranceRelation = null;
   }

  }

  if(firstName1 == undefined || firstName1 == ''){
    var firstName = null;
  }else{
    var firstName = firstName1;
  }

  if(LastName1 == undefined || LastName1 == ''){
    var LastName = null;
  }else{
    var LastName = LastName1;
  }

  if(email1 == undefined || email1 == ''){
    var email = null;
  }else{
    var email = email1;
  }

  if (prodctType == '13' && this.followup.prodGroup == '12' || prodctType == '13' && this.followup.prodGroup == '11') {

    if (this.followup.opendate == "" || this.followup.opendate == undefined || this.followup.opendate == null) {
      this.alertService.presentAlert("",'Provide A/C open Date');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Open Date Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;


    } else {
      this.nextcalldate1 = this.datepipe.transform(this.followup.opendate, 'yyyy-dd-MM');
      var opendate = this.nextcalldate1;
    }

  }else if(prodctType == '13' && this.followup.prodGroup == '10'){
    if (this.followup.opendate == "" || this.followup.opendate == undefined || this.followup.opendate == null) {
      this.alertService.presentAlert("",'Provide Installation Date');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Open Date Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;


    } else {
      this.nextcalldate1 = this.datepipe.transform(this.followup.opendate, 'yyyy-dd-MM');
      var opendate = this.nextcalldate1;
    }
  }else if(prodctType == '13' && this.followup.prodGroup == '14'){
    if (this.followup.opendate == "" || this.followup.opendate == undefined || this.followup.opendate == null) {
      this.alertService.presentAlert("",'Provide Locker Open Date');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Open Date Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;


    } else {
      this.nextcalldate1 = this.datepipe.transform(this.followup.opendate, 'yyyy-dd-MM');
      var opendate = this.nextcalldate1;
    }
  }else if(prodctType == '12'){
    if (this.followup.opendate == "" || this.followup.opendate == undefined || this.followup.opendate == null) {
      this.alertService.presentAlert("",'Provide Open Date');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Open Date Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;


    } else {
      this.nextcalldate1 = this.datepipe.transform(this.followup.opendate, 'yyyy-dd-MM');
      var opendate = this.nextcalldate1;
    }
  }
  
  
  
  else{
    var opendate = null;
  }

  if (prodctType == '13' && productGroup == '12') {

    if (this.followup.policyNum == "" || this.followup.policyNum == undefined || this.followup.policyNum == null) {
      this.alertService.presentAlert("",'Provide Policy Number Details');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Policy Number Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;


    } else {
      
     // var policyNumber = this.followup.policyNum;
      this.policynum = this.followup.policyNum
      this.policyNumber = this.policynum.split('/').join('-')
      var policyNumber = this.policyNumber;
      console.log(policyNumber);
    }

  }else{
    policyNumber = 0;
  }

  if ((prodctType == '13' && this.followup.prodGroup == '14') || (prodctType == '13' && this.followup.prodGroup == '10') || prodctType == '12') {

    if (this.followup.premiumAmount == "" || this.followup.premiumAmount == undefined || this.followup.premiumAmount == null) {
     
      this.alertService.presentAlert("",'Provide premium Amount Details');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide premium Amount Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;


    } else {
      
      var premiumAmount = this.followup.premiumAmount;
    }

  }else{
    premiumAmount = 0;
  }


  if (prodctType == '13' || prodctType == '12') {

    if (this.followup.prodGroup == "" || this.followup.prodGroup == undefined || this.followup.prodGroup == null) {
      this.alertService.presentAlert("",'Provide Product Group Details');
     
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Product Group Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;


    } else {
      
      var productGroup = this.followup.prodGroup;
    }

  }else{
    productGroup = 0;
  }

  if (prodctType == '13' ) {
    // || prodctType == '12'
    if (this.followup.prod == "" || this.followup.prod == undefined || this.followup.prod == null) {
      this.alertService.presentAlert("",'Provide Product Details');
   
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Product Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;


    } else {
      
      var product = this.followup.prod;
    }

  }else{
    product = 0;
  }


  if (prodctType == '12') {

    if (this.followup.premPayTerm == "" || this.followup.premPayTerm == undefined || this.followup.premPayTerm == null) {
      // this.alertService.presentAlert("",'Provide Premium Paying Term Details');
     
      // return false;
      var permiumPayTerm = 0;

    } else {
      
      var permiumPayTerm = 0;
    }

  }else{
    permiumPayTerm = 0;
  }

  if (prodctType == '12') {

    if (this.followup.premPaymode == "" || this.followup.premPaymode == undefined || this.followup.premPaymode == null) {
      // this.alertService.presentAlert("",'Provide Premium Paying Mode Details');
   
      // return false;
      var permiumPayMode = 0

    } else {
      
      var permiumPayMode = 0
    }

  }else{
     permiumPayMode = 0;
  }

  if (prodctType == '12') {

    if (this.followup.referredby == "" || this.followup.referredby == undefined || this.followup.referredby == null) {
      // this.alertService.presentAlert("",'Enter Refered By');
     
      // return false;
insuranceRefer = 0

    } else {
      
       insuranceRefer = 0;
    }

    if (this.followup.InsuranceType == "" || this.followup.InsuranceType == undefined || this.followup.InsuranceType == null) {
      // this.alertService.presentAlert("",'Select Cross Sell Product');
     
      // return false;
insuranceType=0

    } else {
      
       insuranceType = 0
    }

    if (this.followup.Insurance_Source == "" || this.followup.Insurance_Source == undefined || this.followup.Insurance_Source == null) {
      // this.alertService.presentAlert("",'Select Source of Lead');
      
     
      // return false;

insurancesource=0
    } else {
      
       insurancesource = 0;
    }

    if (this.followup.Insurance_Source == 'Refferals' &&(this.followup.ReffRelation == " " || this.followup.ReffRelation == undefined || this.followup.ReffRelation == null)) {
      // this.alertService.presentAlert("",'Provide Reference Relationship');
      
    
      // return false;
      insuranceRelation=0

    } else {
      
      insuranceRelation = 0;
    }

    // var insuranceRefer = this.followup.referredby;
    insuranceRefer = 0
    // var insuranceRelation = this.followup.ReffRelation;
    insuranceRelation=0

  }else{
      insuranceRefer = 0;
    insuranceRelation = 0;
     insurancesource = 0;
     insuranceType = 0;
  }
  var todate = null;
  var premiumType= 0;
  var functionID= 1
  var stripaddress = 0;
  var jointid=0;
  // var casaVal = null;
  // var depositVal = null;
  // var AdvanceVal = null;
  // var InsuranceVal = null;
  if(depositVal == undefined || depositVal ==''){
    depositVal=0
  }
  if(casaVal == undefined || casaVal ==''){
    casaVal=0
  }
  if(AdvanceVal == undefined || AdvanceVal ==''){
    AdvanceVal=0
  }
  if(InsuranceVal == undefined || InsuranceVal ==''){
    InsuranceVal=0
  }
  console.log(CALLTYPE,CUSTID,planNumber,PolicyAmount,feeIncome,CALLID,productGroup,prodctType,
    depositVal,casaVal,AdvanceVal,InsuranceVal,
    BRANCH,firstName,LastName,email,mobile,usercode,product,REMARKS,opendate,policyNumber,premiumAmount,permiumPayTerm,permiumPayMode,STRUSERID,jointid);
this.savebool=true
  this.apiService.saveLeadConversion(CALLTYPE,CUSTID,planNumber,PolicyAmount,feeIncome,CALLID,productGroup,prodctType,depositVal,casaVal,AdvanceVal,InsuranceVal,BRANCH,firstName,LastName,email,mobile,usercode,product,REMARKS,opendate,policyNumber,premiumAmount,permiumPayTerm,permiumPayMode,STRUSERID,jointid+'_'+insuranceType+'_'+insurancesource+'_'+insuranceRelation+'_'+insuranceRefer)
  .then(response=> {
    console.log(response)
    debugger;
    var res = JSON.stringify(response.data);
    res = JSON.parse(res);
    res = JSON.parse(res);
    res = JSON.parse(res);
    res = res;
    // res = JSON.parse(res);

    debugger
    // this.alertService.presentAlert('Success',res);
    this.fupstatusmethod(res)
    // this.modalController.dismiss();
    // this.hidespin($ionicLoading);
    // var alertPopup = $ionicPopup.alert({
    //   title: 'Success',
    //   template: response
    // });

    // alertPopup.then(function(res) {
    //   this.UpdateModal.hide();
    //   this.myfollowupcallsdata();

    // });
    this.followup='';
  },err=>{
    this.savebool=false
    this.alertService.presentAlert("",err.status)
  })

  // .error(function(response) {
  //   console.log(response);
  //   // this.hidespin($ionicLoading);
  // });
//}
}

// callNumber(item){
//   console.log(item);
//   this.item = item;
//  // this.CallConnectModal.show();
//   this.clickcall.callerName=window.localStorage['userName'];
//   this.clickcall.callerMobile=window.localStorage['mobile'];
//   this.clickcall.customerName=item.CUSTOMER_NAME;
//   this.clickcall.customerMobile=item.CONTACT_NO;
//   this.clickcall.customerId=item.CUSTOMER_ID;
//   this.clickcall.purpose=item.purpose_id;
//   this.clickcall.purposeText= item.PURPOSE;
//   var currentDate= new Date();
//   this.clickcall.currDate = $filter('date')(currentDate, 'yyyy-MM-dd hh-mm-ss');
//   // this.clickcall.currDate = $filter('date')(currentDate, 'yyyy-MM-dd hh-mm-ss');
//   console.log(this.clickcall);
//   this.apiService.clickToCallFollowUP(this.clickcall.callerMobile,this.clickcall.customerMobile,this.clickcall.purposeText)
//   .then(function(response) {
//     console.log(response)
//     // this.hidespin($ionicLoading);
//     this.res = JSON.parse(response);
//     this.resout = JSON.parse(this.res);
//     console.log(this.resout)
//     if(this.resout.status == '200'){
//       this.clickcallID = this.resout.data;
//       this.callinterval();
//       this.CallConnectModal.show();
//     }else{
//     var alertPopup = $ionicPopup.alert({
//       title: 'Alert',
//       template: response
//     });
  
//     alertPopup.then(function(res) {
//     });
//     }

//   })
  
//   .error(function(response) {
//     console.log(response);
//     // this.hidespin($ionicLoading);
//   });

// }

validateCustID(obj){
  debugger
  var callID = window.localStorage['CallId'];
  var custID = window.localStorage['CustomerId'];
  var BRANCH = window.localStorage['branchID'];
  var STRUSERID = window.localStorage['userID'];
  var txtId = obj;
  if(obj != undefined || obj != 'undefined' || obj != null ){
    // this.showspin();
    this.apiService.getcustomerdetails(txtId)
      .then(response => {
        // this.hidespin();
        debugger
       var responses = JSON.stringify(response.data);
       responses = JSON.parse(responses);
       responses = JSON.parse(responses);
        this.Npacustomerdata = JSON.parse(responses);
        this.Npacustomerdata =  this.Npacustomerdata ;
        console.log(this.Npacustomerdata.length);
        // if(this.Npacustomerdata.length != 0)
        // {
          console.log('test');
          if(this.Npacustomerdata.length != 0)
          {
            this.branch= this.Npacustomerdata[0].NBranch; 
          }else{
            this.branch= 0;
          }
        this.apiService.custIDValidate(custID,callID,txtId,this.branch,BRANCH,STRUSERID)
        .then(response => {
          debugger
          console.log(response)
          this.vaildResp= JSON.stringify(response.data);
          this.vaildResp = JSON.parse(this.vaildResp);
          console.log("this.vaildResp",this.vaildResp);
          // this.hidespin($ionicLoading);
          if(this.vaildResp == 'OK'){
            console.log(this.vaildResp);

          this.saveLeadConversion();
            // this.followup.customername = this.Npacustomerdata[0].Nfirstname + ' ' + this.Npacustomerdata[0].Nlastname;
            // window.localStorage['customerName'] = this.followup.customername;
            // this.followup.firstname = this.Npacustomerdata[0].Nfirstname;
            // this.followup.lastname = this.Npacustomerdata[0].Nlastname;
            // this.followup.mobile = this.Npacustomerdata[0].Nmobile;
            // this.followup.resphnno = this.Npacustomerdata[0].Nresidencephone;
            // this.followup.email = this.Npacustomerdata[0].Nemail;



            // this.firstWords = [];

            // var firstname = [];

            // if (this.Npacustomerdata.length > 0) {
              // this.showspin();
            // }
            // for (i = 0; i < this.Npacustomerdata.length; i++) {

            //   firstname = this.Npacustomerdata[i].Nfirstname.split(" ");

            //   this.firstWords.push(firstname[0]);
            //   this.Npacustomerdata[i].firstname = this.firstWords[i];
            //   this.firstname1 = this.Npacustomerdata[i].firstname;
            //   if (i == this.Npacustomerdata.length - 1) {
            //     this.hidespin();
            //   }
            // }

            // console.log(this.Npacustomerdata[0].Add1);
            // if(this.Npacustomerdata[0].Add1 != undefined || this.Npacustomerdata[0].Add2 != undefined || this.Npacustomerdata[0].Add3 != undefined || this.Npacustomerdata[0].Add4 != undefined || this.Npacustomerdata[0].PIN != undefined){
            //   var respAdd1= this.Npacustomerdata[0].Add1;
            //   var add1 = respAdd1.replace("/", "-");
            //   console.log(add1);
            //   var respAdd2= this.Npacustomerdata[0].Add2;
            //   var add2 = respAdd2.replace("/", "-");
            //   console.log(add2);
            // this.followup.addressname = add1+' '+add2+' '+this.Npacustomerdata[0].Add3+' '+this.Npacustomerdata[0].Add4+' '+this.Npacustomerdata[0].PIN;
            // console.log(this.followup.addressname);
            // }
            // if(this.followup.addressname != "" && this.followup.addressname != undefined)
            // { 
            //   console.log(this.followup.addressname);
            // this.myvalue = true;
            // //this.data.selectele='P';
            // this.setlatlong(this.followup.addressname);
            // }
          
          }else{
            // this.hidespin();
            this.alertService.presentAlert('Success',this.vaildResp);
            // var alertPopup = $ionicPopup.alert({
            //   title: "",
            //   template: this.vaildResp
            // });
          
            // alertPopup.then(function(res) {
            //   this.followup={};
            //   this.UpdateModal.hide();
          
            // });
            
          }
         
        })
        
        // .error(function(response) {
        //   console.log(response);
        //   // this.hidespin($ionicLoading);
        // });
       
      // }
      })
      // .error(function (response) {
      //   console.log(response);
      //   this.hidespin();
      // });
    }

}


validatepolicy(type,policynum){
// this.showspin();
if(type == '12'){
// if(policynum != undefined || policynum != '' | policynum != null){
  if(policynum != undefined){
this.policynum = policynum.split('/').join('-')
console.log(this.policynum);
this.apiService.validatePolicynum(this.policynum)
.then(response => {
  console.log(response)
  this.policyvalidResp= JSON.stringify(response.data);
  this.policyvalidResp = JSON.parse(this.policyvalidResp);
  // this.hidespin($ionicLoading);
  if(this.policyvalidResp == 'OK'){
    console.log(this.policyvalidResp);
  //  this.ClickAccess =true;
  }else{
    this.alertService.presentAlert("", this.policyvalidResp);
    // this.hidespin();
    //   var alertPopup = $ionicPopup.alert({
    //     title: "",
    //     template: this.policyvalidResp
    //   });
    
    //   alertPopup.then(function(res) {
    //    this.followup.policyNum = '';
    
    //   });
  }
 
})

// .error(function(response) {
//   console.log(response);
//   // this.hidespin($ionicLoading);
// });
}
}
}

validatePermiumAmount(){
var callID = window.localStorage['CallId'];
var custID = window.localStorage['CustomerId'];
var BRANCH = window.localStorage['branchID'];
var STRUSERID = window.localStorage['userID'];
// this.showspin();
if(this.followup.policyNum == undefined || this.followup.policyNum == null || this.followup.policyNum == 'undefined' || this.followup.policyNum == ''){
 
  this.alertService.presentAlert("",'Enter the Policy Number');
  // this.hidespin();
  // var alertPopup = $ionicPopup.alert({
  //   title: "",
  //   template: 'Enter the Policy Number'
  // });
  this.followup.premiumAmount='';
  return false;
}
if(this.followup.premiumAmount == undefined || this.followup.premiumAmount == null || this.followup.premiumAmount == 'undefined' || this.followup.premiumAmount == ''){
  // this.hidespin();
  // var alertPopup = $ionicPopup.alert({
  //   title: "",
  //   template: 'Enter the Premium Amount'
  // });
  this.alertService.presentAlert("",'Enter the Premium Amount');
  this.followup.premiumAmount='';
  return false;
  
}
if(this.followup.premPayTerm == undefined || this.followup.premPayTerm == null || this.followup.premPayTerm == 'undefined' || this.followup.premPayTerm == ''){
  // this.hidespin();
  // var alertPopup = $ionicPopup.alert({
  //   title: "",
  //   template: 'Select the Premium Paying Term'
  // });
  this.alertService.presentAlert("",'Select the Premium Paying Term');
  this.followup.premiumAmount='';
  return false;

}

if(this.followup.premiumAmount > 1000000){
  this.alertService.presentAlert("",'Premium Amount exceeds limits on the account');
  // this.hidespin();
  // var alertPopup = $ionicPopup.alert({
  //   title: "",
  //   template: 'Premium Amount exceeds limits on the account'
  // });
  this.followup.premiumAmount='';
  return false;
}
//if(type == '12'){
this.permType = 0;
 this.apiService.validatePermAmount(this.followup.type,this.followup.prodGroup,this.permType,STRUSERID,BRANCH,this.followup.premiumAmount,this.followup.premPayTerm,this.followup.prod)
.then(response => {
  console.log(response)
  this.FeevalidResp= JSON.stringify(response.data)
  // this.hidespin($ionicLoading);
  if(this.FeevalidResp == ''){
    this.followup.feeIncome = 0;
  }else{
    this.followup.feeIncome = this.FeevalidResp;
  }
 
})

// .error(function(response) {
//   console.log(response);
//   // this.hidespin($ionicLoading);
// });
//}
}
getInsuranceType(){
this.apiService.getInsuranceType()
  .then(response => {
    console.log(response);
    debugger
    var responses = JSON.stringify(response.data);
    responses = JSON.parse(responses);
  responses = JSON.parse(responses);
  responses = JSON.parse(responses);
  debugger
    this.ins_type = responses;
  })
  // .error(function(response) {
  //   this.hidespin();
  //   console.log(response);
  // });
}
getInsuranceSource(){
  debugger
this.apiService.getInsuranceSource()
  .then(response => {
    debugger
    console.log(response);
  
    var responses = JSON.stringify(response.data);
    responses = JSON.parse(responses);
  responses = JSON.parse(responses);
  responses = JSON.parse(responses);
  this.ins_source = responses;
  })
  // .error(function(response) {
  //   this.hidespin();
  //   console.log(response);
  // });
}

getInsurancedata (val){
  debugger
console.log(val,this.followup.InsuranceSource);
  //Insurance Source
 this.apiService.getinsurancedetails('Refferals')
.then(response => {
  debugger
  // this.hidespin();
  console.log(response);
  var itemrefarr = JSON.stringify(response.data);
  itemrefarr = JSON.parse(itemrefarr);
  this.ins_ref = JSON.parse(JSON.parse(itemrefarr));
  this.ins_ref =  this.ins_ref.Table;
})
// .error(function(response) {
//   this.hidespin();
//   console.log(response);
// });

}
getInsurancedata1(valu) { 
  debugger
  console.log(valu);
}
// modelDissmiss() {
//   this.modalController.dismiss();
// }res

async fupstatusmethod(msg){
  const alert:any = await this.alert1.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Saved Successfully"+msg,
    buttons: [{ text     : 'Ok',
   
    
    handler: () => {
      this.modelDissmiss()
      // this.route.navigateByUrl('/mywishprimarycustomer')
    }
  },
 ]
  });
  await alert.present()
 }
async fupsavemethod(){
  const alert:any = await this.alert1.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Saved Successfully",
    buttons: [{ text     : 'Ok',
   
    
    handler: () => {
      this.savebool=false
      this.modelDissmiss()
      // this.route.navigateByUrl('/mywishprimarycustomer')
    }
  },
 ]
  });
  await alert.present()
 }

}



