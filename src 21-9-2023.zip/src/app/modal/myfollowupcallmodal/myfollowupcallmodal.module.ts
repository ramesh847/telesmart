import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MyfollowupcallmodalPageRoutingModule } from './myfollowupcallmodal-routing.module';

import { MyfollowupcallmodalPage } from './myfollowupcallmodal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MyfollowupcallmodalPageRoutingModule
  ],
  declarations: [MyfollowupcallmodalPage]
})
export class MyfollowupcallmodalPageModule {}
