import { Component, OnInit } from '@angular/core';
import { NavParams } from '@ionic/angular';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { AlertController } from '@ionic/angular';
import * as moment from "moment"; 
import { ModalController } from '@ionic/angular';
import { FollowupleadmodalPage } from '../followupleadmodal.page';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
@Component({
  selector: 'app-endcallmodal',
  templateUrl: './endcallmodal.page.html',
  styleUrls: ['./endcallmodal.page.scss'],
  providers:[DatePipe]
})
export class EndcallmodalPage implements OnInit {
  endDate: string;
  currDate: string;
  repStatus: any;
  statusResp: any;
  clickcallID: any;
  interval: any;
  res: any;
  resout: any;
  ClickAccess: boolean;
  accessResp: any;
  voicerecording: string;
  obj: any;
  mylead:any= {};
  dateToday1: string;
  purposeid: any;
  puposename: any;
  updatedname: any;
  purpose: any;
  customername: any;
  customerid: any;
  mobile: any;
  calltype: any;
  calldate: any;
  accoutnumber: any;
  fullname: any;
  enable: boolean;
  businessunitlist: any;
  custDetails: any;
  myleadcustomerdata: any;
  firstWords: any[];
  firstname1: any;
  myvalue: boolean;
  location: string;
  provider: string;
  status: string;
  status2: string;

  constructor(private alert:AlertController,private datepipe:DatePipe,
    private AlertService:AlertServiceService,private modalController:ModalController,
    private apiservice:ApiServiceService,
    private navParams:NavParams,public route:Router
    ) { }
  ngOnInit() {
    debugger
    let Cusdata = this.navParams.get('Data');
    console.log(Cusdata);
    this.callNumber(Cusdata);
    this.clickCallAccess();
  }

  clickCallAccess(){
    var userid = window.localStorage['userID'];
    this.apiservice.AccesstoClick(userid)
    .then((res)=> {
      console.log(res)
      var response =  JSON.parse(res.data)
      this.accessResp= JSON.parse(response)
      // this.hidespin($ionicLoading);
      if(this.accessResp == 'A'){
        console.log(this.accessResp);
        this.ClickAccess =true;
      }else{
        this.ClickAccess =false;
      }
     
    })
    
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin($ionicLoading);
    // });
  }



  clickcall:any={};
  item:any = '';
  callNumber(Cusdata){
    debugger
    console.log(Cusdata);
    this.item = Cusdata;


    // localStorage.setItem('branchID','329');
    // localStorage.setItem('branchCode','329');
    // localStorage.setItem('userCode','3442');
    // localStorage.setItem('userID','2606');
    this.clickcall.callerName= window.localStorage['userName'];
    // localStorage.setItem('userName','3442');
    localStorage.setItem('userType','11');
    //this.clickcall.callerMobile=localStorage.setItem('mobile','9490739835');
    this.clickcall.customerName=Cusdata.CUSTOMER_NAME;
    this.clickcall.customerMobile=Cusdata.CONTACT_NO;
    this.clickcall.customerId=Cusdata.CUSTOMER_ID;
    this.clickcall.purpose=Cusdata.PURPOSE.split('/').join('-');;
    this.clickcall.callerName=window.localStorage['userName']
    this.clickcall.callermobile= window.localStorage['mobile']
        // this.obj.customerName=Cusdata.CUSTOMER_NAME     
        
      //  this.obj.customerMobile=Cusdata.CONTACT_NO;
      // this.obj.customerId=Cusdata.CUSTOMER_ID;
        // this.obj.purpose=Cusdata.PURPOSE.split('/').join('-');
        // var currentDate=new Date();
        // this.obj.currDate=currentDate

    // this.clickcall.callerName=window.localStorage['userName'];
    // this.clickcall.callerMobile=window.localStorage['mobile'];
   
    this.clickcall.endDate='';
    
    var purpose = 'MyZeroStarCustomer';
    var currentDate= new Date();
    // this.clickcall.currDate = $filter('date')(currentDate, 'yyyy-MM-dd hh-mm-ss');
    // console.log(this.currDate);
    this.clickcall.currDate = moment(currentDate).format('YYYY-MM-DD h.mm a');
    // this.followuptime = moment(this.data.followuptime).format('h.mm a');
    this.apiservice.clickToCallCustomer(this.clickcall.callerMobile,this.clickcall.customerMobile,this.clickcall.purpose)
    .then((response)=> {
      debugger
      console.log(response)
      // this.hidespin($ionicLoading);
      // debugger
      this.res = JSON.parse(response.data);
      this.resout = JSON.parse(this.res);
      this.resout = JSON.parse(this.resout);
      // console.log(resout)
      // debugger
      if(this.resout.status == "200"){
        // debugger
        this.clickcallID = this.resout.data;
        this.callinterval();

        

        // this.CallConnectModal.show();
      }else{
        this.AlertService.presentAlert("Alert",this.resout.message)
      // var alertPopup = $ionicPopup.alert({
      //   title: 'Alert',
      //   template: response.data
      // });
    
      // alertPopup.then(function(res) {
      // });
      // by sijin
      }


    })
    
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin($ionicLoading);
    // });

  }

  callinterval(){
    // alert()
  this.interval = setInterval(() => {
this.callResp();
    // clearInterval(this.interval)
  }, 10000);
  }
  stopCall(){
    clearInterval(this.interval)
  }

  EndCallobj:any={};
  callResp(){
    console.log(this.clickcallID.id);
    var id = this.clickcallID.id;
    this.apiservice.callStatusCustomer(id)
    .then((response:any)=> {
    //  console.log(response)
    // debugger
      this.statusResp= JSON.parse(response.data)
      this.repStatus = JSON.parse(this.statusResp);
      this.repStatus = JSON.parse(this.repStatus);
      // debugger
      // this.hidespin($ionicLoading);
      debugger
      console.log(this.repStatus.data.length);
      if(this.repStatus.data.length == 1){
        console.log(this.repStatus.data[0].status2);
      if(this.repStatus.data[0].status2 != null){
        console.log(this.repStatus.data[0]);
        if(this.repStatus.data[0].status2 == 'ANSWER'){
          debugger
          this.stopCall();
          // this.CallConnectModal.hide();
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile=window.localStorage['mobile'];
          this.EndCallobj.customerName=this.item.CUSTOMER_NAME;
          this.EndCallobj.customerMobile=this.item.CONTACT_NO;
          this.EndCallobj.customerId=this.item.CUSTOMER_ID;
        
          //this.EndCallobj.cust=this.item.custCat;
          this.EndCallobj.endStatus= 'A';
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          this.Endcalllead(this.EndCallobj);
          // this.leadmodelpopup(this.item);
          // this.customerActionModal(this.item); by sijin
        }else{


          this.callresppopup(this.repStatus.data[0].status2)
      
        //  alert.present();

          // var myPopup = $ionicPopup.show({
          //   template: '<center>'+ this.repStatus.data[0].status2 +'. would you like to update?</center>',
          //   title: 'Alert',
          //   scope: this,
          //   buttons: [{
          //     text: 'Yes',
          //     type: 'button button-clear button-assertive',
          //     onTap: function (e) {
          //       this.clickcall={};
          //       this.CallConnectModal.hide();
          //       this.stopCall();
          //       console.log(this.item);
          //       this.EndCallobj.callerName=window.localStorage['userName'];
          //       this.EndCallobj.callerMobile=window.localStorage['mobile'];
          //       this.EndCallobj.customerName=this.item.CustomerName;
          //       this.EndCallobj.customerMobile='8825809300';
          //       this.EndCallobj.customerId=this.item.CBSCustomerId;
          //       //this.EndCallobj.cust=this.item.custCat;
          //       this.EndCallobj.endStatus= 'I';
          //       this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          //       this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          //       this.Endcall(this.EndCallobj);
          //       this.customerActionModal(this.item);
          //     }
    
    
          //   },
          //   {
          //     text: 'No',
          //     type: 'button button-clear button-assertive',
          //     onTap: function (e) {
          //       this.clickcall={};
          //       this.CallConnectModal.hide();
          //       this.stopCall();
          //       // console.log(this.item);
          //       // this.followupcallsUpdmodal(this.item);
          //     }
          //   }
          //   ]
          // });
          // by sijin above code important 
        }
        
      }
    }
    })
    
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin($ionicLoading);
    // });
  }
async callresppopup(ans){
  const alert:any = await this.alert.create({
    header: "Alert",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: ans+' would you like to update?',
    buttons: [{ text     : 'Okay',
   
    
    handler: () => {
               this.clickcall={};
            // this.CallConnectModal.hide(); sijin
            this.stopCall();
            console.log(this.item);
            this.EndCallobj.callerName=window.localStorage['userName'];
            this.EndCallobj.callerMobile=window.localStorage['mobile'];
            this.EndCallobj.customerName=this.item.CUSTOMER_NAME;
            this.EndCallobj.customerMobile=this.item.CONTACT_NO;
            this.EndCallobj.customerId=this.item.CUSTOMER_ID;
            
            //this.EndCallobj.cust=this.item.custCat;
            this.EndCallobj.endStatus= 'I';
            this.EndCallobj.currDate = this.repStatus.data[0].start_time;
            this.EndCallobj.endDate = this.repStatus.data[0].end_time;
            // this.Endcalllead(this.EndCallobj);
            this.leadmodelpopup(this.item);
            // this.customerActionModal(this.item);

         
    }
  },
  { text     : 'No',
   
    
  handler: () => {
    this.clickcall={};
    // this.CallConnectModal.hide(); cmd by sijin
    this.stopCall();
  }
},]
  });
}

  Endcalllead(obj){
    debugger
    // this.leadmodelpopup(this.item);
    var clickid=this.clickcallID.id
    console.log(obj);
    if(obj.endDate == undefined || obj.endDate == 'undefined' || obj.endDate == null || obj.endDate == ''){
      var enDate = new Date();
      //  this.endDate = $filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
       this.endDate = moment(enDate).format('YYYY-MM-DD h.mm a')
      // this.endDate = $filter('date')(enDate, 'hh-mm-ss');
      console.log(this.endDate);
      }else{
        var enDate= new Date(obj.endDate);
        this.endDate = moment(enDate).format('YYYY-MM-DD h.mm a')
        // this.endDate =$filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
        console.log(this.endDate);
      }
      var curDate= new Date(obj.currDate);
      this.currDate = moment(curDate).format('YYYY-MM-DD h.mm a')
      // this.currDate = $filter('date')(curDate, 'yyyy-MM-dd hh-mm-ss');
      console.log(this.currDate);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var purpose = 'Followup lead';
 

   
  // this.apiservice.callStatusLead(clickid).then((res:any)=>{
  //   debugger
  //   if(res !='' ){
  //     var dce=JSON.parse(JSON.parse(res.data))
  //     if(dce==''){
  //       this.leadmodelpopup(this.item);;
  //     }else{
  //     if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length !='0'){
  //       var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
      
  //       console.log(xyz)
      
  //       if(xyz[0].recording==''){
  //         this.voicerecording='No Record'
  //       }else{
  //       this.voicerecording=xyz[0].recording.slice(28)
  //       }
  //       if(xyz[0].location==''){
  //         this.location="no record"
  //       }else{
  //         this.location=xyz[0].location
  //       }
  //       if(xyz[0].provider==''){
  //         this.provider="no provider"
  //       }else{
  //         this.provider=xyz[0].location
  //       }

  //     this.apiservice.EndCAllClick2(obj.customerId,obj.customerName,obj.customerMobile,userid,branchid,obj.callerMobile,xyz[0].start_time,xyz[0].end_time,purpose,xyz[0].duration, xyz[0].billsec,xyz[0].credits,xyz[0].status,xyz[0].status2,this.voicerecording,this.location,this.provider)
  //     .then((response:any)=> {
  //       debugger
  //       // console.log(response)
  //       // this.hidespin($ionicLoading);
  //       if(obj.endStatus == 'I'){
       
  //         this.endcallpopup()
  //     }else{
  //       this.clickcall={};
  //             // this.CallConnectModal.hide();
  //             this.stopCall();
  //             // console.log(this.Cusdata);
  //             this.leadmodelpopup(this.item);
  //     }
  //     } ,(err)=>{
  //       debugger
  //       console.log(err);
  //       // this.hidespin();
  //       // var myPopup = $ionicPopup.show({
  //       //   template: err,
  //       //   title: 'Error',
  //       //   scope: this,
  //       //   buttons: [{
  //       //     text: 'OK',
  //       //     type: 'button button-clear button-assertive'
  //       //   }]
  //       // });
  //       this.AlertService.presentAlert('Error', err.status);
  //     }     )
      
  //     // .catch((error)=>{
  //     //   this.AlertService.presentAlert('failed',console.error(error));
        
  //     // });
  //   }else{
  //     this.leadmodelpopup(this.item);
  //     }
  //     }}else{
  //       this.leadmodelpopup(this.item);
  //     }
  // },(err)=>{
  //   console.log(err);
    
  //   this.AlertService.presentAlert('Error', err.status);
  // })

  this.apiservice.callStatusLead(clickid).then((res:any)=>{

    debugger
   res= JSON.stringify(res)
   res=JSON.parse(res)




    if(res=='' ){
     
      this.stopCall();
      // console.log($scope.item);
      this.leadmodelpopup(this.item);
    }else{
    
    if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
      // $scope.clickTocallConnect.hide();
      this.stopCall();
      // console.log($scope.item);
      this.leadmodelpopup(this.item);
    }else{
    
    var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
    
    if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
      this.voicerecording='No Record'
    }else{
    this.voicerecording=xyz[0].recording.slice(28)
    }
    if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
    this.location="no record"
    }else{
      this.location=xyz[0].location
    }
    if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
      this.provider="no provider"
    }else{
      this.provider=xyz[0].provider
    }
    if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
      this.status="no status"
    }else{
     this.status=xyz[0].status
    }
    if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
      this.status2="no status"
    }else{
     this.status2=xyz[0].status2
    }
    
    this.apiservice.EndCAllClick2(obj.customerId,obj.customerName,obj.customerMobile,userid,branchid,obj.callerMobile,xyz[0].start_time,xyz[0].end_time,purpose,xyz[0].duration, xyz[0].billsec,xyz[0].credits,this.status,this.status2,this.voicerecording,this.location,this.provider)
      .then((response:any)=> {
              debugger
          
              // obj.endStatus == 'I'
              if(obj.endStatus == '0'){
           
             
  
                this.endcallpopup()
  
            }else{
              debugger
             this.clickcall={};
                   
                  this.stopCall();
                    // console.log($scope.item);
                    this.leadmodelpopup(this.item);
            }
            },err=>{
              this.AlertService.presentAlert("Error",err.status)
            })
            
          
          }
            }
          })
  }
async endcallpopup(){
  const alert:any = await this.alert.create({
    header: "Alert",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "You have ended the call explicitly. would you like to update?",
    buttons: [{ text     : 'Okay',
   
    
    handler: () => {
      this.clickcall={};
            // this.CallConnectModal.hide();
            this.stopCall();
            console.log(this.item);
            this.clickcall={};
      // this.CallConnectModal.hide();
      this.stopCall();
      console.log(this.item);
      this.leadmodelpopup(this.item);
            // this.customerActionModal(this.item);
    }
  },
  { text     : 'No',
   
    
  handler: () => {
    this.clickcall={};
    // this.CallConnectModal.hide(); cmd by sijin
    this.stopCall();
  }
},]
  });
}


async leadmodelpopup(items){

  
//   this.apiservice.followupleadmodalarray=[]
//   this.apiservice.followupleadmodalarray.push(items,{model:"endnavigation"},{close:"endcallfollowlead"})
// this.route.navigateByUrl('/followupleadmodal')

  const modal = await this.modalController.create({
    component: FollowupleadmodalPage,
    componentProps: { Data: items ,model:"endnavigation"}
  });
  return await modal.present();
}

modelDissmiss(){
  this.modalController.dismiss();
 }






}


