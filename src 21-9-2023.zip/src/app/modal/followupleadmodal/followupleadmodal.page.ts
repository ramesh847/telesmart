import { Component, OnInit } from '@angular/core';
import { AlertController, NavParams } from '@ionic/angular';
import { ApiServiceService } from 'src/app/service/api-service.service';
import * as moment from "moment"; 
// import { Pipe, PipeTransform } from "@angular/core";
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ModalController } from '@ionic/angular';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { Pipe, PipeTransform} from '@angular/core';
import { DomSanitizer,SafeUrl } from "@angular/platform-browser";
import { Router } from '@angular/router';
import { FollowupLeadsPage } from 'src/app/followup-leads/followup-leads.page';
import { DatePipe } from '@angular/common';
import { ToastServiceService } from 'src/app/service/toast-service.service';
import { SafePipe } from 'src/app/service/safe.pipe';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
declare var google;
// @Pipe({ name: 'safe' })
@Pipe({
  name: 'actStatusPipe'
})
@Component({
  selector: 'app-followupleadmodal',
  templateUrl: './followupleadmodal.page.html',
  styleUrls: ['./followupleadmodal.page.scss'],
  providers:[DatePipe,SafePipe,Idle]
})
export class FollowupleadmodalPage implements OnInit {
mylead:any={};
firstWords:any = [];
purposeid:any;
puposename:any;
updatedname:any;
  purpose: any;
  customername: any;
  customerid: any;
  mobile: any;
  calltype: any;
  calldate: any;
  accoutnumber: any;
  fullname: any;
  enable: boolean;
  custDetails: any;
  myleadcustomerdata: any;
  firstname1: any;
  myvalue: boolean;
  businessunitlist: any;
  dateToday1: string;
  callOutCome: any;
  productGroup: any;
  product: any;
  premiumPayTerm: any;
  premiumPayMode: any;
  ins_type: any;
  ins_source: any;
  ins_ref: any;
  getusername: any;
  Inlatlng: any;
  distanceInMeter: any;
  endleadtime: string;
  Navigationrootleads: any;
  Url: any;
  nextcalldate1: string;
  myleadtime: any;
  startleadtime: string;
  branch: any;
  vaildResp: any;
  policynum: any;
  policyNumber: any;
  lat1: any;
  lng1: any;
  minDate: any = new Date().toISOString();
  maxData : any = (new Date()).getFullYear() + 3;
  dateToday3 = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
  getfollowdates: string;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  Cusdata1:any;
  Cusdata: any[];
  Cuhjhjjsdata: any[];
  letUrl: string;
  mapsURL: any;
  plans: any;
  term: any;
  companies: any;
  savebool:boolean
  idleState: string;
  textproductgroup: any;
  termproductid: any;
  constructor(private loader:ToastServiceService,public datepipe:DatePipe,
    private AlertService:AlertServiceService,public route:Router,
    private sanitizer:DomSanitizer,private geolocation: Geolocation,
    private modalController:ModalController,private Alertservice:AlertServiceService,
    private Apiservice:ApiServiceService,private alert:AlertController,private safe:SafePipe,private idle:Idle
    // private navParams:NavParams
    ) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = "No longer idle."));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.route.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          (this.idleState = countdown.toString() )
      );}

  ngOnInit() {
    debugger
    this.savebool=false
    this.Cusdata=this.Apiservice.followupleadmodalarray
    let Cusdata=this.Cusdata[0]
  //   let Cusdata = this.navParams.get('Data');
  // let Cusdata1=  this.navParams.get('model')
  let Cusdata1=this.Cusdata[1].model
 
    
      // let showconditionbased = chauck[1].model
      if(Cusdata1 == 'endnavigation'){
        this.endNavigationleads(Cusdata);
      }else if(Cusdata1 == "Actionnavigation" || Cusdata1=='' || Cusdata1==undefined ){
        this.myleadsmodel(Cusdata);
        this.startmylead(); //time taken for action  
      }else if(Cusdata1 == "Navigationrootleads"){
        this.Navigationrootleads = Cusdata1;
  this.startNavigationrootleads(Cusdata);
  window.localStorage['latitude'] 
  window.localStorage['longitude'] 
  // window.localStorage['accuracy'] =this.accuracy
  var latlongvaluedestination = window.localStorage['latitude']  + ',' + window.localStorage['longitude'] ;
  this.letUrl ="https://www.google.com/maps/embed/v1/directions?key=AIzaSyDGQhzcQYbQf9E7dzGUz-R7BVp2iFeNLfI&origin="+latlongvaluedestination+"&destination=null"
  this.mapsURL = `https://maps.google.com/maps?q=${window.localStorage['latitude']}%20${window.localStorage['longitude']}&t=&z=20&ie=UTF8&iwloc=&output=embed`;
  // this.transform(Url);
  // let data:any = this.sanitizer.bypassSecurityTrustUrl(Url);
  // console.log(data)
  // console.log(data.SafeUrlImpl.changingThisBreaksApplicationSecurity)
  // // this.photoURL();
  // this.Url = data.SafeUrlImpl.changingThisBreaksApplicationSecurity;
  // console.log(Cusdata)
      
    }
    
    // console.log(showconditionbased)
    console.log(Cusdata);
    
    this.getcalloutcome();
    this.getbusinessunit(Cusdata.CUSTOMER_ID);
    this.getPremiumTerm();
    this.getPremiumMode();
    this.getInsuranceSource();
    this.getInsuranceType();
  //  this.reset()
  }
  reset(){
    this.idle.watch()
  }
  startmylead()
  {
  //   console.log(obj);
  // alert("You have started the Meeting")
  //     console.log(obj);
       var timestart = new Date();
      console.log(timestart);
      this.startleadtime = moment(timestart).format("h.mm s a");
      //    this.followuptime = moment(this.data.followuptime).format('h.mm a')
      //  this.startleadtime = $filter('date')(timestart, 'h.mm s a');
      console.log( this.startleadtime);
  }
  // transform() {

  //   return this.sanitizer.bypassSecurityTrustResourceUrl("https://www.google.com/maps/embed/v1/directions?key=AIzaSyDGQhzcQYbQf9E7dzGUz-R7BVp2iFeNLfI&origin=13.0305815,80.2381075&destination=null");

  // }
  // photoURL() {
  //   return this.sanitizer.bypassSecurityTrustUrl(this.Url);
  // }

  getInsuranceType(){
    this.Apiservice.getInsuranceType()
      .then((res:any)=> {
        console.log(response);
        var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
        this.ins_type = response;
      })
      // .error(function(response) {
      //   this.hidespin();
      //   console.log(response);
      // });
  }
  getInsuranceSource(){
    this.Apiservice.getInsuranceSource()
      .then((res:any)=> {
        var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
        this.ins_source = response;
      })
      // .error(function(response) {
      //   this.hidespin();
      //   console.log(response);
      // });
  }

  getInsurancedata(val){
    console.log(val);
      //Insurance Source
     this.Apiservice.getinsurancedetails('Refferals')
    .then((res:any)=> {
      // this.hidespin();
      console.log(response);
      var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
      var itemrefarr = response;
      this.ins_ref = itemrefarr.Table;
    })
    // .error(function(response) {
    //   this.hidespin();
    //   console.log(response);
    // });
  
  }
  checkbox(Event){
    console.log(Event);
    
    if(Event == true){
      this.mylead.JointVisit = 'Y';
    }else{
      this.mylead.JointVisit = "N";
    }
    console.log(this.mylead.JointVisit)
  }

//fee income start
getfeeincome(){
  debugger
  var Branchid = window.localStorage['branchID'];
  var strUserId = window.localStorage['userID']
  var Amount=this.mylead.premiumAmount
  var term=this.mylead.selectedterm
  // this.mylead.premPayTerm
  // mylead.selectedterm

var productid=this.termproductid



  // var productid=this.mylead.selectedCompany
  // this.mylead.plan
  // this.mylead.plan
  // mylead.plan
  // var Mode ='L'
 
  this.Apiservice.feeincome(strUserId,Branchid,Amount,term,productid).then((res)=>{
    debugger
    this.mylead.feeIncome=JSON.parse(res.data)[0].feeamount
    // JSON.parse(JSON.parse(res.data))[0].feeamount

  })


}

//end


  checkusercode(val) {
    var usercode = val;
    var branchid = window.localStorage['branchID'];
    var struserCode = window.localStorage['userCode'];
    // this.showspin();
    // callAPI.getusername(struserCode,usercode, branchid)
    //   .success(function(response) {
    //     this.hidespin();
    //     console.log(response);
    //     response = JSON.parse(response);
    //     if (response == "This User Not in this Branch") {
  
    //       var myPopup = $ionicPopup.show({
    //         template: '<center>Please Enter The Valid Emp Code</center>',
    //         title: "",
    //         scope: this,
    //         buttons: [{
    //           text: 'OK',
    //           type: 'button button-clear button-assertive'
    //         }]
    //       });
    //       this.data.jointusername = "";
    //       this.data.jointusercode = "";
  
    //     } else {
    //       this.getusername = response;
    //       this.data.jointusername = this.getusername;
    //       console.log(this.getusername)
    //     }
  
    //   })
  
    this.Apiservice.checkJointCode(struserCode,usercode, branchid)
    .then((res:any)=> {
      // this.hidespin();
      // console.log(response);
      // response = JSON.parse(response);
      var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
      if (response == "This User Not in this Branch") {
  
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Please Enter The Valid Emp Code</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        this.Alertservice.presentAlert("","Please Enter The Valid Emp Code");
        this.mylead.jointusername = "";
        this.mylead.jointusercode = "";
  
      }else if (response == "Please Enter the Valid User Code") {
  
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Please Enter the Valid User Code</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        this.Alertservice.presentAlert("","Please Enter the Valid User Code");
        this.mylead.jointusername = "";
        this.mylead.jointusercode = "";
  
      }else if (response == "Please do not enter same user code") {
  
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Please do not enter same user code</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        this.Alertservice.presentAlert("","Please do not enter same user code");
        this.mylead.jointusername = "";
        this.mylead.jointusercode = "";
  
      }  else {
        this.getusername = response;
        this.mylead.jointusername = this.getusername;
        console.log(this.getusername)
      }
  
    })
      // .error(function(response) {
      //   this.hidespin();
      //   console.log(response);
      // });
  }
  getcalloutcome() {
    // this.showspin();

    this.Apiservice.getcalloutcomenew()
      .then((res:any)=>{
        console.log(response);
        // response = JSON.parse(response);
        var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
        this.callOutCome = response;
        // this.hidespin();
      })
      // .error(function(response) {
      //   console.log(response);
      //   this.hidespin();
      //   // count++; 
      //   //   if(count<=2){
      //   //     this.getcalloutcome();
      //   //    }else{
      //   //     this.hidespin();
      //   //     this.showToast('Server Error, Call Outcome is not loaded.' )
      //   //  }

      // });
      // this.Apiservice.getProduct(Type,prodGroup)
      //   .then((res:any)=> {
      //     debugger
      //     var response = res.data;
      //   response = JSON.parse(response);
      //   response = JSON.parse(response);
      //     this.product = response;
      //     // this.hidespin();
      //   })
  }
  getprodGroup(Type) {
    debugger
    // this.showspin();
    this.productGroup=[]
    this.companies=[]
    this.plans=[]
    this.term=[]
    this.mylead.selectedProduct=''

    this.Apiservice.getproductGroup(Type)
      .then((res:any)=> {
        debugger
        // console.log(response);
        // response = JSON.parse(response);
        var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
        this.productGroup = response;
        // this.hidespin();
      },err=>{
        this.AlertService.presentAlert("",err.status)
      })
      // .error(function(response) {
      //   console.log(response);
      //   this.hidespin();
      // });
  }

  getPremiumTerm(){

    this.Apiservice.getPremiumPayTerm()
      .then((res:any)=> {
        // console.log(response);
        // response = JSON.parse(response);
        var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
        this.premiumPayTerm = response;
      })
      // .error(function(response) {
      //   console.log(response);
      // });
  }
  getPremiumMode() {

    this.Apiservice.getPremiumPayMode()
      .then((res:any)=> {
        var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
        this.premiumPayMode = response;
      })
      // .error(function(response) {
      //   console.log(response);
      // });
  }

  myleadsmodel(obj){
    debugger
    //  this.UpdateModal.show();
    //  this.dateToday1 = $filter('date')(new Date(), 'yyyy-MM-dd');
    this.dateToday1 = moment(new Date()).format('YYYY-MM-DD');
    console.log(this.dateToday1)
     console.log(obj);
     
      var purposeid = obj.purp_id;
      this.purposeid = obj.purp_id;
     console.log(purposeid);
     console.log(obj.PURPOSE);
     this.puposename = obj.PURPOSE;
     console.log(obj.UpdatedOn)
     this.updatedname = obj.UpdatedOn;
 
     this.mylead.deposits = parseInt(obj.Deposit_Amount);
     this.mylead.casa = parseInt(obj.Casa_Amount);
     this.mylead.advance = parseInt(obj.Advance_Amount);
     this.mylead.insurance = parseInt(obj.Insurance_Amount);
     this.mylead.amount = parseInt(obj.other_Amount);
     this.mylead.caption = obj.other_caption;
     this.mylead.Insurance_Source = obj.InsuranceSource;
     this.mylead.ReffRelation = obj.ReffRelation;
     this.mylead.InsuranceType = obj.InsuranceType;
 
     this.mylead.calltype = "";
     
     this.mylead.remarks = "";
     this.mylead.calloutcome = "";
   
     this.mylead.followdate = "";
     this.mylead.followtime = "";
     this.mylead.JointVisit = "";
     this.mylead.jointcode = "";
     this.mylead.jointusername = "";
 
     this.purpose = obj.PURPOSE;
     window.localStorage['purpose'] = obj.PURPOSE;
     this.customername = obj.CUSTOMER_NAME;
     if(obj.CUSTOMER_ID != 0){
       this.mylead.customerid = obj.CUSTOMER_ID;
     }
     this.customerid = obj.CUSTOMER_ID;
 
     window.localStorage['CustomerId'] = obj.CUSTOMER_ID;
     this.mobile = obj.CONTACT_NO;
     this.calltype = obj.CallType;
     this.calldate = obj.NEXT_CALL_DATE;
     this.accoutnumber = obj.AccountNumber;
     window.localStorage['CallId'] = obj.CRMCallID;
     this.fullname = obj.CUSTOMER_NAME;
 
     //this.mylead.calltype ='P'
     if(obj.CallType == "Personal Visit"){
       this.mylead.calltype ='P';
     }else{
       this.mylead.calltype = 'T';
     }
    
     if(obj.Address !='null' && obj.Address !=null&& obj.Address !="undefined"&& obj.Address !=undefined)
     {
       this.mylead.addressname = obj.Address;
       //mylead.calltype
 
       if(obj.CallType == "Personal Visit"){
         this.mylead.calltype ='P';
         // this.typeshowmap1(this.mylead.addressname);
     
       }else{
         this.mylead.calltype = "";
       }
      
     }
     // else{   
       console.log(this.customerid);  
       if (this.customerid == null) {
 
       this.enable = false;
 
     }
     if (this.customerid != null) {
       this.enable = true;
       console.log(obj.CUSTOMER_ID)
       this.getbusinessunit(obj.CUSTOMER_ID);
       if(obj.CUSTOMER_ID == 0){
         this.mylead.lastname =  obj.CUSTOMER_NAME;
         this.mylead.mobile = obj.CONTACT_NO;
       }else{
      //  this.showspin();
       this.Apiservice.getcustomerdetails(this.customerid)
         .then((res:any)=> {
          //  this.hidespin();
           console.log(response);
           var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
           this.custDetails = response;
           this.myleadcustomerdata = JSON.parse(this.custDetails);
 
           if(this.myleadcustomerdata != "" && this.myleadcustomerdata != undefined)
           {
 
           this.mylead.customername = this.myleadcustomerdata[0].Nfirstname + ' ' + this.myleadcustomerdata[0].Nlastname;
           window.localStorage['customerName'] = this.mylead.customername;
           this.mylead.firstname = this.myleadcustomerdata[0].Nfirstname;
           this.mylead.lastname = this.myleadcustomerdata[0].Nlastname;
           this.mylead.mobile = this.myleadcustomerdata[0].Nmobile;
           this.mylead.resphnno = this.myleadcustomerdata[0].Nresidencephone;
           this.mylead.email = this.myleadcustomerdata[0].Nemail;
 
 
 
          
 
           var firstname = [];
 
           if (this.myleadcustomerdata.length > 0) {
            //  this.showspin();
           }
           for (var i = 0; i < this.myleadcustomerdata.length; i++) {
 
             firstname = this.myleadcustomerdata[i].Nfirstname.split(" ");
 
             this.firstWords.push(firstname[0]);
             this.myleadcustomerdata[i].firstname = this.firstWords[i];
             this.firstname1 = this.myleadcustomerdata[i].firstname;
             if (i == this.myleadcustomerdata.length - 1) {
              //  this.hidespin();
             }
           }
 
           console.log(this.myleadcustomerdata[0].Add1);
           if(this.myleadcustomerdata[0].Add1 != undefined || this.myleadcustomerdata[0].Add2 != undefined || this.myleadcustomerdata[0].Add3 != undefined || this.myleadcustomerdata[0].Add4 != undefined || this.myleadcustomerdata[0].PIN != undefined){
             var respAdd1= this.myleadcustomerdata[0].Add1;
             var add1 = respAdd1.replace("/", "-");
             console.log(add1);
             var respAdd2= this.myleadcustomerdata[0].Add2;
             var add2 = respAdd2.replace("/", "-");
             console.log(add2);
           this.mylead.addressname = add1+' '+add2+' '+this.myleadcustomerdata[0].Add3+' '+this.myleadcustomerdata[0].Add4+' '+this.myleadcustomerdata[0].PIN;
           console.log(this.mylead.addressname);
           }
           if(this.mylead.addressname != "" && this.mylead.addressname != undefined)
           { 
             console.log(this.mylead.addressname);
           this.myvalue = true;
           //this.data.selectele='P';
          //  this.setlatlong(this.mylead.addressname);//cmd by sijin 
           }
          }
 
 
         })
        //  .error(function (response) {
        //    this.hidespin();
        //    console.log(response);
        //  });
       }
       }
     }

     getbusinessunit (cust) {
  debugger
     //  this.showspin();
      this.Apiservice.getbusinesstype(cust)
         .then((res:any)=> {
          var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
           this.businessunitlist = response;


          // this.hidespin();
   
         })
         
   
   
     }

     getproduct(Type,prodGroup) {
      // this.showspin();
      debugger
      this.companies=[]
    this.plans=[]
    this.term=[]
    this.mylead.selectedProduct=''
    this.mylead.selectedCompany=''
    this.mylead.plan=''
    this.mylead.selectedterm=''
      if(prodGroup == '6'){
        // prodGroup="Life Insurance"

        var strParamType = "Life Insurance";
        console.log(strParamType)
        if(strParamType == '' || strParamType==undefined){
          strParamType='test'
        }
        var strCompany = 'test';
        var strProducts = 'test';
        console.log("selected",strParamType)
        this.Apiservice.getInsurance(strParamType,strCompany,strProducts).then((response:any)=>{
          debugger
          console.log("comapniesType",response);
          var result = response.data;
          if(result == '"No record"'){
    
          }else{
            result = JSON.parse(result);
            result = JSON.parse(result);
          // response = JSON.parse(response);
          this.companies = result;
          this.Apiservice.getProduct(Type,prodGroup)
        .then((res:any)=> {
          debugger
          var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
          this.product = response;
          // this.hidespin();
        })
    
          // this.assigned.selectedCompany=""
          // this.assigned.selectedPlan=""
          // this.assigned.selectedProduct=""
          // this.assigned.selectedterm=""
          // console.log("comapnies",this.companies);
          }
           
        })


      } else if(prodGroup == '7'){
        // prodGroup="General Insurance"
       

        var strParamType = "General Insurance";
        console.log(strParamType)
        if(strParamType == '' || strParamType==undefined){
          strParamType='test'
        }
        var strCompany = 'test';
        var strProducts = 'test';
        console.log("selected",strParamType)
        this.Apiservice.getInsurance(strParamType,strCompany,strProducts).then((response:any)=>{
          debugger
          console.log("comapniesType",response);
          var result = response.data;
          if(result == '"No record"'){
    
          }else{
            result = JSON.parse(result);
            result = JSON.parse(result);
          // response = JSON.parse(response);
          this.companies = result;
          this.Apiservice.getProduct(Type,prodGroup)
        .then((res:any)=> {
          debugger
          var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
          this.product = response;
          // this.hidespin();
        })
    
          // this.assigned.selectedCompany=""
          // this.assigned.selectedPlan=""
          // this.assigned.selectedProduct=""
          // this.assigned.selectedterm=""
          // console.log("comapnies",this.companies);
          }
           
        })
      }else if(prodGroup == '8'){
        // prodGroup="Health Insurance"
       

        var strParamType = "Health Insurance";
        console.log(strParamType)
        if(strParamType == '' || strParamType==undefined){
          strParamType='test'
        }
        var strCompany = 'test';
        var strProducts = 'test';
        console.log("selected",strParamType)
        this.Apiservice.getInsurance(strParamType,strCompany,strProducts).then((response:any)=>{
          debugger
          console.log("comapniesType",response);
          var result = response.data;
          if(result == '"No record"'){
    
          }else{
            result = JSON.parse(result);
            result = JSON.parse(result);
          // response = JSON.parse(response);
          this.companies = result;
          this.Apiservice.getProduct(Type,prodGroup)
        .then((res:any)=> {
          debugger
          var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
          this.product = response;
          // this.hidespin();
        })
    
          // this.assigned.selectedCompany=""
          // this.assigned.selectedPlan=""
          // this.assigned.selectedProduct=""
          // this.assigned.selectedterm=""
          // console.log("comapnies",this.companies);
          }
           
        })
      }else{
        this.Apiservice.getProduct(Type,prodGroup)
        .then((res:any)=> {
          debugger
          var response = res.data;
        response = JSON.parse(response);
        response = JSON.parse(response);
          this.product = response;
          // this.hidespin();
        })
      }



     
        // .error(function(response) {
        //   console.log(response);
        //   this.hidespin();
        // });
    }

    onCompanySelected(){
      debugger
      // this.companies=[]
    this.plans=[]
    this.term=[]
    this.mylead.plan=''
    this.mylead.selectedterm=''
    this.mylead.selectedProduct=''
      // var strParamType = "Insurance";
      if(this.mylead.prodGroup == '6'){
        var strParamType="Life Insurance"
      }else if(this.mylead.prodGroup == '7'){
        var strParamType= "General Insurance"
      }else{
      var strParamType="Health Insurance"

      }

      var strCompany = this.mylead.selectedCompany;
      var strProducts = 'test';
      if(strParamType == '' || strParamType == undefined){
        strParamType ='test'
      }
      if(strCompany == '' || strCompany == undefined){
        strCompany='test'
      }
      console.log("selected",strParamType,strCompany);
      this.Apiservice.getInsurancecompany(strCompany,strParamType).then((response:any)=>{
        debugger
        var result = response.data;
        if(result == '"No record"'){
         
          this.term=[]
          // this.products=[]
        }
          else{
            result = JSON.parse(result);
            result = JSON.parse(result);
          // this.products = result;
          console.log(result)
          this.plans = result;
        
          }
         
      })
    }



    onCompanyplanSelected(){
      debugger
      // this.plans=[]
      this.term=[]
      this.mylead.selectedterm=''
      this.mylead.selectedProduct=''
      
      var strParamType = this.mylead.selectedCompany;
      if(this.mylead.prodGroup == '6'){
        var strCompany="Life Insurance"
      }else if(this.mylead.prodGroup == '7'){
        var strCompany= "General Insurance"
      }else{
      var strCompany="Health Insurance"

      }
    
      var strPlan = this.mylead.plan;
      if(strParamType == '' || strParamType == undefined){
        strParamType ='test'
      }
      if(strCompany == '' || strCompany == undefined){
        strCompany='test'
      }
      if(strPlan == '' || strPlan == undefined){
        strPlan='test'
      }
      console.log("selected",strParamType,strCompany,strPlan);
      // /Life Insurance/LIC/SARAL JEEVAN BIMA
      this.Apiservice.getInsuranceplans(strCompany,strParamType,strPlan).then((response:any)=>{
        debugger
        console.log("products",response);
        var result = response.data;
        if(result == '"No record"'){
         
          
          // this.products=[]
        }else{
          result = JSON.parse(result);
          result = JSON.parse(result);
        // response = JSON.parse(response);
        this.term = result;
        // this.assigned.selectedProduct=""
        
        // this.assigned.selectedterm=""
        console.log("plans",this.plans);
        }
         
      })
    }
    oncompanytermsselected(){
      debugger
      this.term.forEach( (element) => {
        debugger
      if( element.text == this.mylead.selectedterm ){
        this.termproductid=element.VAL
      }
       
    });



      this.mylead.selectedProduct=''

      var strParamType = "Insurance";
      if(this.mylead.prodGroup == '6'){
        var strCompany="Life Insurance"
      }else if(this.mylead.prodGroup == '7'){
        var strCompany= "General Insurance"
      }else{
      var strCompany="Health Insurance"

      }

      // var strParamType = this.mylead.type;
      // var strCompany = this.mylead.prodGroup;
      var strPlan = this.mylead.plan;
      var strterm = this.mylead.selectedterm;

   
  
      if(strParamType == '' || strParamType == undefined){
        strParamType ='test'
      }
      if(strCompany == '' || strCompany == undefined){
        strCompany='test'
      }
      if(strPlan == '' || strPlan == undefined){
        strPlan='test'
      }
      if(strterm == '' || strterm == undefined){
        strterm='test'
      }
  
  
      // console.log("selected",strParamType,strCompany,strPlan,strterm);
      // Life Insurance/SARAL JEEVAN BIMA/BELOW 10 YRS
  
      this.Apiservice.getInsuranceterm(strCompany,this.mylead.selectedCompany,strPlan,strterm).then((response:any)=>{
        debugger
        console.log("products",response);
        var result = response.data;
          result = JSON.parse(result);
          // result = JSON.parse(result);
        // response = JSON.parse(response);
        this.mylead.selectedProduct = result[0].text;
        // this.assigned.selectedPlan=""
        // console.log("plans",this.plans);
      })
  
    }
    // getproduct(Type,prodGroup) {
    //   // this.showspin();
    //   this.Apiservice.getProduct(Type,prodGroup)
    //     .then((res:any)=> {
    //       var response = res.data;
    //     response = JSON.parse(response);
    //     response = JSON.parse(response);
    //       this.product = response;
    //       // this.hidespin();
    //     })
    //     // .error(function(response) {
    //     //   console.log(response);
    //     //   this.hidespin();
    //     // });
    // }

    modelDissmiss(){
      debugger
//       if(this.Cusdata1[1].close=="closefollowlead" || this.Cusdata1[2].close == "closefollowlead" || 
//       this.Cusdata1[1].close=="endcallfollowlead"){
//         this.route.navigateByUrl('/followup-leads')
       
//       }else
// if(this.Cusdata1[2].close=="planner"){
//   this.route.navigateByUrl('/myplanner')
// }
// else

      if(this.Cusdata[2].close=="followvisit"){
        this.route.navigateByUrl('/myfollowupvisits')
      }else if(this.Cusdata[2].close=="closefollowlead"  || this.Cusdata[2].close == "endcallfollowlead" ){
        this.route.navigateByUrl('/followup-leads')
        
      }else if(this.Cusdata[2].close == "planner"){
        this.route.navigateByUrl('/myplanner')
      }
    }




     //End
     private DisLat = null;
     private DisLong = null;
endNavigationleads(obj){
  
  console.log("endNavigationleads");
  console.log(obj);
   
   var rad = (x)=> {
      return x * Math.PI / 180;
    };
     setTimeout(()=> {
      var R = 6378137; // Earth’s mean radius in meter
      this.Inlatlng = window.localStorage['curntlatlngvallead'];
     // this.Inlatlng = '13.0308329,80.2380114';

     if( this.Inlatlng == undefined || this.Inlatlng == "undefined"){
      var posOptions = { timeout: 10000, enableHighAccuracy: false };
      this.geolocation.getCurrentPosition(posOptions).then((resp) => {
        var Inlatlng = (resp.coords.latitude) + "," + (resp.coords.longitude);
        // this.longitude = resp.coords.longitude;
        window.localStorage['curntlatlngval'] = Inlatlng;
       }).catch((error) => {
         console.log('Error getting location', error);
       });
 
     }
     this.Inlatlng = '13.0308329,80.2380114';
      console.log(this.Inlatlng)
      console.log(this.DisLat, this.DisLong)
      var latlong1arr = this.Inlatlng.split(",");
      // alert(latlong1arr)
      console.log(latlong1arr)

      var dLat = rad(latlong1arr[0] - this.DisLat);
      var dLong = rad(latlong1arr[1] - this.DisLong);
      var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(rad(this.DisLat)) * Math.cos(rad(latlong1arr[0])) *
        Math.sin(dLong / 2) * Math.sin(dLong / 2);
      console.log(a)
      var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      var d = R * c;
      console.log(d)
      this.distanceInMeter = d;


      var currentDateTime = new Date();

      var objdataupdtime:any = {};
      objdataupdtime.CUSTOMER_ID = obj.CUSTOMER_ID;
      objdataupdtime.RO_CODE = obj.RO_CODE;
      objdataupdtime.START_TIME = currentDateTime;
      //objdataupdtime.START_LOCATION = window.localStorage['trackinglocation'];

      console.log(objdataupdtime);
      console.log(this.distanceInMeter);

      // if (this.distanceInMeter >= 2000) {
      //   console.log("More than 200 meter")


      //   alert("Invalid Meeting Location.");
      // } else {





        //alert("Reached the Location");
         var timestart = new Date();
  console.log(timestart);
  //  this.endleadtime = $filter('date')(timestart, 'h.mm s a');
  // console.log(this.endleadtime);
  var timestart = new Date();
  console.log(timestart);
  this.endleadtime = moment(timestart).format("h.mm s a");

        console.log("Less than 200 meter");
        //alert("Reached the Location");
        // var myPopup = $ionicPopup.show({
        //   template: '<center> Reached the Location </center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive',
        //     onTap: function(e) {
        //       console.log("action popup");
        //       this.myleadsmodel(obj)
        //       //this.UpdateModal.show();
        //     }
        //   }]
        // });

//           Advance_Amount
// Deposit_Amount
// Casa_Amount
// Insurance_Amount
        if(obj.Advance_Amount=='null'|| obj.Advance_Amount=='undefined'|| obj.Advance_Amount==undefined|| obj.Advance_Amount==null){
          obj.Advance_Amount=="";
        }
        if(obj.Deposit_Amount=='null'|| obj.Deposit_Amount=='undefined'|| obj.Deposit_Amount==undefined|| obj.Deposit_Amount==null){
          obj.Deposit_Amount=="";
        }
        if(obj.Casa_Amount=='null'|| obj.Casa_Amount=='undefined'|| obj.Casa_Amount==undefined|| obj.Casa_Amount==null){
          obj.Casa_Amount=="";
        }
        if(obj.Insurance_Amount=='null'|| obj.Insurance_Amount=='undefined'|| obj.Insurance_Amount==undefined|| obj.Insurance_Amount==null){
          obj.Advance_Amount=="";
        }
        if(obj.CallType == 'Personal Visit'){
          this.mylead.calltype='P';
        }
        // this.mylead.calltype='P';
        this.myleadsmodel(obj)

        
      // }

    }, 500);

}
calcoutmethod(item:any){
  debugger
  this.mylead.calloutcome = this.mylead.calloutcome
}
verifytime() {
  debugger
  var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
  this.getfollowdates = this.datepipe.transform( this.mylead.followdate,'YYYY-MM-dd')
  if (this.getfollowdates <= date) {
    this.AlertService.presentAlert("Alert","The Call Back Date should not be same and less than current date")
    return false
  //  this.mylead.followdate=''
  //  this.mylead.followtime=''
  }
  // followupvisits.followdate
  // followupvisits.followtime
  // console.log(this.followupvisits.followdate)
  // console.log(this.followupvisits.followtime)
  // var hourvalid = this.followupvisits.followtime.getHours();
  // var minutevalid = this.followupvisits.followtime.getMinutes();
  // var followdates = this.followupvisits.followdate
  // followdates.setHours(hourvalid);
  // followdates.setMinutes(minutevalid);
  // followdates.getTime();

  // var current_time = $filter('date')(new Date(), 'h.mm a');;
  // var current_time = new Date().getTime();
  // if (this.followupvisits.followtime < current_time) {
  //   this.AlertService.presentAlert("Alert","The Call Back Date should not be less than current date")
    // var myPopup = $ionicPopup.show({
    //   template: '<center>The Call Back Date should not be less than current date </center>',
    //   title: "",
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //     /*onTap: function(e) {
    //             this.followupvisits.followtime =''
    //            }*/
    //   }]
    // });
  // }
}
saveleadcalls() {
  debugger

  // this.showspin();
  // var purpose = this.purpose;
  // var customername1 =this.customername;
  // var mobile1 = this.mobile;
  var purpose = window.localStorage['purpose'];
  var CALLTYPE = this.mylead.calltype;
  var REMARKS1 = this.mylead.remarks;
  var RESPONSE = this.mylead.calloutcome;
  var CALLID1 = window.localStorage['CallId'];
  var CUSTID = window.localStorage['CustomerId'];
  var STRUSERID = window.localStorage['userID'];
  var BRANCH = window.localStorage['branchID'];
  var usercode = window.localStorage['userCode'];
  // if(CUSTID != '0'){
  // this.mylead.addressname=  window.localStorage['addressName'];
  // }
  console.log(this.mylead.addressname);
  var AccountNo = null;
  var Amount = null;
  var Collectiondate = null;
  var colectionmode = null;
  console.log(RESPONSE);
  var purposeid = this.purposeid;
  console.log(purposeid);

  // console.log(RESPONSE)
   if(RESPONSE != 3){
  if (CALLID1 == "") {

    var CALLID = null;
  } else {
    var CALLID = CALLID1;
  }


  if (REMARKS1 == "") {

    var REMARKS = null;
  } else {
    var REMARKS = REMARKS1;
  }

  if (this.mylead.calloutcome == "" || this.mylead.calloutcome == null || this.mylead.calloutcome == undefined) {

    // var myPopup = $ionicPopup.show({
    //   template: '<center>Select Call OutCome</center>',
    //   title: "",
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // this.hidespin();
    this.Alertservice.presentAlert("","Select Call OutCome");
    return false;
  }
  console.log(this.mylead.followdate)
  console.log(this.mylead.followtime)
  console.log(this.mylead.calloutcome)

  // ng-if="((doctype=='Manual'||doctype=='Driver')&&(mydata.documenttype=='Manual'||mydata.documenttype=='Driver'))"


  if (RESPONSE == "2") {

    if ((this.mylead.followdate == "" || this.mylead.followdate == undefined || this.mylead.followdate == null) || (this.mylead.followtime == "" || this.mylead.followtime == undefined || this.mylead.followtime == null)) {
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Provide Followup Details</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert("","Provide Followup Details");
      return false;


    }
    else {
      var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
      this.getfollowdates = this.datepipe.transform( this.mylead.followdate,'YYYY-MM-dd')
      if (this.getfollowdates <= date) {
        // this.followupvisits.followdate=''
        // this.followupvisits.followtime=''
        this.AlertService.presentAlert("Alert","The Call Back Date should not be same and less than current date")
        return false
      
      }else{
      // this.nextcalldate1 = $filter('date')(this.mylead.followdate, 'yyyy-MM-dd');
      // // var durationFilter = $filter('duration');
      // this.myleadtime = $filter('date')(this.mylead.followtime, 'h.mm a');
      //console.log( this.myleadtime)
      this.nextcalldate1 = moment(this.mylead.followdate).format('YYYY-MM-DD');
      var time = this.mylead.followtime.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.mylead.followtime];

    if (time.length > 1) { // If time format correct
      time = time.slice (1);  // Remove full string match value
      this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; 
      time[1]="."// Adjust hours
    }
    this.modifytime1= time.join ('');
    if(this.getampm=="AM"){
      this.modifytime2= this.modifytime1+' '+"AM"
    }else{
      this.modifytime2= this.modifytime1+' '+"PM"
    }
      // moment(this.mylead.followtime).format('h.mm a');

      var NEXTCALLDATE = this.nextcalldate1 + ' ' + this.modifytime2;

    }
  }

  }

  if (RESPONSE != "2") {
    var NEXTCALLDATE = " ";


  }

  if (this.mylead.calltype == "" || this.mylead.calltype == null || this.mylead.calltype == undefined) {
    // var myPopup = $ionicPopup.show({
    //   template: '<center>Select Call Type</center>',
    //   title: "",
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // this.hidespin();
    this.Alertservice.presentAlert("","Select Call Type");
    return false;

  }

  if (this.mylead.calltype == "P" && this.mylead.JointVisit == "Y") {
    if (this.mylead.jointcode == null || this.mylead.jointcode == "" || this.mylead.jointcode == undefined) {
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter Joint Usercode</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive',
      //     //on-tap: this.mylead.jointusername="";
      //     onTap: function(e) {
      //       this.mylead.jointusername = "";
      //     }


      //   }]
      // });
      // this.hidespin();
      this.Alertservice.presentAlert("","Enter Joint Usercode");
      this.mylead.jointusername = "";
      return false;
    } else {
      var jointvisit = "Y";
      var jointcode = this.mylead.jointcode;


    }


  }
  
  if(this.purposeid=='13' ){
    if(this.mylead.caption == undefined || this.mylead.caption == ''){
      this.AlertService.presentAlert("","Please Enter The caption")
      return false
    }else{
      AccountNo=this.mylead.caption
    }

    if(this.mylead.amount == undefined || this.mylead.amount == ''){
      this.AlertService.presentAlert("","Please Enter The amount")
      return false
    }else{
      Amount=this.mylead.amount
    }
  }
  /*
                 if (purpose == "Lead Generation") {
      if(this.mylead.deposits==0 && this.mylead.casa==0 && this.mylead.advance==0 && this.mylead.insurance==0){
         var myPopup = $ionicPopup.show({
            template: '<center>Fill any one of Expected Business</center>',
            title: "",
            scope: this,
            buttons: [{
              text: 'OK',
              type: 'button button-clear button-assertive'
            }]
          });
          this.hidespin($ionicLoading);
          return false;
      }

          else{
          var casaVal = this.mylead.casa;
          var depositVal = this.mylead.deposits;
          var AdvanceVal = this.mylead.advance;
          var InsuranceVal = this.mylead.insurance;
      }

     }*/

  if (this.mylead.deposits != undefined || this.mylead.casa != undefined || this.mylead.advance != undefined || this.mylead.insurance != undefined) {

    var casaVal = this.mylead.casa;
    var depositVal = this.mylead.deposits;
    var AdvanceVal = this.mylead.advance;
    var InsuranceVal = this.mylead.insurance;

  }


  if (purpose != "Lead Generation") {
    var casaVal:any = 0;
    var depositVal:any = 0;
    var AdvanceVal:any = 0;
    var InsuranceVal:any = 0;

  }

  if (this.mylead.calltype != "P") {

    var jointvisit:string = null;

  }

  if (this.mylead.calltype == "P") {
    if (this.mylead.JointVisit == "" || this.mylead.JointVisit == undefined || this.mylead.JointVisit == null || this.mylead.JointVisit == 'N') {

      var jointvisit:string = null;
    }

  }

  if (jointvisit == null) {
    var jointcode = null;
  }

if (this.mylead.calltype == "P") {
  if ((this.startleadtime == "") || ((this.startleadtime== 'undefined') || (this.startleadtime == undefined))) {
    var Endtime = null;
  } else {
    var Endtime:any = this.startleadtime
   
  }
}
  else
  {
var Endtime = null;
  }
if (this.mylead.calltype == "P") {
  if (( this.endleadtime== "") || (( this.endleadtime == 'undefined') || ( this.endleadtime== undefined))) {
    var Totime = null;
  } else {
    //var Totime = this.timeended;
     //var Totime = endtime
     //totime
      var Totime:any =  this.endleadtime;
      
  }
}
else
  {
    var Totime = null;
  }


  //var Totime = null;

  //var Endtime = null;

  // var Endtime = this.timestarted;
  //var Totime = null;
  //var Totime =  this.timeended;



  if (this.mylead.calltype == "P") {

    if ((this.mylead.addressname == "") || ((this.mylead.addressname == 'undefined') || (this.mylead.addressname == undefined))) {
      console.log(this.mylead.addressname)
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter Your Location</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert("","Enter Your Location");
      return false;

    } else {

      var latvalue = this.lat1;

      var langvalue = this.lng1;

      var address = this.mylead.addressname;
    }

  } else {
    //alert("chooseplace12")
    latvalue = null;
    //console.log(latvalue)
    langvalue = null;
    //console.log(langvalue)
    address = null;
    //console.log(address);
  }

  // var lastname = this.followup.lastname;

  if (this.mylead.calltype == "P") {
    console.log("calltype is personal  visit");
    this.savebool=true
    console.log(STRUSERID, CUSTID, RESPONSE, REMARKS, BRANCH, NEXTCALLDATE, CALLID, CALLTYPE, usercode, AccountNo, Amount, Collectiondate, colectionmode, jointvisit, jointcode, Endtime, Totime, depositVal, casaVal, AdvanceVal, InsuranceVal)
    // this.showspin();
    this.loader.presentLoading('')
    debugger
    this.Apiservice.updatefollowlead(STRUSERID, CUSTID, RESPONSE, REMARKS, BRANCH, NEXTCALLDATE, CALLID, CALLTYPE, usercode, AccountNo, Amount, Collectiondate, colectionmode, jointvisit, jointcode, Endtime, Totime)
      .then((res:any)=> {
debugger

        // this.hidespin();
        console.log(res);
        var response = res.data;
        response = JSON.parse(response);
       this.loader.dismissLoading()
        // response = JSON.parse(response);
        if (response !== '') {
          //alert("address")
          console.log(CUSTID, latvalue, langvalue, address, purposeid, CUSTID)
          // this.showspin();
          this.Apiservice.saveaddress(CUSTID, latvalue, langvalue, address, purposeid, CUSTID)
            .then((res:any)=>

              {
                debugger
                console.log(res)
                var response = res.data;
                response = JSON.parse(response);
                // response = JSON.parse(response);
                if (response == "Yes") {
                  window.localStorage['LEADCRMCallID']=""
                  console.log(response)
                  // var alertPopup = $ionicPopup.alert({
                  //   title: 'Success',
                  //   template: 'Saved Successfully'
                  // });
                  
                  // this.Alertservice.presentAlert('Success',"Saved Successfully");
                  this.flwsave()
                  // this.modelDissmiss()
                  // alertPopup.then(function(res) {
                  //   this.UpdateModal.hide();   cmd by sijin
// this.route.navigate(['/followup-leads'])
// this.followuplead()
                  // });
                }
              }).catch((err)=>{
                // this.hidespin();
              })

        } else {
          // var alertPopup = $ionicPopup.alert({
          //   title: 'Error',
          //   template: 'Error While Saving'
          // });
          this.savebool=false
          this.Alertservice.presentAlert('Error',"Error While Saving");
          // alertPopup.then(function(res) {
          //   this.UpdateModal.hide();

          // });
        }

        /* var alertPopup = $ionicPopup.alert({
           title: 'Success',
           template: 'Saved Successfully'



         });


         alertPopup.then(function(res) {
           this.UpdateModal.hide();

           // Custom functionality....
         });*/
        this.mylead.JointVisit = '';
        this.mylead.jointcode = '';
        this.mylead.jointusername = '';


        // this.display();


        /* this.myfollowupcallsdata();*/
      },err=>{
        this.savebool=false
        this.AlertService.presentAlert("",err.status)
      })

     

    // this.UpdateModal.hide();
  } else {
    console.log("calltype is not personal  visit");

    // 1819 0 1 null 452   37883458 T 1742 null null null null null null null null
    // this.showspin();
    console.log(STRUSERID, CUSTID, RESPONSE, REMARKS, BRANCH, NEXTCALLDATE, CALLID, CALLTYPE, usercode, AccountNo, Amount, Collectiondate, colectionmode, jointvisit, jointcode, Endtime, Totime)
    this.loader.presentLoading('')
    this.savebool=true
    this.Apiservice.updatefollowlead(STRUSERID, CUSTID, RESPONSE, REMARKS, BRANCH, NEXTCALLDATE, CALLID, CALLTYPE, usercode, AccountNo, Amount, Collectiondate, colectionmode, jointvisit, jointcode, Endtime, Totime)
      .then((response:any)=> {
        debugger
        this.savebool=false
        this.loader.dismissLoading()
        // this.hidespin();
        console.log(response);
        var response = response.data;
                response = JSON.parse(response);
              
                // this.loader.dismissLoading()
                // response = JSON.parse(response);
                if (response == "Yes") {
        // response = JSON.parse(response);
        //                //   response = JSON.parse(response);
        //             var success=[];
        //              success = response;
        //              if (success[0].response == 1) {


        //                 var alertPopup = $ionicPopup.alert({
        //       title: "",
        //       template: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + success[0].Column1
        //   });

        //     alertPopup.then(function (res) {
        //        this.UpdateModal.hide();
        //     // Custom functionality....
        // });

        //             }


        // var alertPopup = $ionicPopup.alert({
        //   title: 'Success',
        //   template: 'Saved Successfully'



        // });

        // this.Alertservice.presentAlert('Success',"Saved Successfully");
        this.flwsave()
        // this.modelDissmiss()
        // alertPopup.then(function(res) {
        //   this.UpdateModal.hide(); //cmd by sijin
 
        //   // Custom functionality....
        // });
        this.mylead.JointVisit = '';
        this.mylead.jointcode = '';
        this.mylead.jointusername = '';


        // this.display();

                }else{
                  this.savebool=false
                  // this.Alertservice.presentAlert('Success',response);
                  this.flwsstatusmethod(response)
                }
        /* this.myfollowupcallsdata();*/
      })

      .catch((response)=> {
        this.savebool=false
        console.log(response);
        // this.hidespin();
      });

    // this.UpdateModal.hide();

  }
  //     callAPI.updatefollowcalls(STRUSERID, CUSTID, RESPONSE, REMARKS, BRANCH, NEXTCALLDATE, CALLID, CALLTYPE, usercode, AccountNo, Amount, Collectiondate, colectionmode, jointvisit, jointcode, Endtime, Totime,depositVal,casaVal,AdvanceVal,InsuranceVal)
  //       .success(function(response) {
  //         this.hidespin($ionicLoading);
  //         console.log(response);
  //         // response = JSON.parse(response);
  //         //                //   response = JSON.parse(response);
  //         //             var success=[];
  //         //              success = response;
  //         //              if (success[0].response == 1) {


  //         //                 var alertPopup = $ionicPopup.alert({
  //         //       title: "",
  //         //       template: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + success[0].Column1
  //         //   });

  //         //     alertPopup.then(function (res) {
  //         //        this.UpdateModal.hide();
  //         //     // Custom functionality....
  //         // });

  //         //             }


  //         var alertPopup = $ionicPopup.alert({
  //           title: 'Success',
  //           template: 'Saved Successfully'



  //         });


  //         alertPopup.then(function(res) {
  //           this.UpdateModal.hide();

  //           // Custom functionality....
  //         });
  // this.mylead.JointVisit = '';
  // this.mylead.jointcode='';
  // this.mylead.jointusername='';


  //         this.display();


  //        /* this.myfollowupcallsdata();*/
  //       })

  //       .error(function(response) {
  //         console.log(response);
  //         this.hidespin($ionicLoading);
  //       });

  // this.UpdateModal.hide();
}else{
  this.savebool=false
  // var CUSTID = window.localStorage['CustomerId'];
  if(this.mylead.type == 11){
    console.log(this.mylead.customerid)
if((this.mylead.type == 11 && this.mylead.customerid=='') || (this.mylead.type == 11 && this.mylead.customerid==undefined)){
this.AlertService.presentAlert("","Enter CustomerId")
}else{
  this.validateCustID(this.mylead.customerid)
}


    
  }else{
    this.saveLeadConversion();
  }
}
}

async followuplead(){
  debugger
  const modal = await this.modalController.create({
    component: FollowupLeadsPage,
    componentProps: { Data: '' }
    });
    return await modal.present();
}
validateCustID(obj){
  debugger
  // this.loader.presentLoading('')
  var callID = window.localStorage['CallId'];
  var custID = window.localStorage['CustomerId'];
  var BRANCH = window.localStorage['branchID'];
  var STRUSERID = window.localStorage['userID'];
  var txtId = obj;
  if(obj != undefined || obj != 'undefined' || obj != null ){
    // this.showspin();
    this.Apiservice.getcustomerdetails(txtId)
      .then((res:any)=> {
        debugger
        // this.hidespin();
       var response = JSON.parse(res.data);
        response = JSON.parse(response);
        this.myleadcustomerdata = JSON.parse(response);
        
        console.log(this.myleadcustomerdata)
        if(this.myleadcustomerdata.length != 0)
        {
          this.branch= this.myleadcustomerdata[0].NBranch; 
        }else{
          this.branch= 0;
        }
        //this.branch= this.myleadcustomerdata[0].NBranch; 
        this.Apiservice.custIDValidate(custID,callID,txtId,this.branch,BRANCH,STRUSERID)
        .then((res:any)=> {
          debugger
          console.log(res)
          var response = JSON.parse(res.data);
          this.vaildResp= JSON.parse(response)
          // this.loader.dismissLoading()
          // this.hidespin($ionicLoading);
          if(this.vaildResp == 'OK'){
            console.log(this.vaildResp);
            this.saveLeadConversion();
            // this.followup.customerid = obj.CUSTOMER_ID;
            // this.mylead.customername = this.myleadcustomerdata[0].Nfirstname + ' ' + this.myleadcustomerdata[0].Nlastname;
            // window.localStorage['customerName'] = this.mylead.customername;
            // this.mylead.firstname = this.myleadcustomerdata[0].Nfirstname;
            // this.mylead.lastname = this.myleadcustomerdata[0].Nlastname;
            // this.mylead.mobile = this.myleadcustomerdata[0].Nmobile;
            // this.mylead.resphnno = this.myleadcustomerdata[0].Nresidencephone;
            // this.mylead.email = this.myleadcustomerdata[0].Nemail;



            // this.firstWords = [];

            // var firstname = [];

            // if (this.myleadcustomerdata.length > 0) {
            //   this.showspin();
            // }
            // for (i = 0; i < this.myleadcustomerdata.length; i++) {

            //   firstname = this.myleadcustomerdata[i].Nfirstname.split(" ");

            //   this.firstWords.push(firstname[0]);
            //   this.myleadcustomerdata[i].firstname = this.firstWords[i];
            //   this.firstname1 = this.myleadcustomerdata[i].firstname;
            //   if (i == this.myleadcustomerdata.length - 1) {
            //     this.hidespin();
            //   }
            // }

            // console.log(this.myleadcustomerdata[0].Add1);
            // if(this.myleadcustomerdata[0].Add1 != undefined || this.myleadcustomerdata[0].Add2 != undefined || this.myleadcustomerdata[0].Add3 != undefined || this.myleadcustomerdata[0].Add4 != undefined || this.myleadcustomerdata[0].PIN != undefined){
            //   var respAdd1= this.myleadcustomerdata[0].Add1;
            //   var add1 = respAdd1.replace("/", "-");
            //   console.log(add1);
            //   var respAdd2= this.myleadcustomerdata[0].Add2;
            //   var add2 = respAdd2.replace("/", "-");
            //   console.log(add2);
            // this.mylead.addressname = add1+' '+add2+' '+this.myleadcustomerdata[0].Add3+' '+this.myleadcustomerdata[0].Add4+' '+this.myleadcustomerdata[0].PIN;
            // console.log(this.mylead.addressname);
            // }
            // if(this.mylead.addressname != "" && this.mylead.addressname != undefined)
            // { 
            //   console.log(this.mylead.addressname);
            // this.myvalue = true;
            // //this.data.selectele='P';
            // this.setlatlong(this.mylead.addressname);
            // }
          }else{
            // this.hidespin();
            // var alertPopup = $ionicPopup.alert({
            //   title: "",
            //   template: this.vaildResp
            // });
            this.Alertservice.presentAlert("",this.vaildResp);
            // alertPopup.then(function(res) {
            //   this.UpdateModal.hide();     by sijin
          
            // });
            
          }
         
        })
        
        .catch((response)=> {
          console.log(response);
          // this.hidespin($ionicLoading);
        });
       
      // }
      })
      .catch( (response)=> {
        console.log(response);
        // this.hidespin();
      });
    }

}

saveLeadConversion() {
  debugger
  // this.loader.presentLoading('')
  var usercode = window.localStorage['userCode'];
  var username = window.localStorage['userName'];
  var BRANCH = window.localStorage['branchID'];
  var STRUSERID = window.localStorage['userID'];
  var purpose = window.localStorage['PurposeID'];
  console.log(purpose);
 console.log(this.mylead.calloutcome)
  // this.showspin($ionicLoading);
  debugger
  if(this.mylead.calloutcome == undefined || this.mylead.calloutcome == null || this.mylead.calloutcome == 'null' || this.mylead.calloutcome == 'undefined'){
    // var myPopup = $ionicPopup.show({
    //   template: '<center>Provide Call OutCome Details</center>',
    //   title: "",
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // this.hidespin($ionicLoading);
    this.Alertservice.presentAlert("","Provide Call OutCome Details");
      return false;
  }
  var prodctType='';
  var purpose = window.localStorage['PurposeID'];
  var firstName1 = this.mylead.firstname;
  var LastName1 = this.mylead.lastname;
  var mobile1 = this.mylead.mobile;
  var email1 = this.mylead.email;
  var CALLTYPE = this.mylead.calltype;
  var REMARKS1 = this.mylead.remarks;
  var RESPONSE = this.mylead.calloutcome;
  var CALLID1 = window.localStorage['CallId'];
//  var CUSTID = window.localStorage['CustomerId'];
  // this.mylead.addressname=  window.localStorage['addressName'];
  console.log(this.mylead.addressname)
 console.log(RESPONSE)
  if(this.mylead.customerid == undefined){
    var CUSTID = window.localStorage['CustomerId'];
  }else{
    CUSTID = this.mylead.customerid;
  }

  if (CALLID1 == "") {

    var CALLID = null;
  } else {
    var CALLID = CALLID1;
  }


  if (REMARKS1 == "") {

    var REMARKS = null;
  } else {
    var REMARKS = REMARKS1;
  }

 

  if (mobile1 == "" || mobile1 == undefined ) {

    var mobile = null;
  } else {
    var mobile = mobile1;
  }
  if(this.mylead.type == undefined || this.mylead.type == null || this.mylead.type == 'null' || this.mylead.type == 'undefined'){
   
    this.Alertservice.presentAlert("","Select Product Type");
      return false;
  }else{
    var prodctType:string = this.mylead.type;
  }
  if ( prodctType == "12") {

    if (this.mylead.prodGroup == "" || this.mylead.prodGroup == undefined || this.mylead.prodGroup == null) {
     
      this.Alertservice.presentAlert("","Provide Product Group Details");
      return false;


    } else {

      if(this.mylead.prodGroup == '6'){
        var productGroup=this.mylead.prodGroup
        this.textproductgroup="Life Insurance"

      }else if(this.mylead.prodGroup == '7'){
        var productGroup= this.mylead.prodGroup
        this.textproductgroup= "General Insurance"
      }else if(this.mylead.prodGroup == '8'){
      var productGroup=this.mylead.prodGroup 
      this.textproductgroup= "Health Insurance"

      }else{
        productGroup=0 
        this.textproductgroup= 0
      }

      
      // var productGroup = this.mylead.prodGroup;
    }

  }else{
   productGroup= 0
   this.textproductgroup=0
   
  }

  if(prodctType == '12'){
    if(this.mylead.selectedCompany == '' || this.mylead.selectedCompany == undefined || this.mylead.selectedCompany == null){
      this.AlertService.presentAlert("","Select Company Type")
      return false
    }else{
      var companytype=this.mylead.selectedCompany
    }
  
    
    }else{
      var companytype:any=0
    }



 
  if(prodctType == "12"  ){
    // && this.mylead.prodGroup == '6'
    if(this.mylead.plan == undefined || this.mylead.plan == null || this.mylead.plan == ''){
     
      this.Alertservice.presentAlert("","Provide Terms");
      return false;
    }else{
      var plans = this.mylead.plan;
    }
    
  }else{
    var plans:any = 0;
    
  }


  if(prodctType == "12"  ){
    // && this.mylead.prodGroup == '6'
    if(this.mylead.selectedterm == undefined || this.mylead.selectedterm == null || this.mylead.selectedterm == ''){
     
      this.Alertservice.presentAlert("","Provide Terms");
      return false;
    }else{
      var terms = this.mylead.selectedterm;
    }
    
  }else{
    var terms:any = 0;
    
  }
  if(prodctType == "12"  ){
    // && this.mylead.prodGroup == '6'
    if(this.mylead.selectedProduct == undefined || this.mylead.selectedProduct == null || this.mylead.selectedProduct == ''){
     
      // this.Alertservice.presentAlert("","Provide Product category");
      // return false;
      var productcategory = this.mylead.selectedProduct 
    }else{
      var productcategory = this.mylead.selectedProduct 
    }
    
  }else{
    productcategory = 0
    
  }

//  if (prodctType == '12') {

//     if (this.mylead.premiumAmount == "" || this.mylead.premiumAmount == undefined || this.mylead.premiumAmount == null) {
      
//       this.Alertservice.presentAlert("","Provide premium Amount Details");
//       return false;


//     } else {
      
//       var premiumAmount = this.mylead.premiumAmount;
//     }

//   }else{
//     var premiumAmount:any = 0;
//   }


  if(prodctType == "12"){
    // if(this.mylead.feeIncome == undefined || this.mylead.feeIncome == null  || this.mylead.feeIncome == ''){
    //   this.Alertservice.presentAlert("","Provide feeincome");
    //   return false;
    // }else{
      var feeIncome:any = this.mylead.feeIncome;
    }
    
  else{
    var feeIncome:any = 0;
  }
  if(prodctType == "12"  ){
    // && this.mylead.prodGroup == '6'
    if(this.mylead.plannum == undefined || this.mylead.plannum == null || this.mylead.plannum == ''){
     
      // this.Alertservice.presentAlert("","Provide Plan Number Details");
      // return false;
      var planNumber=0
    }else{
      var planNumber = 0
    }
    
  }else{
     planNumber= 0;
    
  }
 



 
  if(this.mylead.type == '13' && this.mylead.prodGroup == '14')
  {
    if(this.mylead.sumAssured == undefined || this.mylead.sumAssured == null){
     
      this.Alertservice.presentAlert("","Enter LockerNumber");
      return false;
    }else{
      var PolicyAmount = this.mylead.sumAssured;
    }
    
  }else{
    var PolicyAmount:any = 0;
  }

  if(this.mylead.type == '13' && this.mylead.prodGroup == '12')
  {
    if(this.mylead.sumAssured == undefined || this.mylead.sumAssured == null){
     
      this.Alertservice.presentAlert("","Enter CustomerID");
      return false;
    }else{
      var PolicyAmount = this.mylead.sumAssured;
    }
    
  }else{
    var PolicyAmount:any = 0;
  }
  if(this.mylead.type == '13' && this.mylead.prodGroup == '11')
  {
    if(this.mylead.sumAssured == undefined || this.mylead.sumAssured == null){
     
      this.Alertservice.presentAlert("","Enter Trading Code");
      return false;
    }else{
      var PolicyAmount = this.mylead.sumAssured;
    }
    
  }else{
    var PolicyAmount:any = 0;
  }
  if(this.mylead.type == '13' && this.mylead.prodGroup == '10')
  {
    if(this.mylead.sumAssured == undefined || this.mylead.sumAssured == null){
     
      this.Alertservice.presentAlert("","Enter Terminal ID");
      return false;
    }else{
      var PolicyAmount = this.mylead.sumAssured;
    }
    
  }else{
    var PolicyAmount:any = 0;
  }




  if (purpose == "3") {
    if (this.mylead.deposits == 0 && this.mylead.casa == 0 && this.mylead.advance == 0 && this.mylead.insurance == 0) {
     
      this.Alertservice.presentAlert("","Fill Details Of Expected Business");
      return false;
    } else {
      var casaVal = this.mylead.casa;
      var depositVal = this.mylead.deposits;
      var AdvanceVal = this.mylead.advance;
      var InsuranceVal = this.mylead.insurance;
      // var insuranceType = this.mylead.InsuranceType;
      var insuranceType=0;
      // var insurancesource = this.mylead.Insurance_Source;
      var insurancesource =0;
      // var insuranceRefer = this.mylead.referredby;
      var insuranceRefer=0;
      // var insuranceRelation = this.mylead.ReffRelation;
      var insuranceRelation=0;
    }

  }
console.log(this.mylead.deposits)
  if (this.mylead.deposits != undefined || this.mylead.casa != undefined || this.mylead.advance != undefined || this.mylead.insurance != undefined || this.mylead.deposits != "" ||this.mylead.casa != "" || this.mylead.advance != "" || this.mylead.insurance != "") {

    var casaVal = this.mylead.casa;
    var depositVal = this.mylead.deposits;
    var AdvanceVal = this.mylead.advance;
    var InsuranceVal = this.mylead.insurance;
    // var insuranceType = this.mylead.InsuranceType;
    var insuranceType=0;
    // var insurancesource = this.mylead.Insurance_Source;
    var insurancesource =0
    // var insuranceRefer = this.mylead.referredby;
    var insuranceRefer =0
    // var insuranceRelation = this.mylead.ReffRelation;
    var insuranceRelation=0
  } else {
     casaVal = 0;
     depositVal = 0;
     AdvanceVal = 0;
     InsuranceVal = 0;
    insuranceType = 0;
    insurancesource = 0;
    insuranceRefer = 0;
    insuranceRelation = 0;
  }
debugger
  if(firstName1 == undefined || firstName1 == ''){
    var firstName = null;
  }else{
    var firstName = firstName1.replace('/','');
  }

  if(LastName1 == undefined || LastName1 == ''){
    var LastName = null;
  }else{
    var LastName = LastName1.replace('/','');
  }

  if(email1 == undefined || email1 == ''){
    var email = null;
  }else{
    var email = email1;
  }


  if(prodctType =='13' && this.mylead.prodGroup =='11' || prodctType =='12')
  {
    if (this.mylead.opendate == "" || this.mylead.opendate == undefined || this.mylead.opendate == null) {
     
      this.Alertservice.presentAlert("","Provide A/C Opening Date");
      return false;


    } else {
     
      this.nextcalldate1 =  moment(this.mylead.opendate).format('YYYY-DD-MM');
      // this.datepipe.transform(this.mylead.opendate, 'yyyy-MM-dd')
      // moment(this.mylead.opendate).format('YYYY-MM-DD');
      // this.nextcalldate1 = $filter('date')(this.mylead.opendate, 'yyyy-dd-MM');
      var opendate = this.nextcalldate1;
    }
  }else{
    var opendate:string = null;
  }
  if(prodctType =='13' && this.mylead.prodGroup =='10' || prodctType =='12')
  {
    if (this.mylead.opendate == "" || this.mylead.opendate == undefined || this.mylead.opendate == null) {
      
      this.Alertservice.presentAlert("","Provide Installation Date");
      return false;


    } else {
     
      this.nextcalldate1 =  moment(this.mylead.opendate).format('YYYY-DD-MM');
     
      var opendate = this.nextcalldate1;
    }
  }else{
    var opendate:string = null;
  }



  if (prodctType == "12" && this.mylead.prodGroup == '8' || this.mylead.prodGroup == '7' || this.mylead.prodGroup == '6' || this.mylead.prodGroup == '9') {

    if (this.mylead.policyNum == "" || this.mylead.policyNum == undefined || this.mylead.policyNum == null) {
     
      this.Alertservice.presentAlert("","Provide Policy Number Details");
      return false;


    } else {
      
      this.policynum = this.mylead.policyNum
      this.policyNumber = this.policynum.split('/').join('-')
      var policyNumber = this.policyNumber;
      console.log(policyNumber);
      //var policyNumber = this.mylead.policyNum;
    }

  }else{
    var policyNumber:any = 0;
  }

  if (prodctType == "13"  && this.mylead.prodGroup == '12' || prodctType == "12") {

    if (this.mylead.premiumAmount == "" || this.mylead.premiumAmount == undefined || this.mylead.premiumAmount == null) {
      
      this.Alertservice.presentAlert("","Provide premium Amount Details");
      return false;


    } else {
      
      var premiumAmount = this.mylead.premiumAmount;
    }

  }else{
    var premiumAmount:any = 0;
  }

  


  if (prodctType == "13" ) {

    if (this.mylead.prodGroup == "" || this.mylead.prodGroup == undefined || this.mylead.prodGroup == null) {
     
      this.Alertservice.presentAlert("","Provide Product Group Details");
      return false;


    } else {
      
      productGroup = this.mylead.prodGroup;
      this.textproductgroup=0
    }

  }else{
    if(this.mylead.prodGroup == '6'){
      var productGroup=this.mylead.prodGroup 
    this.  textproductgroup= "Life Insurance"
    }else if(this.mylead.prodGroup == '7'){
      var productGroup= this.mylead.prodGroup 
      this.  textproductgroup= "General Insurance"
    }else if(this.mylead.prodGroup == '8'){
    var productGroup=this.mylead.prodGroup 
    this.  textproductgroup="Health Insurance"
    }else{
      productGroup=0
      this.  textproductgroup=0
    }
  }

  if (prodctType == "13" ) {

    if (this.mylead.prod == "" || this.mylead.prod == undefined || this.mylead.prod == null) {
     
      this.Alertservice.presentAlert("","Provide Product Details")


    } else {
      
      var product = this.mylead.prod;
    }

  }else{
    var product:any = 0;
  }


//new code






  if (prodctType == "12") {

    if (this.mylead.premPayTerm == "" || this.mylead.premPayTerm == undefined || this.mylead.premPayTerm == null) {
     
      var permiumPayTerm=0

    } else {
      var permiumPayTerm=0
      // var permiumPayTerm = this.mylead.premPayTerm;
    }

  }else{
    var permiumPayTerm = 0;
  }

  if (prodctType == "12") {

    if (this.mylead.premPaymode == "" || this.mylead.premPaymode == undefined || this.mylead.premPaymode == null) {
     

      var permiumPayMode=0
    } else {
      
      // var permiumPayMode = this.mylead.premPaymode;
      var permiumPayMode=0
    }

  }else{
    var permiumPayMode= 0;
  }

  if (prodctType == "12") {

    if (this.mylead.referredby == "" || this.mylead.referredby == undefined || this.mylead.referredby == null) {
     
      var insuranceRefer=0

    } else {
      var insuranceRefer=0
      //  var insuranceRefer = this.mylead.referredby;
    }

    if (this.mylead.InsuranceType == "" || this.mylead.InsuranceType == undefined || this.mylead.InsuranceType == null) {
      
      insuranceType=0


    } else {
      
       insuranceType = 0;
    }

    if (this.mylead.Insurance_Source == "" || this.mylead.Insurance_Source == undefined || this.mylead.Insurance_Source == null) {
     
      insurancesource =0

    } else {
      
      //  var insurancesource = this.mylead.Insurance_Source;
      var insurancesource =0
    }

    if (this.mylead.Insurance_Source == 3&&(this.mylead.ReffRelation == "" || this.mylead.ReffRelation == undefined || this.mylead.ReffRelation == null)) {
     
      var insuranceRelation=0

    } else {
      
      //  var insuranceRelation = this.mylead.ReffRelation;
      var insuranceRelation=0
    }


    // var insuranceRefer = this.mylead.referredby;
    var insuranceRefer=0
    // var insuranceRelation = this.mylead.ReffRelation;
    var insuranceRelation=0

  }else{
     insuranceRefer= 0;
     insuranceRelation = 0;
     insurancesource= 0;
     insuranceType = 0;
  }

  if(prodctType == "11" && CUSTID == 0){
   
    this.Alertservice.presentAlert("","Provide Vaild Customer ID")
    return false;
  }


var todate = null;
var premiumType= 0;
var functionID= 1
var stripaddress = 0;
var jointid=0;
 casaVal = 0;
 depositVal = 0;
 AdvanceVal = 0;
 InsuranceVal = 0;
console.log(CALLTYPE,CUSTID,planNumber,PolicyAmount,feeIncome,CALLID,productGroup,prodctType,depositVal,casaVal,AdvanceVal,InsuranceVal,BRANCH,firstName,LastName,email,mobile,usercode,product,REMARKS,opendate,policyNumber,premiumAmount,permiumPayTerm,permiumPayMode,STRUSERID,jointid);
if(LastName=='.'){
  LastName = null;
}

if(this.termproductid == '' || this.termproductid == undefined){
  this.termproductid=0
}
// CALLTYPE,CUSTID,planNumber,PolicyAmount,feeIncome,CALLID,productGroup,prodctType,depositVal,casaVal,AdvanceVal,InsuranceVal,BRANCH,firstName,LastName,email,mobile,usercode,product,REMARKS,opendate,policyNumber,premiumAmount,permiumPayTerm,permiumPayMode,STRUSERID,jointid+'_'+insuranceType+'_'+insurancesource+'_'+insuranceRelation+'_'+insuranceRefer
// T/4845901/0/35/0/37872227/14/13/null/null/null/null/452/KARTHIKEYAN/S/SKARTHIK432@GMAIL.COM/9688790941/8389/94/Test/2022-15-11/12/3677/0/0/7946/0_0_0_0_0
this.loader.presentLoading('')
this.savebool=true
this.Apiservice.saveLeadConversionNew(CALLTYPE,CUSTID,planNumber,PolicyAmount,feeIncome,CALLID,productGroup,prodctType,
  depositVal,casaVal,AdvanceVal,InsuranceVal,BRANCH,firstName,
  LastName,email,mobile,usercode,product,REMARKS,opendate,policyNumber,premiumAmount,permiumPayTerm,permiumPayMode,
  STRUSERID,jointid+'_'+insuranceType+'_'+insurancesource+'_'+insuranceRelation+'_'+insuranceRefer+'_'+productcategory+'_'+this.termproductid+'_'+
  plans+'_'+companytype+'_'+this.textproductgroup)
.then((res)=> {
  this.loader.dismissLoading()
  debugger
  
this.savebool=false


console.log(res)
var response = JSON.parse(res.data);

this.flwsstatusmethod(response)

},err=>{
  debugger
  this.loader.dismissLoading()
  this.savebool=false
  this.AlertService.presentAlert("",err.status)
})



}

setlatlong(addressname) {
  console.log(addressname);

    var geocoder = new google.maps.Geocoder();
    geocoder.geocode( { 'address': addressname}, function(resp, status) {
    if (status == 'OK') {

    console.log(resp)
    this.BranchLatLong = resp[0].geometry.location.lat() + ',' + resp[0].geometry.location.lng();
    console.log(this.BranchLatLong)

    this.lat1 = resp[0].geometry.location.lat();
    console.log(this.lat1);
    this.lng1 = resp[0].geometry.location.lng();
    console.log(this.lng1);
    this.addbaselocno = (this.lat1) + "," + (this.lng1);
     this.typeshowmap1(resp[0])
    }
  })

}


startNavigationrootleads(obj)
{
  console.log(obj);
   this.DisLat = obj.LatValue;
   console.log(this.DisLat);
    this.DisLong = obj.LongValue;
   console.log(this.DisLong);
  var latlongvaluedestination = obj.LatValue + ',' + obj.LongValue;
  console.log(latlongvaluedestination);
  // $rootScope.url = $sce.trustAsResourceUrl('https://www.google.com/maps/embed/v1/directions?key=AIzaSyDGQhzcQYbQf9E7dzGUz-R7BVp2iFeNLfI&origin=' + window.localStorage['curntlatlngvallead'] + '&destination=' + latlongvaluedestination);
  // $state.go('app.LeadMap');
}
async flwsave(){
  const alert:any = await this.alert.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Saved Successfully",
    buttons: [{ text     : 'Ok',
   
    
    handler: () => {
      this.savebool=false
     this.modelDissmiss()
    }
  },
  ]
  });
  await alert.present();
}
async flwsstatusmethod(msg){
  const alert:any = await this.alert.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: msg,
    buttons: [{ text     : 'Ok',
   
    
    handler: () => {
      this.savebool=false
     this.modelDissmiss()
    }
  },
  ]
  });
  await alert.present();
}



validatepolicy(pnum){
  debugger

// sriramleng 19
if(this.mylead.selectedCompany == 'SHRIRAM GENERAL'){ 
if(pnum.length == 19){
  var ccc={
    PolicyNumber:pnum
  }
  
    this.Apiservice.PolicyNumberValidate(ccc).then((res:any)=>{
      debugger
      // JSON.parse(res.data)
     if(JSON.parse(res.data) == 'Policy Number Already Exist'){
       this.mylead.policyNum=''
       this.AlertService.presentAlert("",JSON.parse(res.data))
       return false
     }
    })
}else{
  this.mylead.policyNum=''
  this.AlertService.presentAlert("","Policy Number Should be 19 digits")
  return false
}   
}else if(this.mylead.selectedCompany == 'ROYAL SUNDARAM GENERAL' || this.mylead.selectedCompany == 'ADITYA BIRLA HEALTH'){
  if(pnum.length == 16){
    var ccc={
      PolicyNumber:pnum
    }
    
      this.Apiservice.PolicyNumberValidate(ccc).then((res:any)=>{
        debugger
        // JSON.parse(res.data)
       if(JSON.parse(res.data) == 'Policy Number Already Exist'){
         this.mylead.policyNum=''
         this.AlertService.presentAlert("",JSON.parse(res.data))
         return false
       }
      })
  }else{
    this.mylead.policyNum=''
  this.AlertService.presentAlert("","Policy Number Should be 16 digits")
return false
  }
}else{
  var ccc={
    PolicyNumber:pnum
  }
  
    this.Apiservice.PolicyNumberValidate(ccc).then((res:any)=>{
      debugger
      // JSON.parse(res.data)
     if(JSON.parse(res.data) == 'Policy Number Already Exist'){
       this.mylead.policyNum=''
       this.AlertService.presentAlert("",JSON.parse(res.data))
       return false
     }
    })
}



}

}

