import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MonthlyuserdetailsPageRoutingModule } from './monthlyuserdetails-routing.module';

import { MonthlyuserdetailsPage } from './monthlyuserdetails.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MonthlyuserdetailsPageRoutingModule
  ],
  declarations: [MonthlyuserdetailsPage]
})
export class MonthlyuserdetailsPageModule {}
