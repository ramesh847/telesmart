import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MonthlyplannernpacallPage } from './monthlyplannernpacall.page';

describe('MonthlyplannernpacallPage', () => {
  let component: MonthlyplannernpacallPage;
  let fixture: ComponentFixture<MonthlyplannernpacallPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MonthlyplannernpacallPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MonthlyplannernpacallPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
