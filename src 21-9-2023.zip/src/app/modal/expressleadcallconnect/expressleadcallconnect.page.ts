import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController } from '@ionic/angular';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import * as moment from "moment"; 

@Component({
  selector: 'app-expressleadcallconnect',
  templateUrl: './expressleadcallconnect.page.html',
  styleUrls: ['./expressleadcallconnect.page.scss'],
})
export class ExpressleadcallconnectPage implements OnInit {
  express:any={};
  endDate: string;
  currDate: string;
  repStatus: any;
  statusResp: any;
  clickcallID: any;
  interval: any;
  res: any;
  resout: any;
  ClickAccess: boolean;
  accessResp: any;
  customeractiondata: any;
  enable: boolean;
  customerid: any;
  expressLeadcustomerdata: any;
  firstWords: any[];
  firstname1: any;
  myvalue: boolean;
  provider: any;
  location: any;
  voicerecording: any;
  status: string;
  status2: string;
  rowid: any;
  clickid: any;
  getcaller:any;
  getcustomer:any;
  constructor(private AlertService:AlertServiceService,private alert:AlertController,
    private modalController:ModalController,private apiservice:ApiServiceService,
  public route:Router) { }

  ngOnInit() {
    debugger
    let Cusdata = this.apiservice.expressleadarray[0]
    console.log(Cusdata);
    this.callNumber(Cusdata);
    this.clickCallAccess();
  }
  clicknumberstar(num:any,status)
  {
    debugger
    if(status == 'ca'){
      this.getcaller= this.apiservice.firstfivexxxx(num)
    }else
    {
      this.getcustomer= this.apiservice.firstfivexxxx(num)
  
  }
}
  clickCallAccess(){
    var userid = window.localStorage['userID'];
    this.apiservice.AccesstoClick(userid)
    .then((res)=> {
      console.log(res)
      var response =  JSON.parse(res.data)
      this.accessResp= JSON.parse(response)
      // this.hidespin($ionicLoading);
      if(this.accessResp == 'A'){
        console.log(this.accessResp);
        this.ClickAccess =true;
      }else{
        this.ClickAccess =false;
      }
     
    })
    
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin($ionicLoading);
    // });
  }



  clickcall:any={};
  item:any = '';
  callNumber(item){
    debugger
    console.log(item);
    this.item = item;
    this.clickcall.callerName=window.localStorage['userName'];
    this.clickcall.callermobile=window.localStorage['mobile'];
    // window.localStorage['mobile'];
    this.clickcall.customerName=item.CUSTOMERNAME;
    this.clickcall.customerMobile= item.MOBILE;
    // item.MOBILE;
    this.clickcall.customerId=item.CBSCUSTOMERID;
    this.clickcall.endDate='';
    var purpose = "Express Lead";
    var currentDate= new Date();
    // this.clickcall.currDate = $filter('date')(currentDate, 'yyyy-MM-dd hh-mm-ss');
    // console.log(this.currDate);
    this.clickcall.currDate = moment(currentDate).format('YYYY-MM-DD h.mm a');
    // this.followuptime = moment(this.data.followuptime).format('h.mm a');
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    if(this.clickcall.callermobile =='' || this.clickcall.callermobile ==undefined || this.clickcall.callermobile ==null ){
      this.AlertService.presentAlert("","CallerNumber Not Available")
    }else if(this.clickcall.customerMobile =='' || this.clickcall.customerMobile ==undefined || this.clickcall.customerMobile ==null ){
     this.AlertService.presentAlert("","CustomerNumber Not Available") 
   }else{
    this.apiservice.endcallnrewfunction(branchid,userid,this.clickcall.callermobile,this.clickcall.customerMobile).then((res:any)=>{
      this.rowid=JSON.parse(JSON.parse(res.data))
     
     
         this.apiservice.clickToCallCustomer(this.clickcall.callermobile,this.clickcall.customerMobile,this.rowid)
         .then((response)=> {
           debugger
           console.log(response)
           // this.hidespin($ionicLoading);
           // debugger
           this.res = JSON.parse(response.data);
           this.resout = JSON.parse(this.res);
           this.resout = JSON.parse(this.resout);
           // console.log(resout)
           // debugger
           if(this.resout.status == "200"){
             // debugger
             this.clickcallID = this.resout.data;
             this.apiservice. autoclicktocallupdate(  this.clickcall.customerId,  this.clickcall.customerName,  this.clickcallID.id,  this.rowid, purpose).then((res:any)=>{
              debugger
                           })
             this.callinterval();
     
             
     
            
           }else{
          
           this.AlertService.presentAlert("",this.resout.message)
          
           }
     
     
         },err=>{
           if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
         })
       })
   }


    
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin($ionicLoading);
    // });

  }

  callinterval(){
    // alert()
  this.interval = setInterval(() => {
this.callResp();
    // clearInterval(this.interval)
  }, 10000);
  }
  stopCall(){
    clearInterval(this.interval)
  }

  EndCallobj:any={};
  callResp(){
    debugger
    console.log(this.clickcallID.id);
    var id = this.clickcallID.id;
    this.apiservice.callStatusCustomer(id)
    .then((response:any)=> {
    //  console.log(response)
    debugger
      this.statusResp= JSON.parse(response.data)
      this.repStatus = JSON.parse(this.statusResp);
      this.repStatus = JSON.parse(this.repStatus);
      // debugger
      // this.hidespin($ionicLoading);
      debugger
      console.log(this.repStatus.data.length);
      if(this.repStatus.data.length == 1){
        
if((this.repStatus.data[0].status=="NOANSWER" || this.repStatus.data[0].status=="FAILED" || this.repStatus.data[0].status=="CONGESTION") && this.repStatus.data[0].status2==null) {
  this.stopCall();
this.callresppopup(this.repStatus.data[0].status,id,"1")

}else{
        console.log(this.repStatus.data[0].status2);
      if(this.repStatus.data[0].status2 != null){
        console.log(this.repStatus.data[0]);
        if(this.repStatus.data[0].status2 == 'ANSWER'){
          debugger
          this.stopCall();
          // this.CallConnectModal.hide();
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile=window.localStorage['mobile'];
          // 
          this.EndCallobj.customerName=this.item.CUSTOMERNAME;
          this.EndCallobj.customerMobile=this.item.MOBILE;
          // this.item.MOBILE;
          this.EndCallobj.customerId=this.item.CBSCUSTOMERID;
          //this.EndCallobj.cust=this.item.custCat;
          this.EndCallobj.endStatus= 'A';
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          this.Endcall(this.EndCallobj);
          // this.expressleadpopup(this.item)
          // this.customerActionModal(this.item); by sijin
        }else{

this.stopCall()
          
this.callresppopup(this.repStatus.data[0].status2,id,"2")
         
      
        
        }
        
      }

      }
    }
    })
    
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin($ionicLoading);
    // });
  }

  callresppopup(ans,id,leg2){
    debugger
this.stopCall()
                            // <<<---using ()=> syntax
      this.apiservice.callStatusLead(id).then((res:any)=>{
  
        debugger
       res= JSON.stringify(res)
       res=JSON.parse(res)
  
       if(res !='' && res.data == '"\\"\\""'){
    this.apiservice.callStatusLead(id).then((res:any)=>{
  
      debugger
     res= JSON.stringify(res)
     res=JSON.parse(res)




    
      var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
      
      if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
        this.voicerecording='No Record'
      }else{
      this.voicerecording=xyz[0].recording.slice(28)
      }
      if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
      this.location="no record"
      }else{
        this.location=xyz[0].location
      }
      if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
        this.provider="no provider"
      }else{
        this.provider=xyz[0].provider
      }
      if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
        this.status="no status"
      }else{
       this.status=xyz[0].status
      }
      if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
        this.status2="no status"
      }else{
       this.status2=xyz[0].status2
      }
      
   debugger
   var branchid = window.localStorage['branchID'];
   var usertype = window.localStorage['userType'];
   var userid = window.localStorage['userID'];
   var purpose = 'Express Lead';
var objendcall={
  CustId :this.clickcall.customerId,
            CustName :this.clickcall.customerName,
            CustNumber :this.clickcall.customerMobile,
            strUserId :userid,
            strBranch :branchid,
            UserNumber :this.clickcall.callermobile,
            StartTime :xyz[0].start_time,
            Endtime :xyz[0].end_time,
            Purpose :purpose,
            duration :xyz[0].duration,
            bill :xyz[0].billsec,
            credit :xyz[0].credits,
            status :this.status,
            status1 :this.status2,
            rec :this.voicerecording,
            location :this.location,
            provider :this.provider,
            callid :id,
            rowid :this.rowid
}


      this.apiservice.endcallconnectnewmethod(objendcall)
        .then((response:any)=> {
                debugger
            this.callresppopoutput(ans,leg2)
            
              },err=>{
                if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
              })
              
            
            
              }
            )
  }else{

      
        var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
        if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
          this.voicerecording='No Record'
        }else{
        this.voicerecording=xyz[0].recording.slice(28)
        }
        if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
        this.location="no record"
        }else{
          this.location=xyz[0].location
        }
        if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
          this.provider="no provider"
        }else{
          this.provider=xyz[0].provider
        }
        if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
          this.status="no status"
        }else{
         this.status=xyz[0].status
        }
        if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
          this.status2="no status"
        }else{
         this.status2=xyz[0].status2
        }
        
     debugger
     var branchid = window.localStorage['branchID'];
     var usertype = window.localStorage['userType'];
     var userid = window.localStorage['userID'];
     var purpose = 'Express Lead';
  var objendcall={
    CustId :this.clickcall.customerId,
              CustName :this.clickcall.customerName,
              CustNumber :this.clickcall.customerMobile,
              strUserId :userid,
              strBranch :branchid,
              UserNumber :this.clickcall.callermobile,
              StartTime :xyz[0].start_time,
              Endtime :xyz[0].end_time,
              Purpose :purpose,
              duration :xyz[0].duration,
              bill :xyz[0].billsec,
              credit :xyz[0].credits,
              status :this.status,
              status1 :this.status2,
              rec :this.voicerecording,
              location :this.location,
              provider :this.provider,
              callid :id,
              rowid :this.rowid
  }
  
  
        this.apiservice.endcallconnectnewmethod(objendcall)
          .then((response:any)=> {
                  debugger
              this.callresppopoutput(ans,leg2)
              
                },err=>{
                  if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                })
                
  }
              
                }
              )
 



  
  }


async callresppopoutput(ans,leg2){
  if(ans == "FAILED" && leg2 == "2"){
    const alert:any = await this.alert.create({
      header: "",
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: "Successfully Saved",
      buttons: [{ text     : 'Yes',
     
      
      handler: () => {
        this.clickcall={};
        // this.CallConnectModal.hide(); cmd by sijin
        this.stopCall();
        this.route.navigateByUrl('/express-leads')
      }
    }]  });
    await alert.present()
  }else{
  const alert:any = await this.alert.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: ans +'. would you like to update?',
    buttons: [{ text     : 'Yes',
   
    
    handler: () => {
               this.clickcall={};
            // this.CallConnectModal.hide(); sijin
            this.stopCall();
            console.log(this.item);
            this.EndCallobj.callerName=window.localStorage['userName'];
            this.EndCallobj.callerMobile=window.localStorage['mobile'];
            this.EndCallobj.customerName=this.item.CUSTOMERNAME;
            this.EndCallobj.customerMobile=this.item.MOBILE;
            this.EndCallobj.customerId=this.item.CBSCUSTOMERID;
            //this.EndCallobj.cust=this.item.custCat;
            this.EndCallobj.endStatus= 'I';
            this.EndCallobj.currDate = this.repStatus.data[0].start_time;
            this.EndCallobj.endDate = this.repStatus.data[0].end_time;
            // this.Endcall(this.EndCallobj);
            this. expressleadpopup(this.item);
            // this.expressleadpopup(this.item);
            // this.customerActionModal(this.item);
    }
  },
  { text     : 'No',
   
    
  handler: () => {
    this.clickcall={};
    // this.CallConnectModal.hide(); cmd by sijin
    this.stopCall();
    this.route.navigateByUrl('/express-leads')
  }
},]
  });
  await alert.present()
}
}
 expressleadpopup(items){
  this.apiservice.expressleadarray=[]
  this.apiservice.expressleadarray.push(items,{close:"endexpresslead"})
  this.route.navigateByUrl('/expressleadmodal')
 
}

Endcall1(obj){
  this.expressleadpopup(this.item)
}

  Endcall(obj){
    debugger
    console.log(obj);
    this.stopCall()
   
if(this.resout=='' || this.repStatus.data.length==0){
  this.expressleadpopup(this.item)
}else{

    if(this.repStatus.data[0].status2=='ANSWER'){
    this. clickid=this.clickcallID.id
    if(obj.endDate == undefined || obj.endDate == 'undefined' || obj.endDate == null || obj.endDate == ''){
      var enDate = new Date();
      //  this.endDate = $filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
       this.endDate = moment(enDate).format('YYYY-MM-DD h.mm a')
      // this.endDate = $filter('date')(enDate, 'hh-mm-ss');
      console.log(this.endDate);
      }else{
        var enDate= new Date(obj.endDate);
        this.endDate = moment(enDate).format('YYYY-MM-DD h.mm a')
        // this.endDate =$filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
        console.log(this.endDate);
      }
      var curDate= new Date(obj.currDate);
      this.currDate = moment(curDate).format('YYYY-MM-DD h.mm a')
      // this.currDate = $filter('date')(curDate, 'yyyy-MM-dd hh-mm-ss');
      console.log(this.currDate);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var purpose = 'Express Lead';
    

    
                              // <<<---using ()=> syntax
      this.apiservice.callStatusLead(this.clickid).then((res:any)=>{

        debugger
       res= JSON.stringify(res)
       res=JSON.parse(res)
    
       if(res !='' && res.data == '"\\"\\""'){
        this.apiservice.callStatusLead(this.clickid).then((res:any)=>{

          debugger
         res= JSON.stringify(res)
         res=JSON.parse(res)
      
        
      
      
          if(res ==''|| JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
           
            this.stopCall();
            // console.log($scope.item);
            this.expressleadpopup(this.item)
          }else{
          
          if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
            // $scope.clickTocallConnect.hide();
            this.stopCall();
            // console.log($scope.item);
            this.expressleadpopup(this.item)
          }else{
          
          var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
          
          if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
            this.voicerecording='No Record'
          }else{
          this.voicerecording=xyz[0].recording.slice(28)
          }
          if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
          this.location="no record"
          }else{
            this.location=xyz[0].location
          }
          if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
            this.provider="no provider"
          }else{
            this.provider=xyz[0].provider
          }
          if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
            this.status="no status"
          }else{
           this.status=xyz[0].status
          }
          if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
            this.status2="no status"
          }else{
           this.status2=xyz[0].status2
          }
          var objendcall={
            CustId :obj.customerId,
                      CustName :obj.customerName,
                      CustNumber :obj.customerMobile,
                      strUserId :userid,
                      strBranch :branchid,
                      UserNumber :obj.callerMobile,
                      StartTime :xyz[0].start_time,
                      Endtime :xyz[0].end_time,
                      Purpose :purpose,
                      duration :xyz[0].duration,
                      bill :xyz[0].billsec,
                      credit :xyz[0].credits,
                      status :this.status,
                      status1 :this.status2,
                      rec :this.voicerecording,
                      location :this.location,
                      provider :this.provider,
                      callid :this.clickid,
                      rowid :this.rowid
          }
          
          
          this.apiservice.endcallconnectnewmethod(objendcall)
            .then((response:any)=> {
                    debugger
                   
                    // obj.endStatus == 'I'
                    if(obj.endStatus == '0'){
                 
                   
        
                      this.endcallpopup()
        
                  }else{
                    debugger
                   this.clickcall={};
                         
                        this.stopCall();
                          // console.log($scope.item);
                          this.expressleadpopup(this.item)
                  }
                  },err=>{
                    if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                  })
                  
                
                }
                  }
                })
       }
    else{
    
        if(res ==''|| JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
         
          this.stopCall();
          // console.log($scope.item);
          this.expressleadpopup(this.item)
        }else{
        
        if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
          // $scope.clickTocallConnect.hide();
          this.stopCall();
          // console.log($scope.item);
          this.expressleadpopup(this.item)
        }else{
        
        var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
        if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
          this.voicerecording='No Record'
        }else{
        this.voicerecording=xyz[0].recording.slice(28)
        }
        if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
        this.location="no record"
        }else{
          this.location=xyz[0].location
        }
        if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
          this.provider="no provider"
        }else{
          this.provider=xyz[0].provider
        }
        if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
          this.status="no status"
        }else{
         this.status=xyz[0].status
        }
        if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
          this.status2="no status"
        }else{
         this.status2=xyz[0].status2
        }
        var objendcall={
          CustId :obj.customerId,
                    CustName :obj.customerName,
                    CustNumber :obj.customerMobile,
                    strUserId :userid,
                    strBranch :branchid,
                    UserNumber :obj.callerMobile,
                    StartTime :xyz[0].start_time,
                    Endtime :xyz[0].end_time,
                    Purpose :purpose,
                    duration :xyz[0].duration,
                    bill :xyz[0].billsec,
                    credit :xyz[0].credits,
                    status :this.status,
                    status1 :this.status2,
                    rec :this.voicerecording,
                    location :this.location,
                    provider :this.provider,
                    callid :this.clickid,
                    rowid :this.rowid
        }
        
        
        this.apiservice.endcallconnectnewmethod(objendcall)
          .then((response:any)=> {
                  debugger
                 
                  // obj.endStatus == 'I'
                  if(obj.endStatus == '0'){
               
                 
      
                    this.endcallpopup()
      
                }else{
                  debugger
                 this.clickcall={};
                       
                      this.stopCall();
                        // console.log($scope.item);
                        this.expressleadpopup(this.item)
                }
                },err=>{
                  if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                })
                
              
              }
                } }
              })
  
    
 

          }else{
            this.expressleadpopup(this.item)
          }
        }
  }
async endcallpopup(){
  const alert:any = await this.alert.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "You have ended the call explicitly. would you like to update?",
    buttons: [{ text     : 'Okay',
   
    
    handler: () => {
      this.clickcall={};
            // this.CallConnectModal.hide();
            this.stopCall();
            console.log(this.item);
           this. expressleadpopup(this.item);
            // this.customerActionModal(this.item);
    }
  },
  { text     : 'No',
   
    
  handler: () => {
    this.clickcall={};
    // this.CallConnectModal.hide(); cmd by sijin
    this.stopCall();
    this.route.navigateByUrl('/express-leads')
  }
},]
  });
  await alert.present()
}
  

  modelDissmiss(){
    this.alert.dismiss()
    this.modalController.dismiss();
   }

}
