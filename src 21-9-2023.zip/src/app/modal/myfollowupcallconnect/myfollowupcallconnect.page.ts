import { Component, OnInit } from '@angular/core';
import { AlertController, ModalController } from '@ionic/angular';
import { NavParams } from '@ionic/angular';
import { DatePipe } from '@angular/common';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Pipe, PipeTransform } from "@angular/core";
import { ApiServiceService } from 'src/app/service/api-service.service';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { MyfollowupcallmodalPage } from '../myfollowupcallmodal/myfollowupcallmodal.page';
import { MyfollowupvisitendmodelPage } from '../myfollowupvisitendmodel/myfollowupvisitendmodel.page';
import { Router } from '@angular/router';
@Component({
  selector: 'app-myfollowupcallconnect',
  templateUrl: './myfollowupcallconnect.page.html',
  styleUrls: ['./myfollowupcallconnect.page.scss'],
  providers: [DatePipe],
})
export class MyfollowupcallconnectPage implements OnInit {
  EndCallobj:any={}
  clickcall: any;
  callerName:any;
  callerNumber:any;
  customerNumber: any;
  customerName: any;
  purpose:any;
  clickCallId: any;
  endDate: any;
  currDate: any;
  customerId: any;
  voicerecording: string;
  result: any;
  resout: any;
  clickcallID: any;
  interval: any;
  statusResp: any;
  repStatus: any;
  location: string;
  provider: string;
  status: string;
  status2: string;
  modelget: any;
  rowid: any;
  clickid: any;
  getcaller:any;
  getcustomer:any;
  constructor(private Apiservice: ApiServiceService, public modalController: ModalController,
    private formBuilder: FormBuilder,private datepipe: DatePipe,private alert:AlertController,private AlertService:AlertServiceService,
    public route:Router) { }

    // $scope.callNumber = function(item){
    //   console.log(item);
    //   $scope.item = item;
    //   $scope.clickcall.callerName=window.localStorage['userName'];
    //   $scope.clickcall.callerMobile=window.localStorage['mobile'];
    //   $scope.clickcall.customerName=item.CustomerName;
    //   $scope.clickcall.customerMobile=item.Mobile;
    //   $scope.clickcall.customerId=item.CBSCustomerID;
    //   $scope.clickcall.purpose=item.Purpose.split('/').join('-');
    //   var currentDate= new Date();
    //   $scope.clickcall.currDate = $filter('date')(currentDate, 'yyyy-MM-dd hh-mm-ss');
    //   console.log($scope.currDate);
  
    //   callAPI.clickToCallCall($scope.clickcall.callerMobile,$scope.clickcall.customerMobile,$scope.clickcall.purpose)
    //   .success(function(response) {
    //     console.log(response)
    //     $scope.hidespin($ionicLoading);
    //     $scope.res = JSON.parse(response);
    //     $scope.resout = JSON.parse($scope.res);
    //     console.log($scope.resout)
    //     if($scope.resout.status == '200'){
    //       $scope.clickcallID = $scope.resout.data;
    //       $scope.callinterval();
    //       $scope.CallConnectModal.show();
    //     }else{
    //     var alertPopup = $ionicPopup.alert({
    //       title: 'Alert',
    //       template: response
    //     });
  
    //     alertPopup.then(function(res) {
    //     });
    //     }
  
    //   })
  
    //   .error(function(response) {
    //     console.log(response);
    //     $scope.hidespin($ionicLoading);
    //   });
  
    // }



  ngOnInit() {
debugger
    // $scope.item = item;
    // $scope.clickcall.callerName=window.localStorage['userName'];
    // $scope.clickcall.callerMobile=window.localStorage['mobile'];
    // $scope.clickcall.customerName=item.CustomerName;
    // $scope.clickcall.customerMobile=item.Mobile;
    // $scope.clickcall.customerId=item.CBSCustomerID;
    // $scope.clickcall.purpose=item.Purpose.split('/').join('-');
    // var currentDate= new Date();
    // $scope.clickcall.currDate = $filter('date')(currentDate, 'yyyy-MM-dd hh-mm-ss');
    // console.log($scope.currDate);




    this.callerName = window.localStorage['userName'];
    this.callerNumber = window.localStorage['mobile']; 
    // 
    this.clickcall = this.Apiservice.followupcallarray[0]
   
    this.customerName = this.clickcall?.CUSTOMER_NAME;
    this.customerNumber =this.clickcall?.CONTACT_NO;
    //  this.clickcall?.CONTACT_NO;
    this.customerId = this.clickcall?.CUSTOMER_ID
    ;
    
  
    console.log(this.clickcall);
 
    
    // if(this.clickcall.CONTACT_NO) {
    //   this.customerNumber = this.clickcall.CONTACT_NO;
    // }
    // if(  this.clickcall.CUSTOMER_NAME) {
    //   this.customerName = this.clickcall.CUSTOMER_NAME;
    // }
    this.purpose = "Follow Up Calls"
    console.log(this.clickcall);
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    if(this.callerNumber =='' || this.callerNumber ==undefined || this.callerNumber ==null ){
      this.AlertService.presentAlert("","CallerNumber Not Available")
    }else if(this.customerNumber =='' || this.customerNumber ==undefined || this.customerNumber ==null ){
     this.AlertService.presentAlert("","CustomerNumber Not Available") 
   }else{
    this.Apiservice.endcallnrewfunction(branchid,userid,this.callerNumber,this.customerNumber).then((res:any)=>{
      this.rowid=JSON.parse(JSON.parse(res.data))
         this.Apiservice.clickToCall(this.callerNumber,this.customerNumber,this.rowid).then(response => {
           debugger
           this.result = JSON.parse(response.data);
           this.resout = JSON.parse( JSON.parse(this.result));
           if(this.resout.status == '200'){
             this.clickcallID = this.resout.data;
             this.Apiservice. autoclicktocallupdate(  this.customerId,  this.customerName,  this.clickcallID.id,  this.rowid, this.purpose).then((res:any)=>{
              debugger
                           })
             this.callinterval();
             // this.CallConnectModal.show();
           }else{
             this.AlertService.presentAlert("",this.resout.message)
            
           }
          
         })
       })
   }


    this.clickCallAccess();
  }
  clicknumberstar(num:any,status)
  {
    debugger
    if(status == 'ca'){
      this.getcaller= this.Apiservice.firstfivexxxx(num)
    }else
    {
      this.getcustomer= this.Apiservice.firstfivexxxx(num)
  
  }}
  clickCallAccess (){
    var userid = window.localStorage['userID'];
    this.Apiservice.AccesstoClick(userid).then(res=> {
      console.log(res);
    })
    // callAPI.AccesstoClick(userid)
    // .success(function(response) {
    //   console.log(response)
    //   $scope.accessResp= JSON.parse(response)
    //   $scope.hidespin($ionicLoading);
    //   if($scope.accessResp == 'A'){
    //     console.log($scope.accessResp);
    //     $scope.ClickAccess =true;
    //   }else{
    //     $scope.ClickAccess =false;
    //   }

    // })

    // .error(function(response) {
    //   console.log(response);
    //   $scope.hidespin($ionicLoading);


    // });
  }

  modelDissmiss() {
    this.modalController.dismiss();
   
  }
  ngOnDestroy() {
    // clearInterval();

  }
 
  callResp(){
     debugger
    console.log(this.clickcallID.id);
    var id =this.clickcallID.id;
    this.Apiservice.callStatusFollowUp(id)
    .then((response:any)=> {
      debugger
    //  console.log(response)
      this.statusResp= JSON.parse(JSON.parse(JSON.parse(response.data)))
      this.repStatus = this.statusResp;
      //this.hidespin($ionicLoading);
      console.log(JSON.parse( JSON.parse(response.data)).length);
      if(this.repStatus.data.length == 1){

        if((this.repStatus.data[0].status=="NOANSWER" || this.repStatus.data[0].status=="FAILED" || this.repStatus.data[0].status=="CONGESTION") && this.repStatus.data[0].status2==null) {
          this.stopCall();
        this.callResppopup(this.repStatus.data[0].status,id)
        
        }else{
        console.log(this.repStatus.data[0].status2);
      if(this.repStatus.data[0].status2 != null){
        console.log(this.repStatus.data[0]);
        if(this.repStatus.data[0].status2 == 'ANSWER'){
          this.stopCall();
         // this.CallConnectModal.hide();
          console.log(this.currDate);
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile=window.localStorage['mobile'];
          this.EndCallobj.customerName=this.customerName;
          this.EndCallobj.customerMobile=this.customerNumber;
          this.EndCallobj.customerId=this.customerId ;
          //this.EndCallobj.purpose=this.item.purpose_id;
          this.EndCallobj.purposeText= this.purpose.split('/').join('-');
          this.EndCallobj.endStatus= 'A';
          //var currentDate= new Date();
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          this.Endcall(this.EndCallobj);
          // this.End(this.clickcall);
        }else{
         this.stopCall()
  
          this.callResppopup(this.repStatus.data[0].status2,id)
  
  
        }
        
      }
      
    }
  }
    })
    
  
  }


  callResppopup(ans,id){
    debugger
this.stopCall()
                             // <<<---using ()=> syntax
      this.Apiservice.callStatusLead(id).then((res:any)=>{
  
        debugger
       res= JSON.stringify(res)
       res=JSON.parse(res)
  
       if(res !='' && res.data == '"\\"\\""'){
    this.Apiservice.callStatusLead(id).then((res:any)=>{
  
      debugger
     res= JSON.stringify(res)
     res=JSON.parse(res)




    
      var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
      
      if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
        this.voicerecording='No Record'
      }else{
      this.voicerecording=xyz[0].recording.slice(28)
      }
      if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
      this.location="no record"
      }else{
        this.location=xyz[0].location
      }
      if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
        this.provider="no provider"
      }else{
        this.provider=xyz[0].provider
      }
      if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
        this.status="no status"
      }else{
       this.status=xyz[0].status
      }
      if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
        this.status2="no status"
      }else{
       this.status2=xyz[0].status2
      }
      
   debugger
   var branchid = window.localStorage['branchID'];
   var usertype = window.localStorage['userType'];
   var userid = window.localStorage['userID'];
   var purpose = 'Follow Up Calls';
var objendcall={
  CustId :this.customerId,
            CustName :this.customerName,
            CustNumber :this.customerNumber,
            strUserId :userid,
            strBranch :branchid,
            UserNumber :this.callerNumber,
            StartTime :xyz[0].start_time,
            Endtime :xyz[0].end_time,
            Purpose :purpose,
            duration :xyz[0].duration,
            bill :xyz[0].billsec,
            credit :xyz[0].credits,
            status :this.status,
            status1 :this.status2,
            rec :this.voicerecording,
            location :this.location,
            provider :this.provider,
            callid :id,
            rowid :this.rowid
}


      this.Apiservice.endcallconnectnewmethod(objendcall)
        .then((response:any)=> {
                debugger
            this.callresppopoutput(ans)
            
              },err=>{
                 if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
              })
              
            
            
              }
            )
  }else{

        var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
        if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
          this.voicerecording='No Record'
        }else{
        this.voicerecording=xyz[0].recording.slice(28)
        }
        if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
        this.location="no record"
        }else{
          this.location=xyz[0].location
        }
        if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
          this.provider="no provider"
        }else{
          this.provider=xyz[0].provider
        }
        if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
          this.status="no status"
        }else{
         this.status=xyz[0].status
        }
        if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
          this.status2="no status"
        }else{
         this.status2=xyz[0].status2
        }
        
     debugger
     var branchid = window.localStorage['branchID'];
     var usertype = window.localStorage['userType'];
     var userid = window.localStorage['userID'];
     var purpose = 'Follow Up Calls';
  var objendcall={
    CustId :this.customerId,
              CustName :this.customerName,
              CustNumber :this.customerNumber,
              strUserId :userid,
              strBranch :branchid,
              UserNumber :this.callerNumber,
              StartTime :xyz[0].start_time,
              Endtime :xyz[0].end_time,
              Purpose :purpose,
              duration :xyz[0].duration,
              bill :xyz[0].billsec,
              credit :xyz[0].credits,
              status :this.status,
              status1 :this.status2,
              rec :this.voicerecording,
              location :this.location,
              provider :this.provider,
              callid :id,
              rowid :this.rowid
  }
  
  
        this.Apiservice.endcallconnectnewmethod(objendcall)
          .then((response:any)=> {
                  debugger
              this.callresppopoutput(ans)
              
                },err=>{
                   if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                })
                
              
  }
                }
              )
 



  
  }


  async callresppopoutput(ans){
    debugger
    const alert = await this.alert.create({
      header: ans+' Would you like to update?',
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: '',
      buttons: [{ text     : 'Yes',
     
      
      handler:() => {
        debugger
        // this.clickcall={};
          //this.CallConnectModal.hide();
          // this.modelDissmiss()
          this.stopCall();
          console.log(this.clickcall);
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile=window.localStorage['mobile'];
          this.EndCallobj.customerName=this.customerName;
          this.EndCallobj.customerMobile=this.customerNumber;
          this.EndCallobj.customerId=this.customerId;
          //this.EndCallobj.purpose=this.item.purpose_id;
          this.EndCallobj.purposeText= this.purpose;
          this.EndCallobj.endStatus= 'I';
          //var currentDate= new Date();
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          // this.Endcall(this.EndCallobj);
          // this.End(this.clickcall);
          this.callconnect(this.clickcall)
      }
    },
    {
      text     : 'No',
     
      
      handler:() => {
        this.clickcall={};
        // this.modelDissmiss()
         // this.CallConnectModal.hide();
          this.stopCall();
          this.route.navigateByUrl('/myfollowupcall')
         //this.followupcallsUpdmodal(this.item);
      }
    }
  ]
    });
    await alert.present()
  }
  // End(obj){

  // }
  callinterval(){
    debugger
    this.interval = setInterval(() => {
      this.callResp();
          // clearInterval(this.interval)
        }, 10000);
 
    //   if ( angular.isDefined(gettimer) ) return;
    //  var gettimer =$interval( function(){ this.callResp(); }, 10000);

    
  }
  stopCall(){
    clearInterval(this.interval)
  }
  Endcall1(obj){
    this.callconnect(this.clickcall)
  }
  Endcall(obj){
    debugger
    this.stopCall()
    console.log(this.clickcall);
if(this.resout=='' || this.repStatus.data.length==0){
  this.callconnect(this.clickcall)
}else{

    if(this.repStatus.data[0].status2=='ANSWER'){
    this. clickid=this.clickcallID.id
    if(obj.endDate == undefined || obj.endDate == 'undefined' || obj.endDate == null || obj.endDate == ''){
      var enDate= new Date();
       this.endDate = this.datepipe.transform(enDate, 'yyyy-MM-dd hh-mm-ss');

      // this.endDate = $filter('date')(enDate, 'hh-mm-ss');
      console.log(this.endDate);
      }else{
        var enDate= new Date(obj.endDate);
        this.endDate = this.datepipe.transform(enDate, 'yyyy-MM-dd hh-mm-ss');
        console.log(this.endDate);
      }
      var curDate= new Date();
      this.currDate =  this.datepipe.transform(curDate, 'yyyy-MM-dd hh-mm-ss');
      console.log(this.currDate);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var purpose = "Follow Up Calls"
    // this.clickcall.Purpose;
   
                        // <<<---using ()=> syntax
  this.Apiservice.callStatusLead(this.clickid).then((res:any)=>{

    debugger
   res= JSON.stringify(res)
   res=JSON.parse(res)
  
   if(res !='' && res.data == '"\\"\\""'){
    this.Apiservice.callStatusLead(this.clickid).then((res:any)=>{

      debugger
     res= JSON.stringify(res)
     res=JSON.parse(res)
    
    
    
    
     if(res=='' || JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
       
        this.stopCall();
        // console.log($scope.item);
        this.callconnect(this.clickcall)
      }else{
      
      if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
        // $scope.clickTocallConnect.hide();
        this.stopCall();
        // console.log($scope.item);
        this.callconnect(this.clickcall)
      }else{
      
      var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
      
      if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
        this.voicerecording='No Record'
      }else{
      this.voicerecording=xyz[0].recording.slice(28)
      }
      if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
      this.location="no record"
      }else{
        this.location=xyz[0].location
      }
      if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
        this.provider="no provider"
      }else{
        this.provider=xyz[0].provider
      }
      if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
        this.status="no status"
      }else{
       this.status=xyz[0].status
      }
      if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
        this.status2="no status"
      }else{
       this.status2=xyz[0].status2
      }
      var objendcall={
        CustId :obj.customerId,
                  CustName :obj.customerName,
                  CustNumber :obj.customerMobile,
                  strUserId :userid,
                  strBranch :branchid,
                  UserNumber :obj.callerMobile,
                  StartTime :xyz[0].start_time,
                  Endtime :xyz[0].end_time,
                  Purpose :purpose,
                  duration :xyz[0].duration,
                  bill :xyz[0].billsec,
                  credit :xyz[0].credits,
                  status :this.status,
                  status1 :this.status2,
                  rec :this.voicerecording,
                  location :this.location,
                  provider :this.provider,
                  callid :this.clickid,
                  rowid :this.rowid
      }
      
      this.Apiservice.endcallconnectnewmethod(objendcall)
        .then((response:any)=> {
                debugger
            
                // obj.endStatus == 'I'
                if(obj.endStatus == '0'){
             
               
    
                  this.callconnect(this.clickcall)
    
              }else{
                debugger
              //  this.clickcall={};
                     
                    this.stopCall();
                      // console.log($scope.item);
                      this.callconnect(this.clickcall)
              }
              },err=>{
                 if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
              })
              
            
            }
              }
            })
   }
  else{
  
   if(res=='' || JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
     
      this.stopCall();
      // console.log($scope.item);
      this.callconnect(this.clickcall)
    }else{
    
    if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
      // $scope.clickTocallConnect.hide();
      this.stopCall();
      // console.log($scope.item);
      this.callconnect(this.clickcall)
    }else{
    
    var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
    
    if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
      this.voicerecording='No Record'
    }else{
    this.voicerecording=xyz[0].recording.slice(28)
    }
    if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
    this.location="no record"
    }else{
      this.location=xyz[0].location
    }
    if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
      this.provider="no provider"
    }else{
      this.provider=xyz[0].provider
    }
    if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
      this.status="no status"
    }else{
     this.status=xyz[0].status
    }
    if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
      this.status2="no status"
    }else{
     this.status2=xyz[0].status2
    }
    var objendcall={
      CustId :obj.customerId,
                CustName :obj.customerName,
                CustNumber :obj.customerMobile,
                strUserId :userid,
                strBranch :branchid,
                UserNumber :obj.callerMobile,
                StartTime :xyz[0].start_time,
                Endtime :xyz[0].end_time,
                Purpose :purpose,
                duration :xyz[0].duration,
                bill :xyz[0].billsec,
                credit :xyz[0].credits,
                status :this.status,
                status1 :this.status2,
                rec :this.voicerecording,
                location :this.location,
                provider :this.provider,
                callid :this.clickid,
                rowid :this.rowid
    }
    
    this.Apiservice.endcallconnectnewmethod(objendcall)
      .then((response:any)=> {
              debugger
          
              // obj.endStatus == 'I'
              if(obj.endStatus == '0'){
           
             
  
                this.callconnect(this.clickcall)
  
            }else{
              debugger
            //  this.clickcall={};
                   
                  this.stopCall();
                    // console.log($scope.item);
                    this.callconnect(this.clickcall)
            }
            },err=>{
               if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
            })
            
          
          }
            } }
          })




      }else{
        this.callconnect(this.clickcall)
      }
    }
  
  }
  async endcallpopup(){
    debugger
    const alert = await this.alert.create({
      header: 'You have ended the call explicitly. would you like to update?',
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: '',
      buttons: [{ text     : 'Yes',
     
      
      handler:() => {
        // this.clickcall={};
        // this.CallConnectModal.hide();
        // this.alert.dismiss()
         this.stopCall();
         console.log();
        //  this.End(this.clickcall);
          this.callconnect(this.clickcall)
      }
    },
    {
      text     : 'No',
     
      
      handler:() => {
        this.clickcall={};
        //this.CallConnectModal.hide();
        this.stopCall();
        // this.alert.dismiss()
         console.log(this.clickcall);
         this.route.navigateByUrl('/myfollowupcall')
        //  this.route.navigate(['myfollowupvisitendmodel'])
        // this.callconnect(this.clickcall)
        //  this.callconnect(this.clickcall);
      }
    }
  ]
    });
    await alert.present()
  }
 async  callconnect(items){

debugger


  //  if(this.modelget="assigned"){
  //    this.Apiservice.assignedcallarray=[]
  //    this.Apiservice.assignedcallarray.push(items,{close:"endcallassign"})
  //    this.route.navigateByUrl('/check')
  //  } else if(this.modelget="planner"){
  //   this.Apiservice.myfollowupvisitary=[]
  //   this.Apiservice.myfollowupvisitary.push(items,{close:"planner"})
  //   this.route.navigateByUrl('/myfollowupvisitendmodel')
  //  }
   
  //  else{
   this.Apiservice.followupcallarray=[]
   this.Apiservice.followupcallarray.push(items,{close:"endfollowupcall"})
   this.route.navigateByUrl('/myfollowupcallmodal')
  //  }

  }
}
