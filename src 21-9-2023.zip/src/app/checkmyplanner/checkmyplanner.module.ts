import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CheckmyplannerPageRoutingModule } from './checkmyplanner-routing.module';

import { CheckmyplannerPage } from './checkmyplanner.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CheckmyplannerPageRoutingModule
  ],
  declarations: [CheckmyplannerPage]
})
export class CheckmyplannerPageModule {}
