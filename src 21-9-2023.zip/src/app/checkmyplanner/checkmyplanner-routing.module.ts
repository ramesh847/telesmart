import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CheckmyplannerPage } from './checkmyplanner.page';

const routes: Routes = [
  {
    path: '',
    component: CheckmyplannerPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CheckmyplannerPageRoutingModule {}
