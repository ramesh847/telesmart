import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../service/api-service.service';
import {Router } from '@angular/router';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
@Component({
  selector: 'app-goalsheet',
  templateUrl: './goalsheet.page.html',
  styleUrls: ['./goalsheet.page.scss'],
  providers:[Idle]
})
export class GoalsheetPage implements OnInit {
  assignend_date: any;
  userType:any;
  targetbranchuserdata: any;
  username: any;
  assignstartdate:any ;
  assignstartend: any;
  goalsheet: any;
  data: any =[];
  targetuserdata: any =[];
  idleState: string;
  booltargetbranchdata:boolean=false
  booltargetuserdata:boolean=false
  constructor(private router: Router,private apiService: ApiServiceService,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
        // (this.idleState = countdown.toString() )
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
    );}

  ngOnInit() {
    debugger
  this.userType = window.localStorage['userType'];
  this.pageload();
  // this.reset()
  }
reset(){
  this.idle.watch()
}
pageload ()
{
  debugger
  var test = {

  }
  // this.showspin();
  this.apiService.AssigneDdate().then(resp => {
    debugger
  //  var response = JSON.stringify(resp.data);
   var responses = JSON.stringify(resp.data);
 this.assignend_date =JSON.parse(responses);
 this.assignend_date =JSON.parse(this.assignend_date);
 this.assignend_date =JSON.parse(this.assignend_date);
 this.assignend_date =this.assignend_date;
 console.log('32 AssigneDdate',this.assignend_date)
    // this.assignend_date = JSON.parse(this.assignend_date) 
   this.goalsheet =  this.assignend_date[0].GoalBUsinessDate;
  

  })
   


  // var hostLink = httpLinkManager.getnewLocalLink();
  // this.showspin();
  this.apiService.targetbranchuserdatas(window.localStorage['branchID'], window.localStorage['userCode'], 10).then(response => {
    // this.hidespin();
    debugger
var resp = JSON.stringify(response.data);
resp = JSON.parse(resp);
resp = JSON.parse(resp);
resp = JSON.parse(resp);

resp =resp;
    console.log("targetbranchuserdatas",resp)
    
if(resp.length != 0){
    for (var i = 0; i < resp.length; i++) {
      resp[i]['Designationid'] = parseFloat(resp[i]['Designationid']).toFixed(2);
      resp[i]['UserId'] = parseFloat(resp[i]['UserId']).toFixed(2);
      resp[i]['BranchId'] = parseFloat(resp[i]['BranchId']).toFixed(2);
      resp[i]['Existing1'] = parseFloat(resp[i]['Existing1']).toFixed(2);
      resp[i]['New1'] = parseFloat(resp[i]['New1']).toFixed(2);
      resp[i]['Existing2'] = parseFloat(resp[i]['Existing2']).toFixed(2);
      resp[i]['New2'] = parseFloat(resp[i]['New2']).toFixed(2);
      resp[i]['Existing3'] = parseFloat(resp[i]['Existing3']).toFixed(2);

      resp[i]['New3'] = parseFloat(resp[i]['New3']).toFixed(2);

      resp[i]['Existing4'] = parseFloat(resp[i]['Existing4']).toFixed(2);
      resp[i]['New5'] = parseFloat(resp[i]['New5']).toFixed(2);
      resp[i]['Existing5'] = parseFloat(resp[i]['Existing5']).toFixed(2);
      resp[i]['Existing6'] = parseFloat(resp[i]['Existing6']).toFixed(2);





    
    }
    this.targetbranchuserdata = resp[0];
    this.booltargetbranchdata=true
  }else{
this.booltargetbranchdata=false
  }
    
  })
  // .error(function(err){
  //   this.hidespin();
  // })
  this.username = window.localStorage['userName'];
  // this.showspin();
  this.apiService.targetuserdatas(window.localStorage['branchID'], window.localStorage['userCode'], 10).then(response => {
    // this.hidespin();
    debugger
    var res = JSON.stringify(response.data);
    res = JSON.parse(res);
res = JSON.parse(res);
res = JSON.parse(res);
res =res;
    console.log("targetuserdatas",res)
if(res.length != 0){
    for (var i = 0; i < res.length; i++) {
      res[i]['BranchId'] = parseFloat(res[i]['BranchId']).toFixed(2);
      res[i]['Deposit'] = parseFloat(res[i]['Deposit']).toFixed(2);
      res[i]['CASA'] = parseFloat(res[i]['CASA']).toFixed(2);
      res[i]['advance'] = parseFloat(res[i]['advance']).toFixed(2);
      res[i]['NPA'] = parseFloat(res[i]['NPA']).toFixed(2);
      res[i]['Existing5'] = parseFloat(res[i]['Existing5']).toFixed(2);

      res[i]['new5'] = parseFloat(res[i]['new5']).toFixed(2);
      res[i]['Others'] = parseFloat(res[i]['Others']).toFixed(2);


      console.log(res[i]);
    }
    this.targetuserdata = res[0];
    this.booltargetuserdata=true
  }
  else{
this.booltargetuserdata=false
  }

  })
  // .error(function(err){
  //   this.hidespin();
  // })


  // this.showspin();
  // this.apiService.AssigneDdate()
  //       .then(function(response) {
  //         // this.hidespin();
  //         console.log(response.data)
  //         var responses = JSON.stringify(response.data);
  //         responses =JSON.parse(responses);
  //         responses =JSON.parse(responses);
  //         responses =JSON.parse(responses);
  //           // this.data.push(responses[0]);
  //         // console.log(response)
  //           // console.log("108AssigneDdate",value['StartDate']);
  //         //  this.assignstartdate = value['StartDate'];
  //         //  this.assignstartend=value['EndDate'];
  //         //  this.goalsheet ="test";
  //       })
        // .error(function(err){
        //   this.hidespin();
        // })
}

goToMyplannerPage() {
  if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
    this.router.navigate(['/regionsummary']);
}else
  if(window.localStorage['userType']=='17')
{ this.router.navigate(['/newsummary']);}else{
  this.router.navigateByUrl('/myplanner');
}
  // this.router.navigateByUrl('/myplanner');
}

}
