import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DiarywishlistPageRoutingModule } from './diarywishlist-routing.module';

import { DiarywishlistPage } from './diarywishlist.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DiarywishlistPageRoutingModule
  ],
  declarations: [DiarywishlistPage]
})
export class DiarywishlistPageModule {}
