import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DiarywishlistPage } from './diarywishlist.page';

const routes: Routes = [
  {
    path: '',
    component: DiarywishlistPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DiarywishlistPageRoutingModule {}
