import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, IonContent } from '@ionic/angular';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { Idle,DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
@Component({
  selector: 'app-advancecommitmentsummary',
  templateUrl: './advancecommitmentsummary.page.html',
  styleUrls: ['./advancecommitmentsummary.page.scss'],
  providers:[DatePipe,Idle]
})
export class AdvancecommitmentsummaryPage implements OnInit {
  userid: any;
  branchid: any;
  datearray:any[]=[]
  visitdate:any;
  splitdate: string;
  pparray: any;
  norecord: string;
  dropdownselect:boolean
  gettoppage: any;
  availamont: any;
  availsum: any;
  cloginamount: any;
  cloginsum: any;
  countsum: any;
  sumamount: any;
  sumtotal: any;
  sumCompleted: any;
  sumpending: any;
  ispageload:boolean=false
  redirect: any;
  rdmdate: string;
  tbranch: any;
  tpending: any;
  tcompleted: any;
  cloccmount: any;
  cloccount: any;
  existingamount: any;
  existingcount: any;
  newamount: any;
  newcount: any;
  totalamount: any;
  totalcount: any;
  availamount: any;
  availcount: any;
  gridarray: any;
  @ViewChild(IonContent, { static: false }) content: IonContent;
  clickuserid: any;
  glength: any;
  newloginindivsumcount: any;
  newloginindivsumamount: any;
  existingloginindivsumcount: any;
  existingloginindivsumamount: any;
  totalcloginsumcount: any;
  totalcloginsumamount: any;
  rdmobjname: any;
  idleState: string;
  constructor(private router:Router,private alertService: AlertServiceService,
    private service:ApiServiceService,public datepipe: DatePipe,private alert:AlertController,private idle:Idle) { 
      // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
        // (this.idleState = countdown.toString() )
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
    );
    }

  ngOnInit() {
    debugger
    this.visitdate=''
    this.dropdownselect=false
    this.userid= window.localStorage['userID']
    this.branchid= window.localStorage['branchID']
    this.service.getrcommitmentdate().then((res:any)=>{
      debugger
      for(let i=0;i<JSON.parse(res.data).length;i++){
        // this.datearray.push(JSON.parse(res.data)[i].cdate.slice(0,10))
        this.datearray.push(JSON.parse(res.data)[i].date)

        }

    // this.commitdate =JSON.parse(res.data)[0].cdate.slice(0,10)
// this.postsenddate=JSON.parse(res.data)[0].cdate
    })
    // this.reset()
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    //this.timedOut = false;
  }
  getPlan(visitdate){
    debugger
  
    if(visitdate == '' || visitdate == null || visitdate == undefined){
      this.dropdownselect=false
      
    }else{
      var vals = visitdate.split('-');
      var day = vals[0];
      var month = vals[1];
      var year = vals[2];
    this.splitdate=year+"-"+month+"-"+day
      // this.rdmdate=this.splitdate
      var obj=
      {
        // rdmuserid :this.userid,
        commentdate  :this.splitdate
      }
      this.service.advancecommitrdmsummaryclocloginavail(obj).then((res:any)=>{
        debugger

        if(res.data == 'No Record Found'){
          this.dropdownselect=false
        }else{
          this.dropdownselect=true
          this.availamont=JSON.parse(res.data).Table[0].availamont
          console.log("availment",this.availamont)
          this.availsum=JSON.parse(res.data).Table[0].availsum
         this.cloginamount= JSON.parse(res.data).Table[0].cloginamount
          this.cloginsum=JSON.parse(res.data).Table[0].cloginsum
         this.countsum =JSON.parse(res.data).Table[0].countsum
         this.sumamount= JSON.parse(res.data).Table[0].sumamount
         this.sumtotal=JSON.parse(res.data).Table[0].Total
         this.sumCompleted=JSON.parse(res.data).Table[0].Completed
         this.sumpending=JSON.parse(res.data).Table[0].pending

         this.newloginindivsumcount=JSON.parse(res.data).Table1[0].newloginindivsumcount
         this.newloginindivsumamount=JSON.parse(res.data).Table1[0].newloginindivsumamount
         this.existingloginindivsumcount=JSON.parse(res.data).Table1[0].existingloginindivsumcount
         this.existingloginindivsumamount=JSON.parse(res.data).Table1[0].existingloginindivsumamount
         this.totalcloginsumcount=JSON.parse(res.data).Table1[0].totalcloginsumcount
         this.totalcloginsumamount=JSON.parse(res.data).Table1[0].totalcloginsumamount
         this.service. advancecommitrdmsummary(obj).then((res:any)=>{
          debugger
          if(res.data == 'No Record Found'){
           this.dropdownselect=false
          }else{
           this.dropdownselect=true
           this.pparray=JSON.parse(res.data)['Table']
           // var xyz=this.pparray.Sum(x => (x.Total))
          }
        
     
        }
        )
        }
       
      })
      
     
    }
 
  }
  rdmmethod(obj:any){
    debugger
    this.rdmobjname=obj.RDMName
    this.ispageload=true
this.clickuserid=obj.userid
 
    this.redirect=this.visitdate
    var vals = this.visitdate.split('-');
    var day = vals[0];
    var month = vals[1];
    var year = vals[2];
  this.splitdate=year+"-"+month+"-"+day
    this.rdmdate=this.splitdate
    var obj1=
    {
      rdmuserid :this.clickuserid,
      commitdate :this.rdmdate
    }
    this.service.getadvancecommittotalsum(obj1).then((res:any)=>{
      debugger
      // this.isstart=true
     this.tbranch= JSON.parse(res.data)[0].Total_Branch
     this.tpending= JSON.parse(res.data)[0].pending
     this.tcompleted= JSON.parse(res.data)[0].completed
    //  if(this.tpending == '0'){
    //     this.xsave=false
    //     this.isaction=true
    //  }else{
    //    this.xsave=true
    //    this.isaction=false
    //  }
  
  
      this.service.getadvancecommitsumindividual(obj1).then((res:any)=>{
        debugger
if(this.tcompleted == 0){
  this.cloccmount='0'
  this.cloccount='0'
  this.existingamount='0'
  this.existingcount='0'
  this.newamount='0'
  this.newcount='0'
  this.totalamount='0'
  this.totalcount='0'
  this.availamount='0'
  this.availcount='0'
}else{
  this.cloccmount= JSON.parse(res.data)[0].CLOC_commit_amount
  this.cloccount= JSON.parse(res.data)[0].CLOC_commit_count
  this.existingamount= JSON.parse(res.data)[0].Existing_customer_amount
   this.existingcount=JSON.parse(res.data)[0].Existing_customer_count
   this.newamount=JSON.parse(res.data)[0].New_customer_amount
   this.newcount=JSON.parse(res.data)[0].New_customer_count
   this.totalamount=JSON.parse(res.data)[0].Total_Login_amount
  this.totalcount= JSON.parse(res.data)[0].Total_Login_count
  this.availamount= JSON.parse(res.data)[0].availment_commit_amount
  this.availcount= JSON.parse(res.data)[0].availment_commit_count
}

        
  this.service.rdmindiualscount(obj1).then((res:any)=>{
  debugger
  this.gridarray=JSON.parse(res.data)
  
  
  
  
  })
  
      })
    })
  
      
   
    
    
  }
  summarybackrdm(){
    debugger
    this.ispageload=false
    this.getPlan(this.visitdate)

  }
  totalbranch(){
    debugger
    var obj=
    {
      rdmuserid :this.clickuserid,
      commitdate :this.rdmdate
    }
    this.service.rdmindiualscount(obj).then((res:any)=>{
      debugger
      this.gridarray=[]
      this.gridarray=JSON.parse(res.data)
      this.glength=this.gridarray.length
      setTimeout(() => {
        this.ScrollToBottom()
      }, 1000);
      
      
      })
  }
  logScrollStart(event) {
    console.log("logScrollStart : When Scroll Starts", event);
  }

  logScrolling(event) {
    console.log("logScrolling : When Scrolling", event);
  }

  logScrollEnd(event) {
    console.log("logScrollEnd : When Scroll Ends", event);
  }
  ScrollToBottom() {
    debugger
    this.content.scrollToBottom(1500);
  }
  filter(id:any){
    debugger
    var pending={
      rdmuserid :this.clickuserid,
      commitdate :this.rdmdate  ,
      //  this.postsenddate,
      flag : id
    }



this.service.rdmfiltercompleted(pending).then((res:any)=>{
  debugger
  this.gridarray=[]
  this.gridarray=JSON.parse(res.data)
this.glength=this.gridarray.length

  setTimeout(() => {
    this.ScrollToBottom()
  }, 1000);
 
})

  }

}
