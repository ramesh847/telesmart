import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdvancecommitmentsummaryPageRoutingModule } from './advancecommitmentsummary-routing.module';

import { AdvancecommitmentsummaryPage } from './advancecommitmentsummary.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdvancecommitmentsummaryPageRoutingModule
  ],
  declarations: [AdvancecommitmentsummaryPage]
})
export class AdvancecommitmentsummaryPageModule {}
