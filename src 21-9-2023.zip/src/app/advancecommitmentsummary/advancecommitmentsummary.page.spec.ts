import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdvancecommitmentsummaryPage } from './advancecommitmentsummary.page';

describe('AdvancecommitmentsummaryPage', () => {
  let component: AdvancecommitmentsummaryPage;
  let fixture: ComponentFixture<AdvancecommitmentsummaryPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvancecommitmentsummaryPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdvancecommitmentsummaryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
